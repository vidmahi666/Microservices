package com.educonnect.assessmentservice.dto;
import com.educonnect.assessmentservice.entity.Assessment;
import jakarta.validation.constraints.NotBlank; import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;
@Data
public class AssessmentRequest {
    @NotNull private Long courseId;
    @NotBlank private String title;
    @NotNull private Assessment.AssessmentType type;
    private String fileUri; private String instructions;
    private LocalDate dueDate; private Integer maxScore; private Integer passingScore;
}
