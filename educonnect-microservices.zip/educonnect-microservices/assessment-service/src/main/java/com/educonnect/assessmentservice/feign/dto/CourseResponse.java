package com.educonnect.assessmentservice.feign.dto;
import lombok.Data;
@Data public class CourseResponse { private Long courseId; private String title; private Long teacherUserId; private String status; }
