package com.educonnect.assessmentservice.service;

import com.educonnect.assessmentservice.dto.*;
import com.educonnect.assessmentservice.entity.*;
import com.educonnect.assessmentservice.exception.ResourceNotFoundException;
import com.educonnect.assessmentservice.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @RequiredArgsConstructor
public class AssessmentService {
    private final AssessmentRepository assessmentRepository;
    private final SubmissionRepository submissionRepository;

    @Transactional
    public Assessment createAssessment(AssessmentRequest req) {
        return assessmentRepository.save(Assessment.builder()
                .courseId(req.getCourseId()).title(req.getTitle()).type(req.getType())
                .fileUri(req.getFileUri()).instructions(req.getInstructions())
                .dueDate(req.getDueDate()).maxScore(req.getMaxScore()).passingScore(req.getPassingScore()).build());
    }

    public List<Assessment> getAssessmentsByCourse(Long courseId) { return assessmentRepository.findByCourseId(courseId); }
    public Assessment getAssessmentById(Long id) { return assessmentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Assessment", id)); }

    @Transactional
    public Assessment activateAssessment(Long id) {
        Assessment a = getAssessmentById(id); a.setStatus(Assessment.AssessmentStatus.ACTIVE); return assessmentRepository.save(a);
    }

    @Transactional
    public Submission submitAssessment(SubmissionRequest req) {
        Assessment assessment = getAssessmentById(req.getAssessmentId());
        Submission sub = Submission.builder().assessment(assessment).studentId(req.getStudentId())
                .fileUri(req.getFileUri()).comments(req.getComments()).build();
        return submissionRepository.save(sub);
    }

    @Transactional
    public Submission gradeSubmission(Long submissionId, GradeRequest req) {
        Submission sub = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new ResourceNotFoundException("Submission", submissionId));
        sub.setScore(req.getScore());
        sub.setComments(req.getFeedback());
        sub.setStatus(Submission.SubmissionStatus.GRADED);
        return submissionRepository.save(sub);
    }

    public List<Submission> getSubmissionsByStudent(Long studentId) { return submissionRepository.findByStudentId(studentId); }
    public List<Submission> getSubmissionsByAssessment(Long assessmentId) { return submissionRepository.findByAssessmentAssessmentId(assessmentId); }
}
