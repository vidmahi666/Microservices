package com.educonnect.assessmentservice.controller;

import com.educonnect.assessmentservice.dto.*;
import com.educonnect.assessmentservice.entity.*;
import com.educonnect.assessmentservice.service.AssessmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/assessments") @RequiredArgsConstructor
@Tag(name = "Assessments", description = "Assessment management")
public class AssessmentController {
    private final AssessmentService assessmentService;

    @PostMapping @Operation(summary = "Create assessment")
    public ResponseEntity<ApiResponse<Assessment>> createAssessment(@Valid @RequestBody AssessmentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Assessment created", assessmentService.createAssessment(req)));
    }

    @GetMapping("/course/{courseId}") @Operation(summary = "Get assessments by course")
    public ResponseEntity<ApiResponse<List<Assessment>>> getByCourse(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.ok("Assessments", assessmentService.getAssessmentsByCourse(courseId)));
    }

    @GetMapping("/{assessmentId}") @Operation(summary = "Get assessment by ID")
    public ResponseEntity<ApiResponse<Assessment>> getById(@PathVariable Long assessmentId) {
        return ResponseEntity.ok(ApiResponse.ok("Assessment", assessmentService.getAssessmentById(assessmentId)));
    }

    @PatchMapping("/{assessmentId}/activate") @Operation(summary = "Activate assessment")
    public ResponseEntity<ApiResponse<Assessment>> activate(@PathVariable Long assessmentId) {
        return ResponseEntity.ok(ApiResponse.ok("Assessment activated", assessmentService.activateAssessment(assessmentId)));
    }

    @PostMapping("/submissions") @Operation(summary = "Submit assessment")
    public ResponseEntity<ApiResponse<Submission>> submit(@Valid @RequestBody SubmissionRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Submitted", assessmentService.submitAssessment(req)));
    }

    @PatchMapping("/submissions/{submissionId}/grade") @Operation(summary = "Grade submission")
    public ResponseEntity<ApiResponse<Submission>> grade(@PathVariable Long submissionId,
            @Valid @RequestBody GradeRequest req) {
        return ResponseEntity.ok(ApiResponse.ok("Graded", assessmentService.gradeSubmission(submissionId, req)));
    }

    @GetMapping("/submissions/student/{studentId}") @Operation(summary = "Get submissions by student")
    public ResponseEntity<ApiResponse<List<Submission>>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.ok("Submissions", assessmentService.getSubmissionsByStudent(studentId)));
    }

    @GetMapping("/{assessmentId}/submissions") @Operation(summary = "Get submissions by assessment")
    public ResponseEntity<ApiResponse<List<Submission>>> getByAssessment(@PathVariable Long assessmentId) {
        return ResponseEntity.ok(ApiResponse.ok("Submissions", assessmentService.getSubmissionsByAssessment(assessmentId)));
    }
}
