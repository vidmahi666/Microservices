package com.educonnect.assessmentservice.repository;
import com.educonnect.assessmentservice.entity.Submission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    List<Submission> findByStudentId(Long studentId);
    List<Submission> findByAssessmentAssessmentId(Long assessmentId);
    boolean existsByAssessmentAssessmentIdAndStudentId(Long assessmentId, Long studentId);
}
