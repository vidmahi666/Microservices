package com.educonnect.contentservice.repository;
import com.educonnect.contentservice.entity.ContentAccess;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ContentAccessRepository extends JpaRepository<ContentAccess, Long> {
    List<ContentAccess> findByStudentId(Long studentId);
    List<ContentAccess> findByContentContentId(Long contentId);
}
