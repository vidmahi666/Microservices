package com.educonnect.contentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name = "contents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Content {
    public enum ContentType { VIDEO, PDF, QUIZ, DOCUMENT, PRESENTATION }
    public enum ContentStatus { ACTIVE, INACTIVE, ARCHIVED }
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long contentId;
    @Column(nullable = false) private Long courseId;
    @Column(nullable = false) private String title;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ContentType type;
    @Column(nullable = false) private String fileUri;
    private String description;
    private Integer sortOrder;
    @Enumerated(EnumType.STRING) @Builder.Default private ContentStatus status = ContentStatus.ACTIVE;
    @CreatedDate @Column(name = "uploaded_date", nullable = false, updatable = false) private LocalDateTime uploadedDate;
    @LastModifiedDate @Column(name = "updated_at") private LocalDateTime updatedAt;
}
