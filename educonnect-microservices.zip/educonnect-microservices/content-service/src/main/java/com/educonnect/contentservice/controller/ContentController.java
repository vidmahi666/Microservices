package com.educonnect.contentservice.controller;
import com.educonnect.contentservice.dto.*;
import com.educonnect.contentservice.entity.Content; import com.educonnect.contentservice.entity.ContentAccess;
import com.educonnect.contentservice.service.ContentService;
import io.swagger.v3.oas.annotations.Operation; import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/contents") @RequiredArgsConstructor
@Tag(name="Contents", description="Course content management")
public class ContentController {
    private final ContentService contentService;
    @PostMapping @Operation(summary="Upload content")
    public ResponseEntity<ApiResponse<Content>> create(@Valid @RequestBody ContentRequest req){
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Content created",contentService.createContent(req)));
    }
    @GetMapping("/course/{courseId}") @Operation(summary="Get content by course")
    public ResponseEntity<ApiResponse<List<Content>>> getByCourse(@PathVariable Long courseId){
        return ResponseEntity.ok(ApiResponse.ok("Contents",contentService.getContentByCourse(courseId)));
    }
    @GetMapping("/{contentId}") @Operation(summary="Get content by ID")
    public ResponseEntity<ApiResponse<Content>> getById(@PathVariable Long contentId){
        return ResponseEntity.ok(ApiResponse.ok("Content",contentService.getContentById(contentId)));
    }
    @PostMapping("/{contentId}/access") @Operation(summary="Record content access")
    public ResponseEntity<ApiResponse<ContentAccess>> recordAccess(@PathVariable Long contentId,@RequestParam Long studentId){
        return ResponseEntity.ok(ApiResponse.ok("Access recorded",contentService.recordAccess(contentId,studentId)));
    }
    @GetMapping("/access/student/{studentId}") @Operation(summary="Get access history by student")
    public ResponseEntity<ApiResponse<List<ContentAccess>>> getAccessByStudent(@PathVariable Long studentId){
        return ResponseEntity.ok(ApiResponse.ok("Access history",contentService.getAccessByStudent(studentId)));
    }
    @PatchMapping("/{contentId}/status") @Operation(summary="Update content status")
    public ResponseEntity<ApiResponse<Content>> updateStatus(@PathVariable Long contentId,@RequestParam Content.ContentStatus status){
        return ResponseEntity.ok(ApiResponse.ok("Status updated",contentService.updateContentStatus(contentId,status)));
    }
}
