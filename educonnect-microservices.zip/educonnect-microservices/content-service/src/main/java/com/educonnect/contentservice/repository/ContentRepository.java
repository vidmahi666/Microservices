package com.educonnect.contentservice.repository;
import com.educonnect.contentservice.entity.Content;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository public interface ContentRepository extends JpaRepository<Content, Long> {
    List<Content> findByCourseIdOrderBySortOrder(Long courseId);
    List<Content> findByCourseIdAndStatus(Long courseId, Content.ContentStatus status);
}
