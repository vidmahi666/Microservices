package com.educonnect.authservice.feign.dto;

import lombok.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class StudentCreateRequest {
    private Long userId;
    private String name;
    private String contactInfo;
}
