package com.educonnect.authservice.feign.dto;

import lombok.Data;

@Data
public class StudentResponse {
    private Long studentId;
    private String name;
    private String contactInfo;
    private Long userId;
    private String status;
}
