package com.educonnect.authservice.feign;

import com.educonnect.authservice.feign.dto.StudentCreateRequest;
import com.educonnect.authservice.feign.dto.StudentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "student-service", fallback = StudentClientFallback.class)
public interface StudentClient {
    @PostMapping("/api/students/internal/create")
    StudentResponse createStudentProfile(@RequestBody StudentCreateRequest request);
}
