package com.educonnect.courseservice.controller;

import com.educonnect.courseservice.dto.*;
import com.educonnect.courseservice.entity.Progress;
import com.educonnect.courseservice.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/progress") @RequiredArgsConstructor
@Tag(name = "Progress", description = "Student progress tracking")
public class ProgressController {
    private final CourseService courseService;

    @PutMapping("/student/{studentId}/course/{courseId}") @Operation(summary = "Update student progress")
    public ResponseEntity<ApiResponse<Progress>> updateProgress(@PathVariable Long studentId,
            @PathVariable Long courseId, @RequestBody ProgressUpdateRequest req) {
        return ResponseEntity.ok(ApiResponse.ok("Progress updated", courseService.updateProgress(studentId, courseId, req)));
    }

    @GetMapping("/student/{studentId}") @Operation(summary = "Get progress by student")
    public ResponseEntity<ApiResponse<List<Progress>>> getProgressByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.ok("Progress", courseService.getProgressByStudent(studentId)));
    }
}
