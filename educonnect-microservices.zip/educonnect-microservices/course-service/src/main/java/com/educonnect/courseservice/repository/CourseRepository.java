package com.educonnect.courseservice.repository;

import com.educonnect.courseservice.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByTeacherUserId(Long teacherUserId);
    List<Course> findByStatus(Course.CourseStatus status);
}
