package com.educonnect.courseservice.feign.dto;
import lombok.Data;
@Data public class StudentResponse { private Long studentId; private String name; private Long userId; private String status; }
