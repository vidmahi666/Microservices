package com.educonnect.courseservice.service;

import com.educonnect.courseservice.dto.*;
import com.educonnect.courseservice.entity.*;
import com.educonnect.courseservice.exception.ResourceNotFoundException;
import com.educonnect.courseservice.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @RequiredArgsConstructor
public class CourseService {
    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final ProgressRepository progressRepository;
    private final CurriculumRepository curriculumRepository;

    @Transactional
    public Course createCourse(CourseRequest req) {
        return courseRepository.save(Course.builder().title(req.getTitle())
                .description(req.getDescription()).teacherUserId(req.getTeacherUserId())
                .startDate(req.getStartDate()).endDate(req.getEndDate()).build());
    }

    public List<Course> getAllCourses() { return courseRepository.findAll(); }
    public Course getCourseById(Long id) { return courseRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Course", id)); }
    public List<Course> getCoursesByTeacher(Long teacherUserId) { return courseRepository.findByTeacherUserId(teacherUserId); }

    @Transactional
    public Course updateCourse(Long id, CourseRequest req) {
        Course course = getCourseById(id);
        course.setTitle(req.getTitle()); course.setDescription(req.getDescription());
        course.setStartDate(req.getStartDate()); course.setEndDate(req.getEndDate());
        return courseRepository.save(course);
    }

    @Transactional
    public Enrollment enrollStudent(EnrollmentRequest req) {
        if (enrollmentRepository.existsByStudentIdAndCourseCourseId(req.getStudentId(), req.getCourseId()))
            throw new RuntimeException("Student already enrolled in this course");
        Course course = getCourseById(req.getCourseId());
        Enrollment enrollment = Enrollment.builder().studentId(req.getStudentId()).course(course).build();
        Enrollment saved = enrollmentRepository.save(enrollment);
        // Init progress record
        progressRepository.save(Progress.builder().studentId(req.getStudentId()).course(course).completionPercentage(0.0).build());
        return saved;
    }

    public List<Enrollment> getEnrollmentsByStudent(Long studentId) { return enrollmentRepository.findByStudentId(studentId); }
    public List<Enrollment> getEnrollmentsByCourse(Long courseId) { return enrollmentRepository.findByCourseCourseId(courseId); }

    @Transactional
    public Progress updateProgress(Long studentId, Long courseId, ProgressUpdateRequest req) {
        Progress progress = progressRepository.findByStudentIdAndCourseCourseId(studentId, courseId)
                .orElseGet(() -> Progress.builder().studentId(studentId).course(getCourseById(courseId)).build());
        if (req.getCompletionPercentage() != null) progress.setCompletionPercentage(req.getCompletionPercentage());
        if (req.getMetricsJson() != null) progress.setMetricsJson(req.getMetricsJson());
        if (progress.getCompletionPercentage() != null && progress.getCompletionPercentage() >= 100.0)
            progress.setStatus(Progress.ProgressStatus.COMPLETED);
        return progressRepository.save(progress);
    }

    public List<Progress> getProgressByStudent(Long studentId) { return progressRepository.findByStudentId(studentId); }
}
