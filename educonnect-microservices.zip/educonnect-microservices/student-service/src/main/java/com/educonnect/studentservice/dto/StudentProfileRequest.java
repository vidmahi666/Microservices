package com.educonnect.studentservice.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.time.LocalDate;

@Data
public class StudentProfileRequest {
    @NotBlank private String name;
    private LocalDate dob;
    private String gender;
    private String address;
    private String contactInfo;
}
