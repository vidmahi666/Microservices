package com.educonnect.studentservice.service;

import com.educonnect.studentservice.dto.StudentProfileRequest;
import com.educonnect.studentservice.entity.Student;
import com.educonnect.studentservice.entity.StudentDocument;
import com.educonnect.studentservice.exception.ResourceNotFoundException;
import com.educonnect.studentservice.repository.StudentDocumentRepository;
import com.educonnect.studentservice.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@Slf4j @Service @RequiredArgsConstructor
public class StudentService {
    private final StudentRepository studentRepository;
    private final StudentDocumentRepository studentDocumentRepository;

    @Transactional
    public Student createStudentFromRegistration(Long userId, String name, String contactInfo) {
        if (studentRepository.existsByUserId(userId)) {
            log.info("Student profile already exists for userId={}", userId);
            return studentRepository.findByUserId(userId).orElseThrow();
        }
        Student student = Student.builder().userId(userId).name(name)
                .contactInfo(contactInfo).status(Student.Status.ACTIVE).build();
        return studentRepository.save(student);
    }

    public Student getStudentByUserId(Long userId) {
        return studentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found for userId: " + userId));
    }

    public Student getStudentById(Long studentId) {
        return studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student", studentId));
    }

    public List<Student> getAllStudents() { return studentRepository.findAll(); }

    @Transactional
    public Student updateStudentProfile(Long userId, StudentProfileRequest request) {
        Student student = getStudentByUserId(userId);
        student.setName(request.getName());
        student.setDob(request.getDob());
        student.setGender(request.getGender());
        student.setAddress(request.getAddress());
        student.setContactInfo(request.getContactInfo());
        return studentRepository.save(student);
    }

    @Transactional
    public StudentDocument uploadDocument(Long studentId, MultipartFile file) throws IOException {
        Student student = getStudentById(studentId);
        StudentDocument doc = StudentDocument.builder()
                .student(student).documentData(file.getBytes())
                .uploadedDate(LocalDate.now()).build();
        return studentDocumentRepository.save(doc);
    }

    public List<StudentDocument> getStudentDocuments(Long studentId) {
        getStudentById(studentId);
        return studentDocumentRepository.findByStudentStudentId(studentId);
    }

    @Transactional
    public StudentDocument verifyDocument(Long documentId, StudentDocument.VerificationStatus status) {
        StudentDocument doc = studentDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException("Document", documentId));
        doc.setVerificationStatus(status);
        return studentDocumentRepository.save(doc);
    }
}
