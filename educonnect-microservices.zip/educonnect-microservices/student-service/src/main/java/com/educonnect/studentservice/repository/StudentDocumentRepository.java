package com.educonnect.studentservice.repository;

import com.educonnect.studentservice.entity.StudentDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface StudentDocumentRepository extends JpaRepository<StudentDocument, Long> {
    List<StudentDocument> findByStudentStudentId(Long studentId);
}
