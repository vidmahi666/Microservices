package com.educonnect.studentservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class StudentInternalCreateRequest {
    @NotNull  private Long userId;
    @NotBlank private String name;
    private String contactInfo;
}
