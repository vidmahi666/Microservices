package com.educonnect.studentservice.controller;

import com.educonnect.studentservice.dto.ApiResponse;
import com.educonnect.studentservice.dto.StudentProfileRequest;
import com.educonnect.studentservice.entity.Student;
import com.educonnect.studentservice.entity.StudentDocument;
import com.educonnect.studentservice.service.StudentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;

@RestController @RequestMapping("/students") @RequiredArgsConstructor
@Tag(name = "Students", description = "Student profile and document management")
public class StudentController {
    private final StudentService studentService;

    @GetMapping
    @Operation(summary = "Get all students")
    public ResponseEntity<ApiResponse<List<Student>>> getAllStudents() {
        return ResponseEntity.ok(ApiResponse.ok("All students", studentService.getAllStudents()));
    }

    @GetMapping("/{studentId}")
    @Operation(summary = "Get student by ID")
    public ResponseEntity<ApiResponse<Student>> getStudentById(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.ok("Student", studentService.getStudentById(studentId)));
    }

    @GetMapping("/by-user/{userId}")
    @Operation(summary = "Get student by user ID")
    public ResponseEntity<ApiResponse<Student>> getStudentByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Student", studentService.getStudentByUserId(userId)));
    }

    @PutMapping("/profile/{userId}")
    @Operation(summary = "Update student profile")
    public ResponseEntity<ApiResponse<Student>> updateProfile(@PathVariable Long userId,
            @Valid @RequestBody StudentProfileRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("Profile updated", studentService.updateStudentProfile(userId, request)));
    }

    @PostMapping("/{studentId}/documents")
    @Operation(summary = "Upload student document")
    public ResponseEntity<ApiResponse<StudentDocument>> uploadDocument(@PathVariable Long studentId,
            @RequestParam("file") MultipartFile file) throws IOException {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Document uploaded", studentService.uploadDocument(studentId, file)));
    }

    @GetMapping("/{studentId}/documents")
    @Operation(summary = "Get student documents")
    public ResponseEntity<ApiResponse<List<StudentDocument>>> getDocuments(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.ok("Documents", studentService.getStudentDocuments(studentId)));
    }

    @PatchMapping("/documents/{documentId}/verify")
    @Operation(summary = "[ADMIN] Verify student document")
    public ResponseEntity<ApiResponse<StudentDocument>> verifyDocument(@PathVariable Long documentId,
            @RequestParam StudentDocument.VerificationStatus status) {
        return ResponseEntity.ok(ApiResponse.ok("Document verified", studentService.verifyDocument(documentId, status)));
    }
}
