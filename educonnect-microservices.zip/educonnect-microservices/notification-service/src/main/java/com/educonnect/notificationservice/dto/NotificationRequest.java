package com.educonnect.notificationservice.dto;
import com.educonnect.notificationservice.entity.Notification;
import jakarta.validation.constraints.NotBlank; import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data public class NotificationRequest{
    @NotNull private Long userId;
    private Long entityId;
    @NotBlank private String message;
    @NotNull private Notification.NotificationCategory category;
}
