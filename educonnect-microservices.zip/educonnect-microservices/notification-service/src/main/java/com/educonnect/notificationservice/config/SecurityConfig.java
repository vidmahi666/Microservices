package com.educonnect.notificationservice.config;
import com.educonnect.notificationservice.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;
import jakarta.servlet.FilterChain;import jakarta.servlet.ServletException;import jakarta.servlet.http.HttpServletRequest;import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;import org.springframework.security.core.context.SecurityContextHolder;
import java.io.IOException;import java.util.List;
@Configuration @EnableWebSecurity @RequiredArgsConstructor
public class SecurityConfig{
    private final JwtUtil jwtUtil;
    @Bean public SecurityFilterChain securityFilterChain(HttpSecurity h)throws Exception{
        h.csrf(AbstractHttpConfigurer::disable).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
         .authorizeHttpRequests(a->a.requestMatchers("/swagger-ui/**","/v3/api-docs/**","/actuator/**").permitAll().anyRequest().authenticated())
         .addFilterBefore(jwtAuthFilter(),UsernamePasswordAuthenticationFilter.class);
        return h.build();
    }
    @Bean public OncePerRequestFilter jwtAuthFilter(){
        return new OncePerRequestFilter(){
            @Override protected void doFilterInternal(HttpServletRequest rq,HttpServletResponse rs,FilterChain c)throws ServletException,IOException{
                String hd=rq.getHeader(HttpHeaders.AUTHORIZATION);
                if(hd!=null&&hd.startsWith("Bearer ")){String t=hd.substring(7);if(jwtUtil.validateToken(t)){String r=rq.getHeader("X-User-Role");if(r==null)r="STUDENT";SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(jwtUtil.extractUsername(t),null,List.of(new SimpleGrantedAuthority("ROLE_"+r))));}}
                c.doFilter(rq,rs);
            }
        };
    }
}
