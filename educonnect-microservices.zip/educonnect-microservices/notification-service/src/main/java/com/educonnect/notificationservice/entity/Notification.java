package com.educonnect.notificationservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name="notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Notification {
    public enum NotificationCategory{COURSE,ASSESSMENT,PROGRAM,COMPLIANCE,SYSTEM}
    public enum NotificationStatus{UNREAD,READ,ARCHIVED}
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long notificationId;
    @Column(nullable=false) private Long userId;
    private Long entityId;
    @Column(columnDefinition="TEXT",nullable=false) private String message;
    @Enumerated(EnumType.STRING) @Column(nullable=false) private NotificationCategory category;
    @Enumerated(EnumType.STRING) @Builder.Default private NotificationStatus status=NotificationStatus.UNREAD;
    @CreatedDate private LocalDateTime createdDate;
}
