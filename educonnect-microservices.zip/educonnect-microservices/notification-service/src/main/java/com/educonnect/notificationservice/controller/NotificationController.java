package com.educonnect.notificationservice.controller;
import com.educonnect.notificationservice.dto.*;
import com.educonnect.notificationservice.entity.Notification;
import com.educonnect.notificationservice.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;import lombok.RequiredArgsConstructor;
import org.springframework.http.*;import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/notifications") @RequiredArgsConstructor
@Tag(name="Notifications",description="Notification management")
public class NotificationController{
    private final NotificationService notificationService;
    @PostMapping @Operation(summary="Create notification")
    public ResponseEntity<ApiResponse<Notification>> create(@Valid @RequestBody NotificationRequest req){
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Notification created",notificationService.createNotification(req)));
    }
    @GetMapping("/user/{userId}") @Operation(summary="Get notifications by user")
    public ResponseEntity<ApiResponse<List<Notification>>> getByUser(@PathVariable Long userId){
        return ResponseEntity.ok(ApiResponse.ok("Notifications",notificationService.getByUser(userId)));
    }
    @GetMapping("/user/{userId}/unread") @Operation(summary="Get unread notifications")
    public ResponseEntity<ApiResponse<List<Notification>>> getUnread(@PathVariable Long userId){
        return ResponseEntity.ok(ApiResponse.ok("Unread",notificationService.getUnreadByUser(userId)));
    }
    @PatchMapping("/{notificationId}/read") @Operation(summary="Mark as read")
    public ResponseEntity<ApiResponse<Notification>> markRead(@PathVariable Long notificationId){
        return ResponseEntity.ok(ApiResponse.ok("Marked read",notificationService.markAsRead(notificationId)));
    }
    @PatchMapping("/{notificationId}/archive") @Operation(summary="Archive notification")
    public ResponseEntity<ApiResponse<Notification>> archive(@PathVariable Long notificationId){
        return ResponseEntity.ok(ApiResponse.ok("Archived",notificationService.archive(notificationId)));
    }
}
