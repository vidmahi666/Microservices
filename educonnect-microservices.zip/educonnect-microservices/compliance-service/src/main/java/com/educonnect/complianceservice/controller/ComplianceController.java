package com.educonnect.complianceservice.controller;
import com.educonnect.complianceservice.dto.*;
import com.educonnect.complianceservice.entity.*;
import com.educonnect.complianceservice.service.ComplianceService;
import io.swagger.v3.oas.annotations.Operation;import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;import lombok.RequiredArgsConstructor;
import org.springframework.http.*;import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/compliance") @RequiredArgsConstructor
@Tag(name="Compliance",description="Compliance record management")
public class ComplianceController{
    private final ComplianceService complianceService;
    @PostMapping @Operation(summary="Create compliance record")
    public ResponseEntity<ApiResponse<ComplianceRecord>> create(@Valid @RequestBody ComplianceRecordRequest req){
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Record created",complianceService.createComplianceRecord(req)));
    }
    @GetMapping @Operation(summary="Get all compliance records")
    public ResponseEntity<ApiResponse<List<ComplianceRecord>>> getAll(){
        return ResponseEntity.ok(ApiResponse.ok("Records",complianceService.getAllRecords()));
    }
    @GetMapping("/entity/{entityId}") @Operation(summary="Get records by entity")
    public ResponseEntity<ApiResponse<List<ComplianceRecord>>> getByEntity(@PathVariable Long entityId){
        return ResponseEntity.ok(ApiResponse.ok("Records",complianceService.getRecordsByEntity(entityId)));
    }
    @PatchMapping("/{complianceId}/result") @Operation(summary="Update compliance result")
    public ResponseEntity<ApiResponse<ComplianceRecord>> updateResult(@PathVariable Long complianceId,@RequestParam ComplianceRecord.ComplianceResult result){
        return ResponseEntity.ok(ApiResponse.ok("Result updated",complianceService.updateResult(complianceId,result)));
    }
}
