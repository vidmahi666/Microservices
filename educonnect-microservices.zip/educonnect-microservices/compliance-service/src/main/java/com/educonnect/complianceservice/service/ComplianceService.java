package com.educonnect.complianceservice.service;
import com.educonnect.complianceservice.dto.*;
import com.educonnect.complianceservice.entity.*;
import com.educonnect.complianceservice.exception.ResourceNotFoundException;
import com.educonnect.complianceservice.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;
import java.util.List;
@Service @RequiredArgsConstructor
public class ComplianceService{
    private final ComplianceRecordRepository complianceRecordRepository;
    private final AuditRepository auditRepository;
    private final AuditLogRepository auditLogRepository;

    @Transactional public ComplianceRecord createComplianceRecord(ComplianceRecordRequest req){
        return complianceRecordRepository.save(ComplianceRecord.builder().entityId(req.getEntityId())
                .type(req.getType()).result(req.getResult()).notes(req.getNotes()).build());
    }
    public List<ComplianceRecord> getAllRecords(){return complianceRecordRepository.findAll();}
    public List<ComplianceRecord> getRecordsByEntity(Long entityId){return complianceRecordRepository.findByEntityId(entityId);}
    @Transactional public ComplianceRecord updateResult(Long id,ComplianceRecord.ComplianceResult result){
        ComplianceRecord r=complianceRecordRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("ComplianceRecord",id));
        r.setResult(result);return complianceRecordRepository.save(r);
    }

    @Transactional public Audit createAudit(AuditRequest req){
        return auditRepository.save(Audit.builder().title(req.getTitle())
                .description(req.getDescription()).auditorUserId(req.getAuditorUserId()).build());
    }
    public List<Audit> getAllAudits(){return auditRepository.findAll();}
    @Transactional public Audit updateAuditStatus(Long id,Audit.AuditStatus status){
        Audit a=auditRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Audit",id));
        a.setStatus(status);return auditRepository.save(a);
    }

    @Transactional public AuditLog logAction(AuditLogRequest req){
        return auditLogRepository.save(AuditLog.builder().action(req.getAction()).entityType(req.getEntityType())
                .entityId(req.getEntityId()).performedByUserId(req.getPerformedByUserId()).details(req.getDetails()).build());
    }
    public List<AuditLog> getLogsByEntity(String entityType,Long entityId){return auditLogRepository.findByEntityTypeAndEntityId(entityType,entityId);}
    public List<AuditLog> getLogsByUser(Long userId){return auditLogRepository.findByPerformedByUserId(userId);}
}
