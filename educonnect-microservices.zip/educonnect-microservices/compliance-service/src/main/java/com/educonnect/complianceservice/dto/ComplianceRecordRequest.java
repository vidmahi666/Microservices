package com.educonnect.complianceservice.dto;
import com.educonnect.complianceservice.entity.ComplianceRecord;
import jakarta.validation.constraints.NotNull;import lombok.Data;
@Data public class ComplianceRecordRequest{
    @NotNull private Long entityId;
    @NotNull private ComplianceRecord.ComplianceType type;
    private ComplianceRecord.ComplianceResult result;
    private String notes;
}
