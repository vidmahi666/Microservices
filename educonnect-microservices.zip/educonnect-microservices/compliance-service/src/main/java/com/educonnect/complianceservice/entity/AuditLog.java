package com.educonnect.complianceservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name="audit_logs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class AuditLog{
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long logId;
    @Column(nullable=false) private String action;
    @Column(nullable=false) private String entityType;
    private Long entityId;
    private Long performedByUserId;
    @Column(columnDefinition="TEXT") private String details;
    @CreatedDate private LocalDateTime timestamp;
}
