import { Routes } from '@angular/router';
import { authGuard, roleGuard, guestGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth/login',
    pathMatch: 'full'
  },

  // ── Auth ────────────────────────────────────────────────────────────────
  {
    path: 'auth',
    canActivate: [guestGuard],
    loadChildren: () =>
      import('./features/auth/auth.routes').then(m => m.AUTH_ROUTES)
  },

  // ── Student ─────────────────────────────────────────────────────────────
  {
    path: 'student',
    canActivate: [authGuard, roleGuard('STUDENT')],
    loadChildren: () =>
      import('./features/student/student.routes').then(m => m.STUDENT_ROUTES)
  },

  // ── Teacher ─────────────────────────────────────────────────────────────
  {
    path: 'teacher',
    canActivate: [authGuard, roleGuard('TEACHER')],
    loadChildren: () =>
      import('./features/teacher/teacher.routes').then(m => m.TEACHER_ROUTES)
  },

  // ── Admin / Staff ────────────────────────────────────────────────────────
  {
    path: 'admin',
    canActivate: [authGuard, roleGuard('ADMIN', 'PROGRAM_MANAGER', 'COMPLIANCE_OFFICER', 'GOVERNMENT_AUDITOR')],
    loadChildren: () =>
      import('./features/admin/admin.routes').then(m => m.ADMIN_ROUTES)
  },

  // ── Unauthorized ─────────────────────────────────────────────────────────
  {
    path: 'unauthorized',
    loadComponent: () =>
      import('./shared/components/unauthorized/unauthorized.component').then(m => m.UnauthorizedComponent)
  },

  // ── 404 ──────────────────────────────────────────────────────────────────
  {
    path: '**',
    loadComponent: () =>
      import('./shared/components/not-found/not-found.component').then(m => m.NotFoundComponent)
  }
];
