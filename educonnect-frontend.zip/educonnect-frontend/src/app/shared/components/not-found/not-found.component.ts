import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="error-page">
      <div class="error-card">
        <div class="error-code">404</div>
        <h1>Page Not Found</h1>
        <p>The page you're looking for doesn't exist or has been moved.</p>
        <div style="margin-top:2rem">
          <a routerLink="/" class="ec-btn ec-btn-primary">← Back to Home</a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .error-page { min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg-void);padding:2rem; }
    .error-card { text-align:center;max-width:440px; }
    .error-code {
      font-family:var(--font-display);font-size:6rem;font-weight:800;line-height:1;
      background:linear-gradient(135deg,var(--teal-400),var(--gold-400));
      -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
      margin-bottom:1rem;
    }
    h1 { font-size:1.75rem;margin-bottom:0.75rem; }
    p { color:var(--text-secondary); }
  `]
})
export class NotFoundComponent {}
