import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent, HeaderComponent],
  template: `
    <div class="ec-layout">
      <app-sidebar />
      <div class="ec-main-content">
        <app-header />
        <main class="ec-page">
          <router-outlet />
        </main>
      </div>
    </div>
  `
})
export class ShellComponent {}
