import { Component, computed, input } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { UserRole } from '../../../core/models/models';

interface NavItem {
  label: string;
  icon: string;
  route: string;
  roles: UserRole[];
  badge?: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <aside class="sidebar">
      <!-- Brand -->
      <div class="sidebar-brand">
        <span class="brand-icon">🎓</span>
        <div>
          <h2 class="brand-name">EduConnect</h2>
          <span class="brand-sub">Learning Platform</span>
        </div>
      </div>

      <!-- User info -->
      <div class="user-info">
        <div class="user-avatar">{{ initials() }}</div>
        <div class="user-details">
          <span class="user-name">{{ user()?.name }}</span>
          <span class="role-chip">{{ roleLabel() }}</span>
        </div>
      </div>

      <div class="sidebar-divider"></div>

      <!-- Navigation -->
      <nav class="sidebar-nav">
        @for (item of visibleNav(); track item.route) {
          <a
            [routerLink]="item.route"
            routerLinkActive="active"
            class="nav-item"
          >
            <span class="nav-icon">{{ item.icon }}</span>
            <span class="nav-label">{{ item.label }}</span>
            @if (item.badge) {
              <span class="nav-badge">{{ item.badge }}</span>
            }
          </a>
        }
      </nav>

      <div class="sidebar-footer">
        <button class="logout-btn" (click)="logout()">
          <span>🚪</span>
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  `,
  styles: [`
    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: var(--sidebar-width);
      height: 100vh;
      background: var(--bg-deep);
      border-right: 1px solid var(--border-subtle);
      display: flex;
      flex-direction: column;
      z-index: 100;
      overflow-y: auto;
    }

    .sidebar-brand {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 1.5rem 1.25rem 1.25rem;
    }
    .brand-icon { font-size: 1.75rem; }
    .brand-name {
      font-family: var(--font-display);
      font-size: 1rem;
      font-weight: 700;
      background: linear-gradient(135deg, var(--teal-400), var(--gold-400));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin: 0;
    }
    .brand-sub { font-size: 0.7rem; color: var(--text-muted); display: block; }

    .user-info {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin: 0 0.75rem;
      padding: 0.75rem;
      background: var(--bg-surface);
      border-radius: var(--radius-md);
    }
    .user-avatar {
      width: 36px; height: 36px;
      background: linear-gradient(135deg, var(--teal-600), var(--teal-400));
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: var(--font-display);
      font-size: 0.8rem;
      font-weight: 700;
      color: #fff;
      flex-shrink: 0;
    }
    .user-name {
      font-size: 0.875rem;
      font-weight: 500;
      display: block;
      color: var(--text-primary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .role-chip {
      font-size: 0.68rem;
      font-weight: 600;
      color: var(--teal-400);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .sidebar-divider {
      height: 1px;
      background: var(--border-subtle);
      margin: 1rem 0.75rem;
    }

    .sidebar-nav {
      flex: 1;
      padding: 0 0.75rem;
      display: flex;
      flex-direction: column;
      gap: 0.125rem;
    }

    .nav-item {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.7rem 0.875rem;
      border-radius: var(--radius-md);
      color: var(--text-secondary);
      font-size: 0.875rem;
      font-weight: 400;
      transition: all var(--transition-fast);
      text-decoration: none;
      position: relative;
    }
    .nav-item:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }
    .nav-item.active {
      background: rgba(20,184,166,0.12);
      color: var(--teal-400);
      font-weight: 500;
    }
    .nav-item.active::before {
      content: '';
      position: absolute;
      left: 0; top: 20%; height: 60%;
      width: 3px;
      background: var(--accent-primary);
      border-radius: 0 2px 2px 0;
    }
    .nav-icon { font-size: 1rem; width: 1.25rem; text-align: center; }
    .nav-label { flex: 1; }
    .nav-badge {
      background: var(--error);
      color: #fff;
      font-size: 0.65rem;
      font-weight: 700;
      padding: 0.1rem 0.4rem;
      border-radius: 10px;
    }

    .sidebar-footer {
      padding: 0.75rem;
      border-top: 1px solid var(--border-subtle);
    }
    .logout-btn {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      width: 100%;
      padding: 0.7rem 0.875rem;
      background: transparent;
      border: none;
      border-radius: var(--radius-md);
      color: var(--text-secondary);
      font-size: 0.875rem;
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    .logout-btn:hover {
      background: rgba(239,68,68,0.1);
      color: var(--error);
    }
  `]
})
export class SidebarComponent {
  constructor(private auth: AuthService) {}

  user   = this.auth.currentUser;
  role   = computed(() => this.auth.getRole());

  initials = computed(() => {
    const name = this.user()?.name ?? '';
    return name.split(' ').slice(0,2).map(n => n[0]).join('').toUpperCase();
  });

  roleLabel = computed(() => {
    const map: Record<string, string> = {
      STUDENT: 'Student',
      TEACHER: 'Teacher',
      ADMIN: 'Administrator',
      PROGRAM_MANAGER: 'Program Manager',
      COMPLIANCE_OFFICER: 'Compliance Officer',
      GOVERNMENT_AUDITOR: 'Government Auditor',
    };
    return map[this.role() ?? ''] ?? this.role();
  });

  private allNav: NavItem[] = [
    // ── Student
    { label: 'Dashboard',    icon: '🏠', route: '/student/dashboard',    roles: ['STUDENT'] },
    { label: 'My Courses',   icon: '📚', route: '/student/courses',      roles: ['STUDENT'] },
    { label: 'Assessments',  icon: '📝', route: '/student/assessments',  roles: ['STUDENT'] },
    { label: 'My Progress',  icon: '📊', route: '/student/progress',     roles: ['STUDENT'] },
    { label: 'My Profile',   icon: '👤', route: '/student/profile',      roles: ['STUDENT'] },
    // ── Teacher
    { label: 'Dashboard',    icon: '🏠', route: '/teacher/dashboard',    roles: ['TEACHER'] },
    { label: 'My Courses',   icon: '📚', route: '/teacher/courses',      roles: ['TEACHER'] },
    { label: 'Course Content', icon: '🎬', route: '/teacher/content',   roles: ['TEACHER'] },
    { label: 'Assessments',  icon: '📝', route: '/teacher/assessments',  roles: ['TEACHER'] },
    { label: 'Students',     icon: '👥', route: '/teacher/students',     roles: ['TEACHER'] },
    // ── Admin
    { label: 'Dashboard',    icon: '🏠', route: '/admin/dashboard',      roles: ['ADMIN', 'PROGRAM_MANAGER'] },
    { label: 'User Management', icon: '👥', route: '/admin/users',       roles: ['ADMIN'] },
    { label: 'All Courses',  icon: '📚', route: '/admin/courses',        roles: ['ADMIN', 'PROGRAM_MANAGER'] },
    { label: 'Reports',      icon: '📊', route: '/admin/reports',        roles: ['ADMIN', 'PROGRAM_MANAGER'] },
    { label: 'Compliance',   icon: '✅', route: '/admin/compliance',     roles: ['ADMIN', 'COMPLIANCE_OFFICER'] },
    { label: 'Audits',       icon: '🔍', route: '/admin/audits',         roles: ['ADMIN', 'COMPLIANCE_OFFICER', 'GOVERNMENT_AUDITOR'] },
  ];

  visibleNav = computed(() => {
    const r = this.role();
    if (!r) return [];
    return this.allNav.filter(n => n.roles.includes(r));
  });

  logout(): void { this.auth.logout(); }
}
