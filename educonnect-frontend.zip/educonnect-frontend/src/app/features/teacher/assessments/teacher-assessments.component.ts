import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AssessmentService, CourseService } from '../../../core/services/api.services';
import { Assessment, Submission, Course, AssessmentType } from '../../../core/models/models';

@Component({
  selector: 'app-teacher-assessments',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div>
      <div class="page-header-row">
        <div>
          <h2 class="ec-section-title">Assessments</h2>
          <p class="ec-section-sub">Create tests, quizzes and assignments; grade submissions</p>
        </div>
        <button class="ec-btn ec-btn-primary" (click)="openCreate()">+ New Assessment</button>
      </div>

      <!-- Tabs -->
      <div class="tabs">
        <button class="tab-btn" [class.active]="tab() === 'assessments'" (click)="tab.set('assessments')">
          Assessments ({{ assessments().length }})
        </button>
        <button class="tab-btn" [class.active]="tab() === 'grading'" (click)="tab.set('grading')">
          Pending Grading ({{ pendingCount() }})
        </button>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      }

      <!-- Assessment list -->
      @if (!loading() && tab() === 'assessments') {
        @if (assessments().length === 0) {
          <div class="ec-empty">
            <div class="ec-empty-icon">📝</div>
            <h3>No assessments yet</h3>
            <p>Create quizzes and tests for your courses</p>
          </div>
        } @else {
          <div class="ec-table-wrap">
            <table class="ec-table">
              <thead>
                <tr><th>Title</th><th>Course</th><th>Type</th><th>Max Score</th><th>Due Date</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                @for (a of assessments(); track a.assessmentId) {
                  <tr>
                    <td><strong>{{ a.title }}</strong></td>
                    <td style="font-size:0.83rem;color:var(--text-secondary)">{{ a.courseTitle ?? 'Course #'+a.courseId }}</td>
                    <td><span class="type-tag type-{{ a.type.toLowerCase() }}">{{ a.type }}</span></td>
                    <td>{{ a.maxScore }}</td>
                    <td>{{ a.dueDate | date:'mediumDate' }}</td>
                    <td><span class="ec-badge" [class]="statusBadge(a.status)">{{ a.status }}</span></td>
                    <td>
                      @if (a.status === 'DRAFT') {
                        <button class="ec-btn ec-btn-primary ec-btn-sm" (click)="activate(a)">Activate</button>
                      }
                      <button class="ec-btn ec-btn-secondary ec-btn-sm" style="margin-left:0.4rem" (click)="viewSubmissions(a)">
                        Submissions
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Grading tab -->
      @if (!loading() && tab() === 'grading') {
        @if (submissionsToGrade().length === 0) {
          <div class="ec-empty">
            <div class="ec-empty-icon">✅</div>
            <h3>All caught up!</h3>
            <p>No pending submissions to grade</p>
          </div>
        } @else {
          <div class="ec-table-wrap">
            <table class="ec-table">
              <thead>
                <tr><th>Student</th><th>Assessment</th><th>Submitted</th><th>File</th><th>Action</th></tr>
              </thead>
              <tbody>
                @for (s of submissionsToGrade(); track s.submissionId) {
                  <tr>
                    <td>{{ s.studentName ?? 'Student #'+s.studentId }}</td>
                    <td>{{ s.assessmentTitle ?? 'Assessment #'+s.assessmentId }}</td>
                    <td>{{ s.submittedAt | date:'mediumDate' }}</td>
                    <td>
                      <a [href]="s.fileUri" target="_blank" class="file-link">📎 View File</a>
                    </td>
                    <td>
                      <button class="ec-btn ec-btn-gold ec-btn-sm" (click)="openGrade(s)">Grade</button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Create Assessment Modal -->
      @if (showCreateModal()) {
        <div class="ec-modal-overlay" (click)="showCreateModal.set(false)">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>Create Assessment</h3>
              <button class="ec-modal-close" (click)="showCreateModal.set(false)">✕</button>
            </div>
            @if (createError()) {
              <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ createError() }}</span></div>
            }
            <form [formGroup]="createForm" (ngSubmit)="create()">
              <div class="ec-form-group">
                <label class="ec-label">Course *</label>
                <select formControlName="courseId" class="ec-select">
                  <option value="">Select course</option>
                  @for (c of courses(); track c.courseId) {
                    <option [value]="c.courseId">{{ c.title }}</option>
                  }
                </select>
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Title *</label>
                <input formControlName="title" type="text" class="ec-input" placeholder="Assessment title" />
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Description</label>
                <textarea formControlName="description" class="ec-textarea" rows="2"></textarea>
              </div>
              <div class="ec-grid-2">
                <div class="ec-form-group">
                  <label class="ec-label">Type *</label>
                  <select formControlName="type" class="ec-select">
                    <option value="">Select</option>
                    @for (t of types; track t) { <option [value]="t">{{ t }}</option> }
                  </select>
                </div>
                <div class="ec-form-group">
                  <label class="ec-label">Max Score *</label>
                  <input formControlName="maxScore" type="number" class="ec-input" placeholder="100" />
                </div>
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Due Date *</label>
                <input formControlName="dueDate" type="date" class="ec-input" />
              </div>
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="showCreateModal.set(false)">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="creating()">
                  @if (creating()) { <span class="ec-spinner"></span> } Create
                </button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Grade Modal -->
      @if (showGradeModal()) {
        <div class="ec-modal-overlay" (click)="showGradeModal.set(false)">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>Grade Submission</h3>
              <button class="ec-modal-close" (click)="showGradeModal.set(false)">✕</button>
            </div>
            @if (selectedSubmission()) {
              <div class="grade-info">
                <p><strong>Student:</strong> {{ selectedSubmission()!.studentName ?? 'Student #'+selectedSubmission()!.studentId }}</p>
                <p><strong>Assessment:</strong> {{ selectedSubmission()!.assessmentTitle ?? 'Assessment #'+selectedSubmission()!.assessmentId }}</p>
                <a [href]="selectedSubmission()!.fileUri" target="_blank" class="file-link" style="margin-top:0.5rem;display:inline-block">
                  📎 View Submission
                </a>
              </div>
            }
            <form [formGroup]="gradeForm" (ngSubmit)="submitGrade()">
              <div class="ec-form-group" style="margin-top:1rem">
                <label class="ec-label">Score *</label>
                <input formControlName="score" type="number" class="ec-input" placeholder="Enter score" />
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Feedback</label>
                <textarea formControlName="feedback" class="ec-textarea" rows="3" placeholder="Optional feedback..."></textarea>
              </div>
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="showGradeModal.set(false)">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-gold" [disabled]="grading()">
                  @if (grading()) { <span class="ec-spinner"></span> } Submit Grade
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .page-header-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem; }
    .tabs { display: flex; gap: 0.5rem; margin-bottom: 1.75rem; }
    .tab-btn { padding: 0.5rem 1.25rem; border-radius: 20px; border: 1px solid var(--border-subtle); background: transparent; color: var(--text-secondary); font-size: 0.875rem; cursor: pointer; transition: all var(--transition-fast); }
    .tab-btn.active { background: var(--accent-primary); border-color: var(--accent-primary); color: #000; font-weight: 600; }
    .type-tag { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; padding: 0.15rem 0.5rem; border-radius: 4px; }
    .type-quiz     { background: rgba(59,130,246,0.15); color:#60a5fa; }
    .type-test     { background: rgba(239,68,68,0.15);  color:#f87171; }
    .type-assignment { background: rgba(245,158,11,0.15); color:#fbbf24; }
    .type-project  { background: rgba(16,185,129,0.15); color:#34d399; }
    .file-link { color: var(--accent-primary); font-size: 0.85rem; }
    .grade-info { background: var(--bg-surface); border-radius: var(--radius-md); padding: 0.875rem; margin-bottom: 0.5rem; font-size: 0.875rem; line-height: 1.8; }
  `]
})
export class TeacherAssessmentsComponent implements OnInit {
  tab = signal<'assessments' | 'grading'>('assessments');
  loading     = signal(true);
  courses     = signal<Course[]>([]);
  assessments = signal<Assessment[]>([]);
  allSubmissions = signal<Submission[]>([]);
  submissionsToGrade = signal<Submission[]>([]);
  pendingCount = signal(0);

  showCreateModal = signal(false);
  creating = signal(false);
  createError = signal('');

  showGradeModal = signal(false);
  selectedSubmission = signal<Submission | null>(null);
  grading = signal(false);

  types: AssessmentType[] = ['QUIZ', 'TEST', 'ASSIGNMENT', 'PROJECT'];
  createForm: FormGroup;
  gradeForm: FormGroup;

  constructor(private auth: AuthService, private assessSvc: AssessmentService, private courseSvc: CourseService, private fb: FormBuilder) {
    this.createForm = this.fb.group({
      courseId: ['', Validators.required], title: ['', Validators.required],
      description: [''], type: ['', Validators.required],
      maxScore: [100, [Validators.required, Validators.min(1)]],
      dueDate: ['', Validators.required]
    });
    this.gradeForm = this.fb.group({
      score: [null, [Validators.required, Validators.min(0)]], feedback: ['']
    });
  }

  statusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'ec-badge-success', DRAFT:'ec-badge-neutral', CLOSED:'ec-badge-warning', ARCHIVED:'ec-badge-danger' };
    return m[s] ?? 'ec-badge-neutral';
  }

  ngOnInit(): void {
    const teacherId = this.auth.getUserId();
    this.courseSvc.getAllCourses().subscribe({
      next: r => {
        if (r.success) {
          const myCourses = (r.data ?? []).filter(c => c.teacherId === teacherId);
          this.courses.set(myCourses);
          this.loadAssessments(myCourses.map(c => c.courseId));
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false)
    });
  }

  loadAssessments(courseIds: number[]): void {
    if (!courseIds.length) { this.loading.set(false); return; }
    const all: Assessment[] = [];
    let pending = courseIds.length;
    courseIds.forEach(id => {
      this.assessSvc.getByCourse(id).subscribe({
        next: r => {
          if (r.success) all.push(...(r.data ?? []));
          pending--;
          if (pending === 0) {
            this.assessments.set(all);
            this.loadPendingSubmissions(all.map(a => a.assessmentId));
          }
        },
        error: () => { pending--; if (pending === 0) this.loading.set(false); }
      });
    });
  }

  loadPendingSubmissions(assessmentIds: number[]): void {
    if (!assessmentIds.length) { this.loading.set(false); return; }
    const pending_subs: Submission[] = [];
    let pending = assessmentIds.length;
    assessmentIds.forEach(id => {
      this.assessSvc.getSubmissionsByAssessment(id).subscribe({
        next: r => {
          if (r.success) pending_subs.push(...(r.data ?? []).filter(s => s.status === 'SUBMITTED'));
          pending--;
          if (pending === 0) {
            this.submissionsToGrade.set(pending_subs);
            this.pendingCount.set(pending_subs.length);
            this.loading.set(false);
          }
        },
        error: () => { pending--; if (pending === 0) this.loading.set(false); }
      });
    });
  }

  openCreate(): void { this.createForm.reset({ maxScore: 100 }); this.createError.set(''); this.showCreateModal.set(true); }

  create(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.creating.set(true);
    this.assessSvc.create(this.createForm.value).subscribe({
      next: r => {
        this.creating.set(false);
        if (r.success) { this.assessments.update(a => [r.data, ...a]); this.showCreateModal.set(false); }
        else this.createError.set(r.message ?? 'Failed');
      },
      error: err => { this.creating.set(false); this.createError.set(err?.error?.message ?? 'Failed'); }
    });
  }

  activate(a: Assessment): void {
    this.assessSvc.activate(a.assessmentId).subscribe({
      next: r => {
        if (r.success) this.assessments.update(arr => arr.map(x => x.assessmentId === a.assessmentId ? { ...x, status: 'ACTIVE' as any } : x));
      }
    });
  }

  viewSubmissions(a: Assessment): void { this.tab.set('grading'); }

  openGrade(s: Submission): void {
    this.selectedSubmission.set(s);
    this.gradeForm.reset();
    this.showGradeModal.set(true);
  }

  submitGrade(): void {
    if (this.gradeForm.invalid) { this.gradeForm.markAllAsTouched(); return; }
    const s = this.selectedSubmission()!;
    this.grading.set(true);
    this.assessSvc.grade(s.submissionId, this.gradeForm.value).subscribe({
      next: r => {
        this.grading.set(false);
        if (r.success) {
          this.submissionsToGrade.update(arr => arr.filter(x => x.submissionId !== s.submissionId));
          this.pendingCount.update(n => n - 1);
          this.showGradeModal.set(false);
        }
      },
      error: () => this.grading.set(false)
    });
  }
}
