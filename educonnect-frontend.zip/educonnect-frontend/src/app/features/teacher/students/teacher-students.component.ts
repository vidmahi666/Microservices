import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService, ProgressService } from '../../../core/services/api.services';
import { Course, Enrollment, Progress } from '../../../core/models/models';

@Component({
  selector: 'app-teacher-students',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div>
      <div class="ec-page-header">
        <h2 class="ec-section-title">Students</h2>
        <p class="ec-section-sub">View enrolled students and their progress in your courses</p>
      </div>

      <!-- Course Selector -->
      <div class="course-selector">
        <label class="ec-label">Select Course</label>
        <select class="ec-select" style="max-width:360px" [(ngModel)]="selectedCourseId" (ngModelChange)="onCourseSelect($event)">
          <option [ngValue]="null">-- Select a course --</option>
          @for (c of courses(); track c.courseId) {
            <option [ngValue]="c.courseId">{{ c.title }}</option>
          }
        </select>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (!selectedCourseId) {
        <div class="ec-empty">
          <div class="ec-empty-icon">👥</div>
          <h3>Select a course</h3>
          <p>Choose a course above to view enrolled students</p>
        </div>
      } @else if (enrollments().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">📭</div>
          <h3>No students enrolled</h3>
          <p>No students have enrolled in this course yet</p>
        </div>
      } @else {
        <!-- Summary row -->
        <div class="summary-row">
          <div class="ec-stat-card">
            <div class="ec-stat-icon">👥</div>
            <div class="ec-stat-number">{{ enrollments().length }}</div>
            <div class="ec-stat-label">Enrolled Students</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">✅</div>
            <div class="ec-stat-number">{{ completedCount() }}</div>
            <div class="ec-stat-label">Completed</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">📊</div>
            <div class="ec-stat-number">{{ avgProgress() }}%</div>
            <div class="ec-stat-label">Avg. Progress</div>
          </div>
        </div>

        <div class="ec-table-wrap">
          <table class="ec-table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Enrolled Date</th>
                <th>Progress</th>
                <th>Completion</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              @for (e of enrollments(); track e.enrollmentId) {
                <tr>
                  <td>
                    <div style="display:flex;align-items:center;gap:0.75rem">
                      <div class="student-av">{{ (e.studentName ?? 'S').charAt(0).toUpperCase() }}</div>
                      <div>
                        <p style="font-weight:500">{{ e.studentName ?? 'Student #'+e.studentId }}</p>
                        <p style="font-size:0.75rem;color:var(--text-muted)">ID: {{ e.studentId }}</p>
                      </div>
                    </div>
                  </td>
                  <td>{{ e.enrollmentDate | date:'mediumDate' }}</td>
                  <td style="min-width:160px">
                    @if (getProgress(e.studentId); as p) {
                      <div>
                        <div style="display:flex;justify-content:space-between;margin-bottom:0.375rem;font-size:0.78rem">
                          <span style="color:var(--text-secondary)">Completion</span>
                          <span style="color:var(--teal-400);font-weight:600">{{ p.completionPercentage }}%</span>
                        </div>
                        <div class="ec-progress">
                          <div class="ec-progress-fill" [style.width.%]="p.completionPercentage"></div>
                        </div>
                      </div>
                    } @else {
                      <span style="color:var(--text-muted);font-size:0.82rem">No data</span>
                    }
                  </td>
                  <td>{{ getProgress(e.studentId)?.completionPercentage ?? 0 }}%</td>
                  <td>
                    @if (getProgress(e.studentId); as p) {
                      <span class="ec-badge" [class]="p.status === 'COMPLETED' ? 'ec-badge-success' : 'ec-badge-info'">
                        {{ p.status }}
                      </span>
                    } @else {
                      <span class="ec-badge ec-badge-neutral">—</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    </div>
  `,
  styles: [`
    .course-selector { margin-bottom: 2rem; }
    .summary-row { display: grid; grid-template-columns: repeat(3,1fr); gap: 1.25rem; margin-bottom: 2rem; }
    @media(max-width:768px) { .summary-row { grid-template-columns: 1fr; } }
    .student-av {
      width: 32px; height: 32px;
      background: linear-gradient(135deg, var(--teal-600), var(--teal-400));
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 0.8rem; font-weight: 700; color: #fff; flex-shrink: 0;
    }
  `]
})
export class TeacherStudentsComponent implements OnInit {
  courses     = signal<Course[]>([]);
  enrollments = signal<Enrollment[]>([]);
  progressMap = signal<Map<number, Progress>>(new Map());
  loading     = signal(false);
  completedCount = signal(0);
  avgProgress    = signal(0);
  selectedCourseId: number | null = null;

  constructor(
    private auth: AuthService,
    private courseSvc: CourseService,
    private enrollSvc: EnrollmentService,
    private progressSvc: ProgressService
  ) {}

  ngOnInit(): void {
    const teacherId = this.auth.getUserId();
    this.courseSvc.getAllCourses().subscribe({
      next: r => {
        if (r.success) {
          this.courses.set((r.data ?? []).filter(c => c.teacherId === teacherId));
        }
      }
    });
  }

  onCourseSelect(courseId: number | null): void {
    if (!courseId) return;
    this.loading.set(true);
    this.enrollSvc.getByCourse(courseId).subscribe({
      next: r => {
        if (r.success) {
          this.enrollments.set(r.data ?? []);
          this.loadProgress(courseId, (r.data ?? []).map(e => e.studentId));
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false)
    });
  }

  loadProgress(courseId: number, studentIds: number[]): void {
    this.progressSvc.getByCourse(courseId).subscribe({
      next: r => {
        if (r.success) {
          const map = new Map<number, Progress>();
          (r.data ?? []).forEach(p => map.set(p.studentId, p));
          this.progressMap.set(map);
          const values = Array.from(map.values());
          this.completedCount.set(values.filter(p => p.status === 'COMPLETED').length);
          if (values.length > 0) {
            const avg = values.reduce((a, b) => a + b.completionPercentage, 0) / values.length;
            this.avgProgress.set(Math.round(avg));
          }
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  getProgress(studentId: number): Progress | undefined {
    return this.progressMap().get(studentId);
  }
}
