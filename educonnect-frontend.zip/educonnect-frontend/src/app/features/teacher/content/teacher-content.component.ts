import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ContentService, CourseService } from '../../../core/services/api.services';
import { Content, Course, ContentType } from '../../../core/models/models';

@Component({
  selector: 'app-teacher-content',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div>
      <div class="page-header-row">
        <div>
          <h2 class="ec-section-title">Course Content</h2>
          <p class="ec-section-sub">Upload and manage learning materials</p>
        </div>
        <button class="ec-btn ec-btn-primary" (click)="openUpload()">+ Upload Content</button>
      </div>

      <!-- Course Filter -->
      <div class="filter-row">
        <select class="ec-select filter-select" [(ngModel)]="selectedCourseId" (ngModelChange)="onCourseChange($event)">
          <option [ngValue]="null">All Courses</option>
          @for (c of courses(); track c.courseId) {
            <option [ngValue]="c.courseId">{{ c.title }}</option>
          }
        </select>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (contents().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">🎬</div>
          <h3>No content uploaded yet</h3>
          <p>Upload videos, PDFs, and other materials for your students</p>
        </div>
      } @else {
        <div class="content-grid">
          @for (c of contents(); track c.contentId) {
            <div class="content-card ec-card">
              <div class="content-icon">{{ contentIcon(c.type) }}</div>
              <div class="content-meta-top">
                <span class="type-chip">{{ c.type }}</span>
                <span class="ec-badge" [class]="c.status === 'ACTIVE' ? 'ec-badge-success' : 'ec-badge-warning'">
                  {{ c.status }}
                </span>
              </div>
              <h4 class="content-title">{{ c.title }}</h4>
              <p class="content-desc">{{ c.description }}</p>
              <div class="content-footer">
                <span class="content-date">{{ c.uploadedAt | date:'mediumDate' }}</span>
                @if (c.status === 'ACTIVE') {
                  <button class="ec-btn ec-btn-danger ec-btn-sm" (click)="archive(c)">Archive</button>
                }
              </div>
            </div>
          }
        </div>
      }

      <!-- Upload Modal -->
      @if (showModal()) {
        <div class="ec-modal-overlay" (click)="closeModal()">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>Upload Content</h3>
              <button class="ec-modal-close" (click)="closeModal()">✕</button>
            </div>
            @if (formError()) {
              <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ formError() }}</span></div>
            }
            <form [formGroup]="form" (ngSubmit)="upload()">
              <div class="ec-form-group">
                <label class="ec-label">Course *</label>
                <select formControlName="courseId" class="ec-select" [class.error]="isInvalid('courseId')">
                  <option value="">Select course</option>
                  @for (c of courses(); track c.courseId) {
                    <option [value]="c.courseId">{{ c.title }}</option>
                  }
                </select>
                @if (isInvalid('courseId')) { <span class="ec-error-text">Course required</span> }
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Title *</label>
                <input formControlName="title" type="text" class="ec-input"
                  [class.error]="isInvalid('title')" placeholder="Content title" />
                @if (isInvalid('title')) { <span class="ec-error-text">Title required</span> }
              </div>
              <div class="ec-form-group">
                <label class="ec-label">Description</label>
                <textarea formControlName="description" class="ec-textarea" rows="2" placeholder="Brief description..."></textarea>
              </div>
              <div class="ec-grid-2">
                <div class="ec-form-group">
                  <label class="ec-label">Content Type *</label>
                  <select formControlName="type" class="ec-select">
                    <option value="">Select type</option>
                    @for (t of contentTypes; track t) {
                      <option [value]="t">{{ t }}</option>
                    }
                  </select>
                </div>
                <div class="ec-form-group">
                  <label class="ec-label">File / URL *</label>
                  <input formControlName="fileUri" type="text" class="ec-input"
                    [class.error]="isInvalid('fileUri')" placeholder="https://..." />
                  @if (isInvalid('fileUri')) { <span class="ec-error-text">URL required</span> }
                </div>
              </div>
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="closeModal()">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="ec-spinner"></span> }
                  Upload
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .page-header-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem; }
    .filter-row { margin-bottom: 1.5rem; }
    .filter-select { max-width: 280px; }

    .content-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(280px,1fr)); gap: 1.25rem; }
    .content-card { position: relative; }
    .content-icon { font-size: 2.5rem; margin-bottom: 0.75rem; }
    .content-meta-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; }
    .type-chip {
      font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;
      background: rgba(20,184,166,0.1); color: var(--teal-400); padding: 0.15rem 0.5rem; border-radius: 4px;
    }
    .content-title { font-size: 0.95rem; font-weight: 600; margin-bottom: 0.375rem; }
    .content-desc { font-size: 0.82rem; color: var(--text-secondary); line-height: 1.5; flex: 1; margin-bottom: 1rem; }
    .content-footer { display: flex; justify-content: space-between; align-items: center; margin-top: auto; }
    .content-date { font-size: 0.75rem; color: var(--text-muted); }
  `]
})
export class TeacherContentComponent implements OnInit {
  loading  = signal(true);
  courses  = signal<Course[]>([]);
  contents = signal<Content[]>([]);
  allContents = signal<Content[]>([]);
  showModal = signal(false);
  saving   = signal(false);
  formError = signal('');
  selectedCourseId: number | null = null;
  form: FormGroup;

  contentTypes: ContentType[] = ['VIDEO', 'PDF', 'QUIZ', 'DOCUMENT', 'PRESENTATION'];

  constructor(private auth: AuthService, private contentSvc: ContentService, private courseSvc: CourseService, private fb: FormBuilder) {
    this.form = this.fb.group({
      courseId:    ['', Validators.required],
      title:       ['', Validators.required],
      description: [''],
      type:        ['', Validators.required],
      fileUri:     ['', Validators.required],
    });
  }

  contentIcon(t: string): string {
    const m: Record<string,string> = { VIDEO:'🎬', PDF:'📄', QUIZ:'❓', DOCUMENT:'📝', PRESENTATION:'📊' };
    return m[t] ?? '📁';
  }

  isInvalid(f: string): boolean {
    const c = this.form.get(f);
    return !!(c?.invalid && c?.touched);
  }

  ngOnInit(): void {
    const teacherId = this.auth.getUserId();
    this.courseSvc.getAllCourses().subscribe({
      next: r => {
        if (r.success) {
          const myCourses = (r.data ?? []).filter(c => c.teacherId === teacherId);
          this.courses.set(myCourses);
          this.loadAllContent(myCourses.map(c => c.courseId));
        } else {
          this.loading.set(false);
        }
      },
      error: () => this.loading.set(false)
    });
  }

  loadAllContent(courseIds: number[]): void {
    if (courseIds.length === 0) { this.loading.set(false); return; }
    const all: Content[] = [];
    let pending = courseIds.length;
    courseIds.forEach(id => {
      this.contentSvc.getByCourse(id).subscribe({
        next: r => {
          if (r.success) all.push(...(r.data ?? []));
          pending--;
          if (pending === 0) {
            this.allContents.set(all);
            this.contents.set(all);
            this.loading.set(false);
          }
        },
        error: () => { pending--; if (pending === 0) this.loading.set(false); }
      });
    });
  }

  onCourseChange(id: number | null): void {
    if (!id) this.contents.set(this.allContents());
    else this.contents.set(this.allContents().filter(c => c.courseId === id));
  }

  openUpload(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  upload(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    this.contentSvc.upload(this.form.value).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.allContents.update(arr => [r.data, ...arr]);
          this.onCourseChange(this.selectedCourseId);
          this.closeModal();
        } else { this.formError.set(r.message ?? 'Upload failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Upload failed'); }
    });
  }

  archive(c: Content): void {
    this.contentSvc.updateStatus(c.contentId, 'ARCHIVED').subscribe({
      next: r => {
        if (r.success) {
          this.allContents.update(arr => arr.map(x => x.contentId === c.contentId ? { ...x, status: 'ARCHIVED' as any } : x));
          this.onCourseChange(this.selectedCourseId);
        }
      }
    });
  }
}
