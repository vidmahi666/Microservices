import { Component, signal } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="login-wrap">
      <div class="login-header">
        <h2>Welcome back</h2>
        <p>Sign in to your EduConnect account</p>
      </div>

      @if (errorMsg()) {
        <div class="ec-alert ec-alert-error">
          <span>⚠️</span>
          <span>{{ errorMsg() }}</span>
        </div>
      }

      <form [formGroup]="form" (ngSubmit)="onSubmit()">
        <div class="ec-form-group">
          <label class="ec-label">Email Address</label>
          <input
            formControlName="email"
            type="email"
            class="ec-input"
            [class.error]="isInvalid('email')"
            placeholder="you@example.com"
            autocomplete="email"
          />
          @if (isInvalid('email')) {
            <span class="ec-error-text">Valid email required</span>
          }
        </div>

        <div class="ec-form-group">
          <label class="ec-label">Password</label>
          <div class="input-eye">
            <input
              formControlName="password"
              [type]="showPassword() ? 'text' : 'password'"
              class="ec-input"
              [class.error]="isInvalid('password')"
              placeholder="Enter your password"
              autocomplete="current-password"
            />
            <button type="button" class="eye-btn" (click)="showPassword.set(!showPassword())">
              {{ showPassword() ? '🙈' : '👁️' }}
            </button>
          </div>
          @if (isInvalid('password')) {
            <span class="ec-error-text">Password required</span>
          }
        </div>

        <button
          type="submit"
          class="ec-btn ec-btn-primary submit-btn"
          [disabled]="loading()"
        >
          @if (loading()) {
            <span class="ec-spinner"></span>
            Signing in...
          } @else {
            Sign In
          }
        </button>
      </form>

      <div class="login-footer">
        <p>New student? <a routerLink="/auth/register">Create an account</a></p>
        <div class="demo-accounts">
          <p class="demo-title">Demo Accounts</p>
          <div class="demo-grid">
            @for (d of demoAccounts; track d.role) {
              <button class="demo-btn" (click)="fillDemo(d)">{{ d.role }}</button>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-wrap { animation: slideUp 0.3s ease; }
    .login-header { margin-bottom: 2rem; }
    .login-header h2 { font-family: var(--font-display); font-size: 1.75rem; font-weight: 700; }
    .login-header p { color: var(--text-secondary); margin-top: 0.25rem; }

    .input-eye { position: relative; }
    .input-eye .ec-input { padding-right: 2.75rem; }
    .eye-btn {
      position: absolute; right: 0.875rem; top: 50%;
      transform: translateY(-50%);
      background: none; border: none; cursor: pointer; font-size: 1rem;
    }

    .submit-btn { width: 100%; justify-content: center; padding: 0.875rem; font-size: 1rem; margin-top: 0.5rem; }

    .login-footer { margin-top: 1.5rem; text-align: center; }
    .login-footer p { color: var(--text-secondary); font-size: 0.9rem; }
    .login-footer a { color: var(--accent-primary); font-weight: 500; }

    .demo-accounts { margin-top: 1.5rem; padding: 1rem; background: var(--bg-surface); border-radius: var(--radius-md); }
    .demo-title { font-size: 0.78rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 0.75rem; }
    .demo-grid { display: flex; flex-wrap: wrap; gap: 0.5rem; justify-content: center; }
    .demo-btn {
      padding: 0.3rem 0.75rem;
      background: var(--bg-hover);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-sm);
      color: var(--text-secondary);
      font-size: 0.78rem;
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    .demo-btn:hover { border-color: var(--border-accent); color: var(--accent-primary); }
  `]
})
export class LoginComponent {
  form: FormGroup;
  loading = signal(false);
  errorMsg = signal('');
  showPassword = signal(false);

  demoAccounts = [
    { role: 'Admin',   email: 'admin@educonnect.com',   password: 'Admin@123' },
    { role: 'Student', email: 'alice@educonnect.com',   password: 'Alice@123' },
    { role: 'Teacher', email: 'teacher@educonnect.com', password: 'Teacher@123' },
  ];

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      email:    ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  isInvalid(field: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl?.invalid && ctrl?.touched);
  }

  fillDemo(d: { email: string; password: string }): void {
    this.form.patchValue({ email: d.email, password: d.password });
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading.set(true);
    this.errorMsg.set('');

    this.auth.login(this.form.value).subscribe({
      next: res => {
        this.loading.set(false);
        if (res.success && res.data) {
          this.auth.redirectAfterLogin(res.data.role);
        } else {
          this.errorMsg.set(res.message || 'Login failed');
        }
      },
      error: err => {
        this.loading.set(false);
        this.errorMsg.set(err?.error?.message || 'Invalid credentials. Please try again.');
      }
    });
  }
}
