import { Component, signal } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="reg-wrap">
      <div class="reg-header">
        <h2>Create Account</h2>
        <p>Join EduConnect as a student today</p>
      </div>

      @if (successMsg()) {
        <div class="ec-alert ec-alert-success">
          <span>✅</span>
          <span>{{ successMsg() }}</span>
        </div>
      }
      @if (errorMsg()) {
        <div class="ec-alert ec-alert-error">
          <span>⚠️</span>
          <span>{{ errorMsg() }}</span>
        </div>
      }

      <form [formGroup]="form" (ngSubmit)="onSubmit()">
        <div class="ec-form-group">
          <label class="ec-label">Full Name</label>
          <input formControlName="name" type="text" class="ec-input"
            [class.error]="isInvalid('name')" placeholder="Your full name" />
          @if (isInvalid('name')) {
            <span class="ec-error-text">Name is required</span>
          }
        </div>

        <div class="ec-form-group">
          <label class="ec-label">Email Address</label>
          <input formControlName="email" type="email" class="ec-input"
            [class.error]="isInvalid('email')" placeholder="you@example.com" />
          @if (isInvalid('email')) {
            <span class="ec-error-text">Valid email required</span>
          }
        </div>

        <div class="ec-form-group">
          <label class="ec-label">Password</label>
          <input formControlName="password" type="password" class="ec-input"
            [class.error]="isInvalid('password')" placeholder="Min. 8 characters" />
          @if (isInvalid('password')) {
            <span class="ec-error-text">Password must be at least 8 characters</span>
          }
        </div>

        <div class="role-info">
          <span class="role-badge">🎓 Student Account</span>
          <span class="role-note">All new registrations are for students. Staff accounts are created by admins.</span>
        </div>

        <button type="submit" class="ec-btn ec-btn-primary submit-btn" [disabled]="loading()">
          @if (loading()) {
            <span class="ec-spinner"></span>
            Creating account...
          } @else {
            Create Account
          }
        </button>
      </form>

      <div class="reg-footer">
        <p>Already have an account? <a routerLink="/auth/login">Sign in</a></p>
      </div>
    </div>
  `,
  styles: [`
    .reg-wrap { animation: slideUp 0.3s ease; }
    .reg-header { margin-bottom: 2rem; }
    .reg-header h2 { font-family: var(--font-display); font-size: 1.75rem; font-weight: 700; }
    .reg-header p { color: var(--text-secondary); margin-top: 0.25rem; }

    .role-info {
      display: flex;
      flex-direction: column;
      gap: 0.375rem;
      background: rgba(20,184,166,0.06);
      border: 1px solid var(--border-accent);
      border-radius: var(--radius-md);
      padding: 0.875rem 1rem;
      margin-bottom: 1.25rem;
    }
    .role-badge { font-size: 0.85rem; font-weight: 600; color: var(--teal-400); }
    .role-note { font-size: 0.8rem; color: var(--text-secondary); }

    .submit-btn { width: 100%; justify-content: center; padding: 0.875rem; font-size: 1rem; }
    .reg-footer { margin-top: 1.5rem; text-align: center; }
    .reg-footer p { color: var(--text-secondary); font-size: 0.9rem; }
    .reg-footer a { color: var(--accent-primary); font-weight: 500; }
  `]
})
export class RegisterComponent {
  form: FormGroup;
  loading  = signal(false);
  errorMsg = signal('');
  successMsg = signal('');

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      name:     ['', Validators.required],
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }

  isInvalid(field: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl?.invalid && ctrl?.touched);
  }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading.set(true);
    this.errorMsg.set('');

    this.auth.register({ ...this.form.value, role: 'STUDENT' }).subscribe({
      next: res => {
        this.loading.set(false);
        if (res.success) {
          this.successMsg.set('Account created! Redirecting to login...');
          setTimeout(() => this.router.navigate(['/auth/login']), 1800);
        } else {
          this.errorMsg.set(res.message || 'Registration failed');
        }
      },
      error: err => {
        this.loading.set(false);
        this.errorMsg.set(err?.error?.message || 'Registration failed. Email may already be in use.');
      }
    });
  }
}
