import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { ProgressService } from '../../../core/services/api.services';
import { Progress } from '../../../core/models/models';

@Component({
  selector: 'app-student-progress',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div>
      <div class="ec-page-header">
        <h2 class="ec-section-title">My Progress</h2>
        <p class="ec-section-sub">Track your learning completion across all courses</p>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else {
        <!-- Summary row -->
        <div class="summary-row">
          <div class="ec-stat-card">
            <div class="ec-stat-icon">📚</div>
            <div class="ec-stat-number">{{ progressList().length }}</div>
            <div class="ec-stat-label">Total Courses</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">✅</div>
            <div class="ec-stat-number">{{ completed() }}</div>
            <div class="ec-stat-label">Completed</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">🔥</div>
            <div class="ec-stat-number">{{ inProgress() }}</div>
            <div class="ec-stat-label">In Progress</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">📊</div>
            <div class="ec-stat-number">{{ overallPct() }}%</div>
            <div class="ec-stat-label">Overall Progress</div>
          </div>
        </div>

        @if (progressList().length === 0) {
          <div class="ec-empty">
            <div class="ec-empty-icon">📊</div>
            <h3>No progress data</h3>
            <p>Enroll in courses to start tracking your progress</p>
          </div>
        } @else {
          <div class="progress-cards">
            @for (p of progressList(); track p.progressId) {
              <div class="ec-card progress-card">
                <div class="p-header">
                  <div>
                    <h4 class="p-title">{{ p.courseTitle ?? 'Course #'+p.courseId }}</h4>
                    <span class="p-sub">Last updated: {{ p.lastUpdated | date:'mediumDate' }}</span>
                  </div>
                  <span class="ec-badge" [class]="p.status === 'COMPLETED' ? 'ec-badge-success' : 'ec-badge-info'">
                    {{ p.status | titlecase }}
                  </span>
                </div>

                <div class="p-body">
                  <div class="pct-row">
                    <span class="pct-label">Completion</span>
                    <span class="pct-val">{{ p.completionPercentage }}%</span>
                  </div>
                  <div class="ec-progress p-bar">
                    <div class="ec-progress-fill" [style.width.%]="p.completionPercentage"
                      [class.gold]="p.completionPercentage === 100"></div>
                  </div>
                </div>

                @if (p.completionPercentage === 100) {
                  <div class="complete-ribbon">🏆 Course Completed!</div>
                }
              </div>
            }
          </div>
        }
      }
    </div>
  `,
  styles: [`
    .summary-row { display: grid; grid-template-columns: repeat(4,1fr); gap: 1.25rem; margin-bottom: 2rem; }
    @media (max-width:1024px) { .summary-row { grid-template-columns: repeat(2,1fr); } }

    .progress-cards { display: flex; flex-direction: column; gap: 1.25rem; }
    .progress-card {}

    .p-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; }
    .p-title { font-size: 1rem; font-weight: 600; margin-bottom: 0.2rem; }
    .p-sub { font-size: 0.78rem; color: var(--text-muted); }

    .p-body {}
    .pct-row { display: flex; justify-content: space-between; margin-bottom: 0.5rem; }
    .pct-label { font-size: 0.82rem; color: var(--text-secondary); }
    .pct-val { font-size: 0.875rem; font-weight: 700; color: var(--teal-400); }
    .p-bar { height: 8px; }
    .ec-progress-fill.gold { background: linear-gradient(90deg, var(--gold-600), var(--gold-400)); }

    .complete-ribbon {
      margin-top: 0.875rem;
      padding: 0.5rem 1rem;
      background: rgba(245,158,11,0.1);
      border: 1px solid rgba(245,158,11,0.25);
      border-radius: var(--radius-sm);
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--gold-400);
      text-align: center;
    }
  `]
})
export class StudentProgressComponent implements OnInit {
  loading      = signal(true);
  progressList = signal<Progress[]>([]);
  completed    = signal(0);
  inProgress   = signal(0);
  overallPct   = signal(0);

  constructor(private auth: AuthService, private progressSvc: ProgressService) {}

  ngOnInit(): void {
    const sId = this.auth.getUserId() ?? 1;
    this.progressSvc.getByStudent(sId).subscribe({
      next: r => {
        if (r.success) {
          const list = r.data ?? [];
          this.progressList.set(list);
          this.completed.set(list.filter(p => p.status === 'COMPLETED').length);
          this.inProgress.set(list.filter(p => p.status === 'IN_PROGRESS').length);
          if (list.length > 0) {
            const avg = list.reduce((a, b) => a + b.completionPercentage, 0) / list.length;
            this.overallPct.set(Math.round(avg));
          }
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }
}
