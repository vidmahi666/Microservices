import { Routes } from '@angular/router';
import { ShellComponent } from '../../shared/components/shell/shell.component';

export const STUDENT_ROUTES: Routes = [
  {
    path: '',
    component: ShellComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/student-dashboard.component').then(m => m.StudentDashboardComponent)
      },
      {
        path: 'courses',
        loadComponent: () => import('./courses/student-courses.component').then(m => m.StudentCoursesComponent)
      },
      {
        path: 'assessments',
        loadComponent: () => import('./assessments/student-assessments.component').then(m => m.StudentAssessmentsComponent)
      },
      {
        path: 'progress',
        loadComponent: () => import('./progress/student-progress.component').then(m => m.StudentProgressComponent)
      },
      {
        path: 'profile',
        loadComponent: () => import('./profile/student-profile.component').then(m => m.StudentProfileComponent)
      }
    ]
  }
];
