import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AssessmentService, EnrollmentService, CourseService } from '../../../core/services/api.services';
import { Assessment, Submission, Course } from '../../../core/models/models';

@Component({
  selector: 'app-student-assessments',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div>
      <div class="ec-page-header">
        <h2 class="ec-section-title">Assessments</h2>
        <p class="ec-section-sub">View and submit quizzes, tests, and assignments</p>
      </div>

      <!-- Tabs -->
      <div class="tabs">
        <button class="tab-btn" [class.active]="tab() === 'available'" (click)="tab.set('available')">Available</button>
        <button class="tab-btn" [class.active]="tab() === 'submitted'" (click)="tab.set('submitted')">
          My Submissions ({{ submissions().length }})
        </button>
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      }

      <!-- Available Assessments -->
      @if (!loading() && tab() === 'available') {
        @if (assessments().length === 0) {
          <div class="ec-empty">
            <div class="ec-empty-icon">📝</div>
            <h3>No assessments available</h3>
            <p>Enroll in courses to see assessments</p>
          </div>
        } @else {
          <div class="assessment-grid">
            @for (a of assessments(); track a.assessmentId) {
              <div class="ec-card assessment-card">
                <div class="a-top">
                  <span class="type-chip type-{{ a.type.toLowerCase() }}">{{ a.type }}</span>
                  <span class="ec-badge" [class]="statusBadge(a.status)">{{ a.status }}</span>
                </div>
                <h4 class="a-title">{{ a.title }}</h4>
                <p class="a-desc">{{ a.description }}</p>
                <div class="a-meta">
                  <span>📚 {{ a.courseTitle ?? 'Course #'+a.courseId }}</span>
                  <span>🏆 Max: {{ a.maxScore }} pts</span>
                  <span>📅 Due: {{ a.dueDate | date:'mediumDate' }}</span>
                </div>
                <div class="a-footer">
                  @if (submittedSet().has(a.assessmentId)) {
                    <span class="submitted-badge">✅ Submitted</span>
                  } @else if (a.status === 'ACTIVE') {
                    <button class="ec-btn ec-btn-primary ec-btn-sm" (click)="openSubmit(a)">
                      Submit
                    </button>
                  } @else {
                    <span style="color:var(--text-muted);font-size:0.82rem;">Not active</span>
                  }
                </div>
              </div>
            }
          </div>
        }
      }

      <!-- My Submissions -->
      @if (!loading() && tab() === 'submitted') {
        @if (submissions().length === 0) {
          <div class="ec-empty">
            <div class="ec-empty-icon">📋</div>
            <h3>No submissions yet</h3>
          </div>
        } @else {
          <div class="ec-table-wrap">
            <table class="ec-table">
              <thead>
                <tr>
                  <th>Assessment</th>
                  <th>Submitted</th>
                  <th>Score</th>
                  <th>Feedback</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                @for (s of submissions(); track s.submissionId) {
                  <tr>
                    <td>{{ s.assessmentTitle ?? 'Assessment #'+s.assessmentId }}</td>
                    <td>{{ s.submittedAt | date:'mediumDate' }}</td>
                    <td>
                      @if (s.score !== null && s.score !== undefined) {
                        <strong style="color:var(--gold-400)">{{ s.score }} pts</strong>
                      } @else {
                        <span style="color:var(--text-muted)">—</span>
                      }
                    </td>
                    <td style="max-width:200px;font-size:0.82rem;color:var(--text-secondary)">
                      {{ s.feedback ?? '—' }}
                    </td>
                    <td>
                      <span class="ec-badge" [class]="s.status === 'GRADED' ? 'ec-badge-success' : 'ec-badge-warning'">
                        {{ s.status }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Submit Modal -->
      @if (showModal()) {
        <div class="ec-modal-overlay" (click)="closeModal()">
          <div class="ec-modal" (click)="$event.stopPropagation()">
            <div class="ec-modal-header">
              <h3>Submit Assessment</h3>
              <button class="ec-modal-close" (click)="closeModal()">✕</button>
            </div>
            @if (selectedAssessment()) {
              <div class="modal-info">
                <p><strong>{{ selectedAssessment()!.title }}</strong></p>
                <p style="color:var(--text-secondary);font-size:0.85rem">Max Score: {{ selectedAssessment()!.maxScore }} pts</p>
              </div>
            }
            <form [formGroup]="submitForm" (ngSubmit)="submitAssessment()">
              <div class="ec-form-group">
                <label class="ec-label">Submission File URL</label>
                <input formControlName="fileUri" type="url" class="ec-input"
                  placeholder="https://drive.google.com/file/..." />
                <span class="ec-error-text" *ngIf="submitForm.get('fileUri')?.invalid && submitForm.get('fileUri')?.touched">
                  Valid URL required
                </span>
              </div>
              @if (submitError()) {
                <div class="ec-alert ec-alert-error"><span>⚠️</span><span>{{ submitError() }}</span></div>
              }
              <div style="display:flex;gap:0.75rem;justify-content:flex-end">
                <button type="button" class="ec-btn ec-btn-secondary" (click)="closeModal()">Cancel</button>
                <button type="submit" class="ec-btn ec-btn-primary" [disabled]="submitting()">
                  @if (submitting()) { <span class="ec-spinner"></span> }
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .tabs { display: flex; gap: 0.5rem; margin-bottom: 1.75rem; }
    .tab-btn {
      padding: 0.5rem 1.25rem; border-radius: 20px;
      border: 1px solid var(--border-subtle); background: transparent;
      color: var(--text-secondary); font-size: 0.875rem; cursor: pointer;
      transition: all var(--transition-fast);
    }
    .tab-btn.active { background: var(--accent-primary); border-color: var(--accent-primary); color: #000; font-weight: 600; }

    .assessment-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(320px,1fr)); gap: 1.25rem; }
    .assessment-card { display: flex; flex-direction: column; }
    .a-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem; }
    .type-chip {
      font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;
      padding: 0.2rem 0.6rem; border-radius: 4px;
    }
    .type-quiz     { background: rgba(59,130,246,0.15); color: #60a5fa; }
    .type-test     { background: rgba(239,68,68,0.15);  color: #f87171; }
    .type-assignment { background: rgba(245,158,11,0.15); color: #fbbf24; }
    .type-project  { background: rgba(16,185,129,0.15); color: #34d399; }

    .a-title { font-size: 1rem; font-weight: 600; margin-bottom: 0.4rem; }
    .a-desc  { font-size: 0.83rem; color: var(--text-secondary); flex: 1; margin-bottom: 0.875rem; line-height: 1.5; }
    .a-meta  { display: flex; flex-wrap: wrap; gap: 0.625rem; font-size: 0.78rem; color: var(--text-muted); margin-bottom: 1rem; }
    .a-footer { display: flex; justify-content: flex-end; margin-top: auto; }
    .submitted-badge { font-size: 0.85rem; color: var(--success); font-weight: 500; }

    .modal-info {
      background: var(--bg-surface); border-radius: var(--radius-md);
      padding: 0.875rem; margin-bottom: 1.25rem;
    }
  `]
})
export class StudentAssessmentsComponent implements OnInit {
  tab         = signal<'available' | 'submitted'>('available');
  loading     = signal(true);
  assessments = signal<Assessment[]>([]);
  submissions = signal<Submission[]>([]);
  submittedSet = signal<Set<number>>(new Set());
  showModal   = signal(false);
  selectedAssessment = signal<Assessment | null>(null);
  submitting  = signal(false);
  submitError = signal('');
  submitForm: FormGroup;

  constructor(
    private auth: AuthService,
    private assessSvc: AssessmentService,
    private enrollSvc: EnrollmentService,
    private fb: FormBuilder
  ) {
    this.submitForm = this.fb.group({ fileUri: ['', [Validators.required, Validators.pattern('https?://.+')]] });
  }

  statusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'ec-badge-success', DRAFT:'ec-badge-neutral', CLOSED:'ec-badge-warning', ARCHIVED:'ec-badge-danger' };
    return m[s] ?? 'ec-badge-neutral';
  }

  ngOnInit(): void {
    const sId = this.auth.getUserId() ?? 1;
    // Load submissions first
    this.assessSvc.getSubmissionsByStudent(sId).subscribe({
      next: r => {
        if (r.success) {
          const subs = r.data ?? [];
          this.submissions.set(subs);
          this.submittedSet.set(new Set(subs.map(s => s.assessmentId)));
        }
      }
    });

    // Load enrolled courses, then fetch assessments per course
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => {
        if (r.success && r.data) {
          const courseIds = [...new Set(r.data.map(e => e.courseId))];
          const allAssessments: Assessment[] = [];
          let pending = courseIds.length;
          if (pending === 0) { this.loading.set(false); return; }
          courseIds.forEach(cId => {
            this.assessSvc.getByCourse(cId).subscribe({
              next: ar => {
                if (ar.success) allAssessments.push(...(ar.data ?? []));
                pending--;
                if (pending === 0) {
                  this.assessments.set(allAssessments);
                  this.loading.set(false);
                }
              },
              error: () => { pending--; if (pending === 0) this.loading.set(false); }
            });
          });
        } else {
          this.loading.set(false);
        }
      },
      error: () => this.loading.set(false)
    });
  }

  openSubmit(a: Assessment): void {
    this.selectedAssessment.set(a);
    this.submitForm.reset();
    this.submitError.set('');
    this.showModal.set(true);
  }

  closeModal(): void { this.showModal.set(false); }

  submitAssessment(): void {
    if (this.submitForm.invalid) { this.submitForm.markAllAsTouched(); return; }
    const studentId = this.auth.getUserId() ?? 1;
    const a = this.selectedAssessment()!;
    this.submitting.set(true);
    this.assessSvc.submit({ assessmentId: a.assessmentId, studentId, fileUri: this.submitForm.value.fileUri }).subscribe({
      next: r => {
        this.submitting.set(false);
        if (r.success) {
          this.submittedSet.update(s => { s.add(a.assessmentId); return new Set(s); });
          this.submissions.update(arr => [r.data, ...arr]);
          this.closeModal();
        } else {
          this.submitError.set(r.message ?? 'Submission failed');
        }
      },
      error: err => {
        this.submitting.set(false);
        this.submitError.set(err?.error?.message ?? 'Submission failed');
      }
    });
  }
}
