import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ReportService, AdminService, CourseService } from '../../../core/services/api.services';
import { DashboardMetrics, User } from '../../../core/models/models';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="dashboard">
      <!-- Header -->
      <div class="welcome-banner">
        <div>
          <h1>Admin Console 🛡️</h1>
          <p>System overview and management — full platform control</p>
        </div>
        <div style="display:flex;gap:0.75rem">
          <a routerLink="/admin/users" class="ec-btn ec-btn-secondary">Manage Users</a>
          <a routerLink="/admin/reports" class="ec-btn ec-btn-primary">View Reports</a>
        </div>
      </div>

      <!-- Metrics -->
      @if (loadingMetrics()) {
        <div style="display:flex;justify-content:center;padding:3rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else {
        <div class="metrics-grid">
          <div class="ec-stat-card metric-teal">
            <div class="ec-stat-icon">👥</div>
            <div class="ec-stat-number">{{ metrics()?.totalStudents ?? 0 }}</div>
            <div class="ec-stat-label">Total Students</div>
          </div>
          <div class="ec-stat-card metric-gold">
            <div class="ec-stat-icon">📚</div>
            <div class="ec-stat-number">{{ metrics()?.totalCourses ?? 0 }}</div>
            <div class="ec-stat-label">Total Courses</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">📋</div>
            <div class="ec-stat-number">{{ metrics()?.totalEnrollments ?? 0 }}</div>
            <div class="ec-stat-label">Enrollments</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">📝</div>
            <div class="ec-stat-number">{{ metrics()?.totalAssessments ?? 0 }}</div>
            <div class="ec-stat-label">Assessments</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">🔥</div>
            <div class="ec-stat-number">{{ metrics()?.activeStudents ?? 0 }}</div>
            <div class="ec-stat-label">Active Students</div>
          </div>
          <div class="ec-stat-card">
            <div class="ec-stat-icon">✅</div>
            <div class="ec-stat-number">{{ metrics()?.completionRate ?? 0 }}%</div>
            <div class="ec-stat-label">Completion Rate</div>
          </div>
        </div>
      }

      <div class="bottom-grid">
        <!-- Recent Users -->
        <div class="ec-card">
          <div class="card-row">
            <div>
              <div class="ec-section-title">Recent Users</div>
              <div class="ec-section-sub">Newly registered accounts</div>
            </div>
            <a routerLink="/admin/users" class="ec-btn ec-btn-secondary ec-btn-sm">View All</a>
          </div>
          @if (recentUsers().length === 0) {
            <div class="ec-empty" style="padding:2rem 0">
              <div class="ec-empty-icon">👥</div>
              <h3>No users yet</h3>
            </div>
          } @else {
            @for (u of recentUsers(); track u.userId) {
              <div class="user-row">
                <div class="user-left">
                  <div class="u-av">{{ u.name.charAt(0) }}</div>
                  <div>
                    <p class="u-name">{{ u.name }}</p>
                    <p class="u-email">{{ u.email }}</p>
                  </div>
                </div>
                <div style="display:flex;gap:0.5rem;align-items:center">
                  <span class="ec-badge" [class]="roleBadge(u.role)">{{ u.role }}</span>
                  <span class="ec-badge" [class]="u.status === 'ACTIVE' ? 'ec-badge-success' : 'ec-badge-danger'">
                    {{ u.status }}
                  </span>
                </div>
              </div>
            }
          }
        </div>

        <!-- Quick Actions -->
        <div class="ec-card">
          <div class="ec-section-title">Quick Actions</div>
          <div class="ec-section-sub">Common administrative tasks</div>
          <div class="action-grid">
            <a routerLink="/admin/users" class="action-item">
              <span class="action-icon">👥</span>
              <span class="action-label">User Management</span>
              <span class="action-desc">Manage roles & access</span>
            </a>
            <a routerLink="/admin/courses" class="action-item">
              <span class="action-icon">📚</span>
              <span class="action-label">All Courses</span>
              <span class="action-desc">View all platform courses</span>
            </a>
            <a routerLink="/admin/compliance" class="action-item">
              <span class="action-icon">✅</span>
              <span class="action-label">Compliance</span>
              <span class="action-desc">Policy & compliance records</span>
            </a>
            <a routerLink="/admin/audits" class="action-item">
              <span class="action-icon">🔍</span>
              <span class="action-label">Audits</span>
              <span class="action-desc">Formal audit management</span>
            </a>
            <a routerLink="/admin/reports" class="action-item">
              <span class="action-icon">📊</span>
              <span class="action-label">Reports</span>
              <span class="action-desc">Analytics & reporting</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { animation: fadeIn 0.3s ease; }
    .welcome-banner {
      display: flex; align-items: center; justify-content: space-between;
      background: linear-gradient(135deg, var(--bg-card), rgba(59,130,246,0.04));
      border: 1px solid var(--border-subtle); border-radius: var(--radius-xl);
      padding: 2rem; margin-bottom: 2rem;
    }
    .welcome-banner h1 { font-size: 1.75rem; margin-bottom: 0.25rem; }
    .welcome-banner p { color: var(--text-secondary); }

    .metrics-grid { display: grid; grid-template-columns: repeat(6,1fr); gap: 1.25rem; margin-bottom: 2rem; }
    @media(max-width:1280px) { .metrics-grid { grid-template-columns: repeat(3,1fr); } }
    @media(max-width:768px)  { .metrics-grid { grid-template-columns: repeat(2,1fr); } }

    .metric-teal::before { background: linear-gradient(90deg, var(--teal-500), transparent); }
    .metric-gold::before { background: linear-gradient(90deg, var(--gold-500), transparent); }

    .bottom-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    @media(max-width:900px) { .bottom-grid { grid-template-columns: 1fr; } }

    .card-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.25rem; }

    .user-row {
      display: flex; align-items: center; justify-content: space-between;
      padding: 0.75rem 0; border-bottom: 1px solid rgba(255,255,255,0.03);
    }
    .user-row:last-child { border-bottom: none; }
    .user-left { display: flex; align-items: center; gap: 0.75rem; }
    .u-av {
      width: 32px; height: 32px;
      background: linear-gradient(135deg, var(--bg-hover), var(--border-soft));
      border-radius: 50%; display: flex; align-items: center; justify-content: center;
      font-size: 0.8rem; font-weight: 700; color: var(--text-primary); flex-shrink: 0;
    }
    .u-name { font-size: 0.875rem; font-weight: 500; margin-bottom: 0.1rem; }
    .u-email { font-size: 0.75rem; color: var(--text-muted); }

    .action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; }
    .action-item {
      display: flex; flex-direction: column; gap: 0.25rem;
      padding: 1rem; background: var(--bg-surface);
      border: 1px solid var(--border-subtle); border-radius: var(--radius-md);
      text-decoration: none; transition: all var(--transition-fast); cursor: pointer;
    }
    .action-item:hover { border-color: var(--border-accent); background: var(--bg-hover); }
    .action-icon { font-size: 1.35rem; }
    .action-label { font-size: 0.85rem; font-weight: 600; color: var(--text-primary); }
    .action-desc  { font-size: 0.75rem; color: var(--text-muted); }
  `]
})
export class AdminDashboardComponent implements OnInit {
  loadingMetrics = signal(true);
  metrics    = signal<DashboardMetrics | null>(null);
  recentUsers = signal<User[]>([]);

  constructor(
    private auth: AuthService,
    private reportSvc: ReportService,
    private adminSvc: AdminService,
  ) {}

  roleBadge(r: string): string {
    const m: Record<string,string> = {
      STUDENT: 'ec-badge-teal', TEACHER: 'ec-badge-gold',
      ADMIN: 'ec-badge-danger', PROGRAM_MANAGER: 'ec-badge-info',
      COMPLIANCE_OFFICER: 'ec-badge-warning', GOVERNMENT_AUDITOR: 'ec-badge-neutral'
    };
    return m[r] ?? 'ec-badge-neutral';
  }

  ngOnInit(): void {
    this.reportSvc.getDashboardMetrics().subscribe({
      next: r => { if (r.success) this.metrics.set(r.data); this.loadingMetrics.set(false); },
      error: () => this.loadingMetrics.set(false)
    });

    this.adminSvc.getAllUsers().subscribe({
      next: r => { if (r.success) this.recentUsers.set((r.data ?? []).slice(0, 6)); }
    });
  }
}
