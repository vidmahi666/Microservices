import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseService } from '../../../core/services/api.services';
import { Course } from '../../../core/models/models';

@Component({
  selector: 'app-admin-courses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div>
      <div class="ec-page-header">
        <h2 class="ec-section-title">All Courses</h2>
        <p class="ec-section-sub">View and monitor all courses on the platform</p>
      </div>

      <!-- Status Filter -->
      <div class="filter-bar">
        @for (f of statusFilters; track f) {
          <button class="filter-chip" [class.active]="statusFilter() === f" (click)="setStatus(f)">{{ f }}</button>
        }
      </div>

      <div style="margin-bottom:1.25rem">
        <input type="text" class="ec-input" style="max-width:360px" placeholder="Search courses..."
          [(ngModel)]="searchQ" (ngModelChange)="applyFilter()" />
      </div>

      @if (loading()) {
        <div style="text-align:center;padding:4rem"><span class="ec-spinner ec-spinner-lg"></span></div>
      } @else if (filtered().length === 0) {
        <div class="ec-empty">
          <div class="ec-empty-icon">📚</div>
          <h3>No courses found</h3>
        </div>
      } @else {
        <div class="ec-table-wrap">
          <table class="ec-table">
            <thead>
              <tr><th>Title</th><th>Teacher</th><th>Start</th><th>End</th><th>Status</th></tr>
            </thead>
            <tbody>
              @for (c of filtered(); track c.courseId) {
                <tr>
                  <td>
                    <div>
                      <p style="font-weight:500">{{ c.title }}</p>
                      <p style="font-size:0.78rem;color:var(--text-muted)">{{ c.description | slice:0:50 }}...</p>
                    </div>
                  </td>
                  <td style="font-size:0.85rem">{{ c.teacherName ?? 'Teacher #'+c.teacherId }}</td>
                  <td>{{ c.startDate | date:'mediumDate' }}</td>
                  <td>{{ c.endDate | date:'mediumDate' }}</td>
                  <td><span class="ec-badge" [class]="statusBadge(c.status)">{{ c.status }}</span></td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        <p style="margin-top:1rem;font-size:0.82rem;color:var(--text-muted)">
          Showing {{ filtered().length }} of {{ courses().length }} courses
        </p>
      }
    </div>
  `,
  styles: [`
    .filter-bar { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.25rem; }
    .filter-chip { padding: 0.35rem 0.875rem; border-radius: 20px; border: 1px solid var(--border-subtle); background: transparent; color: var(--text-secondary); font-size: 0.8rem; cursor: pointer; transition: all var(--transition-fast); }
    .filter-chip.active { background: rgba(20,184,166,0.15); border-color: var(--border-accent); color: var(--teal-400); }
  `]
})
export class AdminCoursesComponent implements OnInit {
  loading = signal(true);
  courses  = signal<Course[]>([]);
  filtered = signal<Course[]>([]);
  statusFilter = signal('ALL');
  searchQ = '';
  statusFilters = ['ALL', 'DRAFT', 'ACTIVE', 'COMPLETED', 'ARCHIVED'];

  constructor(private courseSvc: CourseService) {}

  statusBadge(s: string): string {
    const m: Record<string,string> = { ACTIVE:'ec-badge-success', DRAFT:'ec-badge-neutral', COMPLETED:'ec-badge-info', ARCHIVED:'ec-badge-warning' };
    return m[s] ?? 'ec-badge-neutral';
  }

  ngOnInit(): void {
    this.courseSvc.getAllCourses().subscribe({
      next: r => { if (r.success) { this.courses.set(r.data ?? []); this.applyFilter(); } this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  setStatus(s: string): void { this.statusFilter.set(s); this.applyFilter(); }

  applyFilter(): void {
    let list = this.courses();
    if (this.statusFilter() !== 'ALL') list = list.filter(c => c.status === this.statusFilter());
    if (this.searchQ) list = list.filter(c => c.title.toLowerCase().includes(this.searchQ.toLowerCase()));
    this.filtered.set(list);
  }
}
