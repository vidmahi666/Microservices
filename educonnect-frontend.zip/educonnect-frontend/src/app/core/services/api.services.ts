import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ApiResponse, User, Student, Course, CourseRequest, Enrollment, EnrollmentRequest,
  Progress, Content, ContentRequest, Assessment, AssessmentRequest,
  Submission, SubmissionRequest, GradeRequest, Notification, DashboardMetrics,
  ComplianceRecord, Audit
} from '../models/models';

// ── Admin / User Management ──────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class AdminService {
  private base = environment.adminServiceUrl;

  constructor(private http: HttpClient) {}

  getAllUsers(): Observable<ApiResponse<User[]>> {
    return this.http.get<ApiResponse<User[]>>(`${this.base}/users`);
  }

  getUserById(id: number): Observable<ApiResponse<User>> {
    return this.http.get<ApiResponse<User>>(`${this.base}/users/${id}`);
  }

  deactivateUser(id: number): Observable<ApiResponse<void>> {
    return this.http.patch<ApiResponse<void>>(`${this.base}/users/${id}/deactivate`, {});
  }

  activateUser(id: number): Observable<ApiResponse<void>> {
    return this.http.patch<ApiResponse<void>>(`${this.base}/users/${id}/activate`, {});
  }

  createTeacher(payload: {name: string; email: string; password: string}): Observable<ApiResponse<User>> {
    return this.http.post<ApiResponse<User>>(`${this.base}/teachers`, payload);
  }

  getAllTeachers(): Observable<ApiResponse<User[]>> {
    return this.http.get<ApiResponse<User[]>>(`${this.base}/teachers`);
  }

  createProgramManager(payload: {name: string; email: string; password: string}): Observable<ApiResponse<User>> {
    return this.http.post<ApiResponse<User>>(`${this.base}/program-managers`, payload);
  }

  createComplianceOfficer(payload: {name: string; email: string; password: string}): Observable<ApiResponse<User>> {
    return this.http.post<ApiResponse<User>>(`${this.base}/compliance-officers`, payload);
  }

  createGovernmentAuditor(payload: {name: string; email: string; password: string}): Observable<ApiResponse<User>> {
    return this.http.post<ApiResponse<User>>(`${this.base}/government-auditors`, payload);
  }
}

// ── Student Service ──────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class StudentService {
  private base = environment.studentServiceUrl;

  constructor(private http: HttpClient) {}

  getAllStudents(): Observable<ApiResponse<Student[]>> {
    return this.http.get<ApiResponse<Student[]>>(this.base);
  }

  getStudentById(id: number): Observable<ApiResponse<Student>> {
    return this.http.get<ApiResponse<Student>>(`${this.base}/${id}`);
  }

  getStudentByUserId(userId: number): Observable<ApiResponse<Student>> {
    return this.http.get<ApiResponse<Student>>(`${this.base}/by-user/${userId}`);
  }

  updateProfile(id: number, payload: Partial<Student>): Observable<ApiResponse<Student>> {
    return this.http.put<ApiResponse<Student>>(`${this.base}/profile/${id}`, payload);
  }

  getDocuments(studentId: number): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.base}/${studentId}/documents`);
  }

  verifyDocument(docId: number, status: string): Observable<ApiResponse<void>> {
    const params = new HttpParams().set('status', status);
    return this.http.patch<ApiResponse<void>>(`${this.base}/documents/${docId}/verify`, {}, { params });
  }
}

// ── Course Service ────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class CourseService {
  private base = environment.courseServiceUrl;

  constructor(private http: HttpClient) {}

  getAllCourses(): Observable<ApiResponse<Course[]>> {
    return this.http.get<ApiResponse<Course[]>>(this.base);
  }

  getCourseById(id: number): Observable<ApiResponse<Course>> {
    return this.http.get<ApiResponse<Course>>(`${this.base}/${id}`);
  }

  createCourse(payload: CourseRequest): Observable<ApiResponse<Course>> {
    return this.http.post<ApiResponse<Course>>(this.base, payload);
  }

  updateCourse(id: number, payload: Partial<CourseRequest>): Observable<ApiResponse<Course>> {
    return this.http.put<ApiResponse<Course>>(`${this.base}/${id}`, payload);
  }
}

// ── Enrollment Service ────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class EnrollmentService {
  private base = environment.enrollmentServiceUrl;

  constructor(private http: HttpClient) {}

  enroll(payload: EnrollmentRequest): Observable<ApiResponse<Enrollment>> {
    return this.http.post<ApiResponse<Enrollment>>(this.base, payload);
  }

  getByStudent(studentId: number): Observable<ApiResponse<Enrollment[]>> {
    return this.http.get<ApiResponse<Enrollment[]>>(`${this.base}/student/${studentId}`);
  }

  getByCourse(courseId: number): Observable<ApiResponse<Enrollment[]>> {
    return this.http.get<ApiResponse<Enrollment[]>>(`${this.base}/course/${courseId}`);
  }

  updateStatus(enrollmentId: number, status: string): Observable<ApiResponse<void>> {
    const params = new HttpParams().set('status', status);
    return this.http.patch<ApiResponse<void>>(`${this.base}/${enrollmentId}/status`, {}, { params });
  }

  unenroll(enrollmentId: number): Observable<ApiResponse<void>> {
    return this.http.patch<ApiResponse<void>>(`${this.base}/${enrollmentId}/unenroll`, {});
  }
}

// ── Progress Service ──────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ProgressService {
  private base = environment.progressServiceUrl;

  constructor(private http: HttpClient) {}

  getByStudent(studentId: number): Observable<ApiResponse<Progress[]>> {
    return this.http.get<ApiResponse<Progress[]>>(`${this.base}/student/${studentId}`);
  }

  getByStudentAndCourse(studentId: number, courseId: number): Observable<ApiResponse<Progress>> {
    return this.http.get<ApiResponse<Progress>>(`${this.base}/student/${studentId}/course/${courseId}`);
  }

  getByCourse(courseId: number): Observable<ApiResponse<Progress[]>> {
    return this.http.get<ApiResponse<Progress[]>>(`${this.base}/course/${courseId}`);
  }

  updateProgress(studentId: number, courseId: number, payload: {completionPercentage: number}): Observable<ApiResponse<Progress>> {
    return this.http.put<ApiResponse<Progress>>(`${this.base}/student/${studentId}/course/${courseId}`, payload);
  }

  initProgress(studentId: number, courseId: number, studentName: string, courseTitle: string): Observable<ApiResponse<Progress>> {
    const params = new HttpParams()
      .set('studentId', studentId)
      .set('courseId', courseId)
      .set('studentName', studentName)
      .set('courseTitle', courseTitle);
    return this.http.post<ApiResponse<Progress>>(`${this.base}/init`, {}, { params });
  }
}

// ── Assessment Service ────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class AssessmentService {
  private base = environment.assessmentServiceUrl;

  constructor(private http: HttpClient) {}

  getByCourse(courseId: number): Observable<ApiResponse<Assessment[]>> {
    return this.http.get<ApiResponse<Assessment[]>>(`${this.base}/course/${courseId}`);
  }

  getById(id: number): Observable<ApiResponse<Assessment>> {
    return this.http.get<ApiResponse<Assessment>>(`${this.base}/${id}`);
  }

  create(payload: AssessmentRequest): Observable<ApiResponse<Assessment>> {
    return this.http.post<ApiResponse<Assessment>>(this.base, payload);
  }

  activate(id: number): Observable<ApiResponse<void>> {
    return this.http.patch<ApiResponse<void>>(`${this.base}/${id}/activate`, {});
  }

  submit(payload: SubmissionRequest): Observable<ApiResponse<Submission>> {
    return this.http.post<ApiResponse<Submission>>(`${this.base}/submissions`, payload);
  }

  grade(submissionId: number, payload: GradeRequest): Observable<ApiResponse<Submission>> {
    return this.http.patch<ApiResponse<Submission>>(`${this.base}/submissions/${submissionId}/grade`, payload);
  }

  getSubmissionsByStudent(studentId: number): Observable<ApiResponse<Submission[]>> {
    return this.http.get<ApiResponse<Submission[]>>(`${this.base}/submissions/student/${studentId}`);
  }

  getSubmissionsByAssessment(assessmentId: number): Observable<ApiResponse<Submission[]>> {
    return this.http.get<ApiResponse<Submission[]>>(`${this.base}/${assessmentId}/submissions`);
  }
}

// ── Content Service ────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ContentService {
  private base = environment.contentServiceUrl;

  constructor(private http: HttpClient) {}

  getByCourse(courseId: number): Observable<ApiResponse<Content[]>> {
    return this.http.get<ApiResponse<Content[]>>(`${this.base}/course/${courseId}`);
  }

  getById(id: number): Observable<ApiResponse<Content>> {
    return this.http.get<ApiResponse<Content>>(`${this.base}/${id}`);
  }

  upload(payload: ContentRequest): Observable<ApiResponse<Content>> {
    return this.http.post<ApiResponse<Content>>(this.base, payload);
  }

  recordAccess(contentId: number, studentId: number): Observable<ApiResponse<void>> {
    const params = new HttpParams().set('studentId', studentId);
    return this.http.post<ApiResponse<void>>(`${this.base}/${contentId}/access`, {}, { params });
  }

  getAccessHistory(studentId: number): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.base}/access/student/${studentId}`);
  }

  updateStatus(contentId: number, status: string): Observable<ApiResponse<void>> {
    const params = new HttpParams().set('status', status);
    return this.http.patch<ApiResponse<void>>(`${this.base}/${contentId}/status`, {}, { params });
  }
}

// ── Notification Service ──────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private base = environment.notificationServiceUrl;

  constructor(private http: HttpClient) {}

  getByUser(userId: number): Observable<ApiResponse<Notification[]>> {
    return this.http.get<ApiResponse<Notification[]>>(`${this.base}/user/${userId}`);
  }

  getUnread(userId: number): Observable<ApiResponse<Notification[]>> {
    return this.http.get<ApiResponse<Notification[]>>(`${this.base}/user/${userId}/unread`);
  }

  markRead(notificationId: number): Observable<ApiResponse<void>> {
    return this.http.patch<ApiResponse<void>>(`${this.base}/${notificationId}/read`, {});
  }

  archive(notificationId: number): Observable<ApiResponse<void>> {
    return this.http.patch<ApiResponse<void>>(`${this.base}/${notificationId}/archive`, {});
  }
}

// ── Report Service ────────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ReportService {
  private base = environment.reportServiceUrl;

  constructor(private http: HttpClient) {}

  getDashboardMetrics(): Observable<ApiResponse<DashboardMetrics>> {
    return this.http.get<ApiResponse<DashboardMetrics>>(`${this.base}/dashboard`);
  }

  generateReport(scope: string, generatedBy: string): Observable<ApiResponse<any>> {
    const params = new HttpParams().set('scope', scope).set('generatedBy', generatedBy);
    return this.http.post<ApiResponse<any>>(`${this.base}/generate`, {}, { params });
  }

  getAllReports(): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(this.base);
  }
}

// ── Compliance Service ────────────────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ComplianceService {
  private base = environment.complianceServiceUrl;

  constructor(private http: HttpClient) {}

  getAll(): Observable<ApiResponse<ComplianceRecord[]>> {
    return this.http.get<ApiResponse<ComplianceRecord[]>>(this.base);
  }

  getByEntity(entityId: number): Observable<ApiResponse<ComplianceRecord[]>> {
    return this.http.get<ApiResponse<ComplianceRecord[]>>(`${this.base}/entity/${entityId}`);
  }

  create(payload: Partial<ComplianceRecord>): Observable<ApiResponse<ComplianceRecord>> {
    return this.http.post<ApiResponse<ComplianceRecord>>(this.base, payload);
  }

  updateResult(id: number, result: string): Observable<ApiResponse<void>> {
    const params = new HttpParams().set('result', result);
    return this.http.patch<ApiResponse<void>>(`${this.base}/${id}/result`, {}, { params });
  }

  getAllAudits(): Observable<ApiResponse<Audit[]>> {
    return this.http.get<ApiResponse<Audit[]>>(`${environment.apiUrl}/audits`);
  }

  createAudit(payload: Partial<Audit>): Observable<ApiResponse<Audit>> {
    return this.http.post<ApiResponse<Audit>>(`${environment.apiUrl}/audits`, payload);
  }

  updateAuditStatus(auditId: number, status: string): Observable<ApiResponse<void>> {
    const params = new HttpParams().set('status', status);
    return this.http.patch<ApiResponse<void>>(`${environment.apiUrl}/audits/${auditId}/status`, {}, { params });
  }
}
