import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ApiResponse, AuthResponse, LoginRequest, RegisterRequest, User, UserRole
} from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN_KEY = 'educonnect_token';
  private readonly USER_KEY = 'educonnect_user';

  currentUser = signal<AuthResponse | null>(this.loadUser());

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: LoginRequest): Observable<ApiResponse<AuthResponse>> {
    return this.http
      .post<ApiResponse<AuthResponse>>(`${environment.authServiceUrl}/login`, credentials)
      .pipe(tap(res => {
        if (res.success && res.data) {
          this.saveSession(res.data);
        }
      }));
  }

  register(payload: RegisterRequest): Observable<ApiResponse<AuthResponse>> {
    return this.http.post<ApiResponse<AuthResponse>>(
      `${environment.authServiceUrl}/register`, payload
    );
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.currentUser.set(null);
    this.router.navigate(['/auth/login']);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getRole(): UserRole | null {
    return this.currentUser()?.role ?? null;
  }

  hasRole(...roles: UserRole[]): boolean {
    const role = this.getRole();
    return role ? roles.includes(role) : false;
  }

  getUserId(): number | null {
    return this.currentUser()?.userId ?? null;
  }

  private saveSession(data: AuthResponse): void {
    localStorage.setItem(this.TOKEN_KEY, data.token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(data));
    this.currentUser.set(data);
  }

  private loadUser(): AuthResponse | null {
    try {
      const raw = localStorage.getItem(this.USER_KEY);
      return raw ? (JSON.parse(raw) as AuthResponse) : null;
    } catch {
      return null;
    }
  }

  redirectAfterLogin(role: UserRole): void {
    const routes: Record<UserRole, string> = {
      ADMIN: '/admin/dashboard',
      STUDENT: '/student/dashboard',
      TEACHER: '/teacher/dashboard',
      PROGRAM_MANAGER: '/admin/dashboard',
      COMPLIANCE_OFFICER: '/admin/compliance',
      GOVERNMENT_AUDITOR: '/admin/audits',
    };
    this.router.navigate([routes[role] ?? '/']);
  }
}
