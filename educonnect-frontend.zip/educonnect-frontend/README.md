# EduConnect Frontend — Angular 17

A full-featured, role-based Angular 17 frontend for the **EduConnect Digital Education & E-Learning Governance System**.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Angular 17 (Standalone Components) |
| State | Angular Signals |
| Routing | Angular Router (lazy-loaded) |
| Forms | Reactive Forms |
| HTTP | HttpClient + functional interceptors |
| Styling | Custom SCSS (CSS Variables, no 3rd-party UI lib) |
| Auth | JWT (localStorage) |

---

## Project Structure

```
src/
├── app/
│   ├── core/
│   │   ├── guards/
│   │   │   └── auth.guard.ts          ← authGuard, roleGuard, guestGuard
│   │   ├── interceptors/
│   │   │   ├── jwt.interceptor.ts     ← Auto-attaches Bearer token
│   │   │   └── error.interceptor.ts   ← 401/403 handler
│   │   ├── models/
│   │   │   └── models.ts              ← All TypeScript interfaces & types
│   │   └── services/
│   │       ├── auth.service.ts        ← Login, register, session
│   │       └── api.services.ts        ← All microservice API calls
│   │
│   ├── features/
│   │   ├── auth/
│   │   │   ├── auth-shell/            ← Split-screen auth layout
│   │   │   ├── login/                 ← Login form + demo accounts
│   │   │   └── register/              ← Student self-registration
│   │   │
│   │   ├── student/
│   │   │   ├── dashboard/             ← Progress stats, enrollments
│   │   │   ├── courses/               ← Browse & enroll in courses
│   │   │   ├── assessments/           ← View & submit tests/quizzes
│   │   │   ├── progress/              ← Per-course progress bars
│   │   │   └── profile/               ← Edit personal info
│   │   │
│   │   ├── teacher/
│   │   │   ├── dashboard/             ← Stats, pending grading
│   │   │   ├── courses/               ← Create & manage courses
│   │   │   ├── content/               ← Upload videos, PDFs, docs
│   │   │   ├── assessments/           ← Create quizzes/tests, grade submissions
│   │   │   └── students/              ← View enrolled students + progress
│   │   │
│   │   └── admin/
│   │       ├── dashboard/             ← Platform-wide metrics
│   │       ├── users/                 ← Manage all users, create staff
│   │       ├── courses/               ← View all platform courses
│   │       ├── reports/               ← Generate & view reports
│   │       ├── compliance/            ← Compliance records management
│   │       └── audits/                ← Government audit management
│   │
│   └── shared/
│       └── components/
│           ├── shell/                 ← Main layout (sidebar + header + outlet)
│           ├── sidebar/               ← Role-aware navigation
│           ├── header/                ← Notifications, user chip
│           ├── unauthorized/          ← 403 page
│           └── not-found/             ← 404 page
│
└── environments/
    ├── environment.ts                 ← Dev (localhost:8080)
    └── environment.prod.ts            ← Production URLs
```

---

## Role-Based Access Control

| Role | Login | Dashboard | Features |
|---|---|---|---|
| **STUDENT** | Self-register | `/student/dashboard` | Courses, Assessments, Progress, Profile |
| **TEACHER** | Admin creates | `/teacher/dashboard` | Courses, Content, Assessments, Students |
| **ADMIN** | Admin creates | `/admin/dashboard` | Users, Courses, Reports, Compliance, Audits |
| **PROGRAM_MANAGER** | Admin creates | `/admin/dashboard` | Dashboard, Courses, Reports |
| **COMPLIANCE_OFFICER** | Admin creates | `/admin/compliance` | Compliance, Audits |
| **GOVERNMENT_AUDITOR** | Admin creates | `/admin/audits` | Audits (read) |

### Route Guards
- `authGuard` — requires authenticated session
- `roleGuard(...roles)` — requires specific role(s)
- `guestGuard` — redirects logged-in users away from auth pages

---

## API Integration

All services map directly to your microservices via the API Gateway at `http://localhost:8080`:

| Service | Base URL | Covers |
|---|---|---|
| Auth | `/auth` | Login, Register |
| Admin | `/admin` | Users, Staff creation |
| Student | `/students` | Profile, Documents |
| Course | `/courses` | CRUD courses |
| Enrollment | `/enrollments` | Enroll, status |
| Progress | `/progress` | Per-course progress |
| Assessment | `/assessments` | Tests, quizzes, submissions, grading |
| Content | `/contents` | Upload, access history |
| Notification | `/notifications` | Unread, mark read |
| Report | `/reports` | Dashboard metrics, generate |
| Compliance | `/compliance` | Records, audits |

---

## Getting Started

### Prerequisites
- Node.js 18+
- npm 9+

### Installation

```bash
# Install dependencies
npm install

# Start development server (port 4200)
npm start

# Build for production
npm run build
```

The app will be at `http://localhost:4200`.

### Demo Accounts (shown on Login page)

| Role | Email | Password |
|---|---|---|
| Admin | admin@educonnect.com | Admin@123 |
| Student | alice@educonnect.com | Alice@123 |
| Teacher | teacher@educonnect.com | Teacher@123 |

---

## Environment Configuration

Edit `src/environments/environment.ts` to change API URLs:

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080',
  authServiceUrl: 'http://localhost:8080/auth',
  // ... other service URLs
};
```

---

## Key Design Decisions

1. **Standalone Components** — no NgModule overhead, fully tree-shakeable
2. **Angular Signals** — reactive state without RxJS complexity in templates
3. **Lazy Loading** — each role's feature module is loaded on demand
4. **Functional Interceptors** — `jwtInterceptor` & `errorInterceptor` injected via `provideHttpClient`
5. **Role-aware Sidebar** — `visibleNav` computed signal filters nav items by current role
6. **CSS Variables** — single dark theme controllable from `:root`, no Tailwind/Bootstrap needed

---

## Adding New Features

### New page under Student:
1. Create component in `src/app/features/student/your-page/`
2. Add route to `student.routes.ts`
3. Add nav item to `sidebar.component.ts` with `roles: ['STUDENT']`
4. Add API call to `api.services.ts` if needed
