import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment as env } from '../../../environments/environment';
import {
  ApiResponse, User, UpdateUserRequest, CreateUserRequest,
  Student, StudentProfileRequest, StudentDocument, VerificationStatus,
  Course, CourseRequest,
  Enrollment, EnrollmentRequest, EnrollmentStatus,
  Progress, ProgressUpdateRequest,
  Assessment, AssessmentRequest, Submission, SubmissionRequest, GradeRequest,
  Content, ContentRequest, ContentAccess, ContentStatus,
  Notification, NotificationRequest,
  ComplianceRecord, ComplianceRecordRequest, ComplianceResult,
  Audit, AuditRequest, AuditLog, AuditLogRequest,
  Report, DashboardMetrics,
} from '../models';

// ── User Service ─────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class UserService {
  private base = `${env.usersUrl}`;
  constructor(private http: HttpClient) {}

  getAll():                       Observable<ApiResponse<User[]>>  { return this.http.get<ApiResponse<User[]>>(this.base); }
  getById(id: number):            Observable<ApiResponse<User>>    { return this.http.get<ApiResponse<User>>(`${this.base}/${id}`); }
  getByEmail(email: string):      Observable<ApiResponse<User>>    { return this.http.get<ApiResponse<User>>(`${this.base}/by-email`, { params: new HttpParams().set('email', email) }); }
  getByRole(role: string):        Observable<ApiResponse<User[]>>  { return this.http.get<ApiResponse<User[]>>(`${this.base}/role/${role}`); }
  getByStatus(status: string):    Observable<ApiResponse<User[]>>  { return this.http.get<ApiResponse<User[]>>(`${this.base}/status/${status}`); }
  update(id: number, req: UpdateUserRequest): Observable<ApiResponse<User>> { return this.http.patch<ApiResponse<User>>(`${this.base}/${id}`, req); }
  updateStatus(id: number, status: string):   Observable<ApiResponse<User>> { return this.http.patch<ApiResponse<User>>(`${this.base}/${id}/status`, null, { params: new HttpParams().set('status', status) }); }
  deactivate(id: number):         Observable<ApiResponse<void>>    { return this.http.delete<ApiResponse<void>>(`${this.base}/${id}`); }
}

// ── Admin / Auth Management Service ──────────────────────────
@Injectable({ providedIn: 'root' })
export class AdminUserService {
  private base = `${env.adminUrl}`;
  constructor(private http: HttpClient) {}

  getAllUsers():                              Observable<ApiResponse<User[]>>  { return this.http.get<ApiResponse<User[]>>(`${this.base}/users`); }
  getUserById(id: number):                   Observable<ApiResponse<User>>    { return this.http.get<ApiResponse<User>>(`${this.base}/users/${id}`); }
  deactivateUser(id: number):                Observable<ApiResponse<User>>    { return this.http.patch<ApiResponse<User>>(`${this.base}/users/${id}/deactivate`, {}); }
  activateUser(id: number):                  Observable<ApiResponse<User>>    { return this.http.patch<ApiResponse<User>>(`${this.base}/users/${id}/activate`, {}); }
  createTeacher(req: CreateUserRequest):     Observable<ApiResponse<User>>    { return this.http.post<ApiResponse<User>>(`${this.base}/teachers`, req); }
  getAllTeachers():                           Observable<ApiResponse<User[]>>  { return this.http.get<ApiResponse<User[]>>(`${this.base}/teachers`); }
  createProgramManager(req: CreateUserRequest):    Observable<ApiResponse<User>> { return this.http.post<ApiResponse<User>>(`${this.base}/program-managers`, req); }
  createComplianceOfficer(req: CreateUserRequest): Observable<ApiResponse<User>> { return this.http.post<ApiResponse<User>>(`${this.base}/compliance-officers`, req); }
  createGovernmentAuditor(req: CreateUserRequest): Observable<ApiResponse<User>> { return this.http.post<ApiResponse<User>>(`${this.base}/government-auditors`, req); }
}

// ── Student Service ───────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class StudentService {
  private base = `${env.studentsUrl}`;
  constructor(private http: HttpClient) {}

  getAll():                                      Observable<ApiResponse<Student[]>>  { return this.http.get<ApiResponse<Student[]>>(this.base); }
  getById(id: number):                           Observable<ApiResponse<Student>>    { return this.http.get<ApiResponse<Student>>(`${this.base}/${id}`); }
  getByUserId(userId: number):                   Observable<ApiResponse<Student>>    { return this.http.get<ApiResponse<Student>>(`${this.base}/by-user/${userId}`); }
  updateProfile(userId: number, req: StudentProfileRequest): Observable<ApiResponse<Student>> { return this.http.put<ApiResponse<Student>>(`${this.base}/profile/${userId}`, req); }
  getDocuments(studentId: number):               Observable<ApiResponse<StudentDocument[]>> { return this.http.get<ApiResponse<StudentDocument[]>>(`${this.base}/${studentId}/documents`); }
  verifyDocument(docId: number, status: VerificationStatus): Observable<ApiResponse<StudentDocument>> {
    return this.http.patch<ApiResponse<StudentDocument>>(`${this.base}/documents/${docId}/verify`, null, { params: new HttpParams().set('status', status) });
  }
}

// ── Course Service ────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class CourseService {
  private base = `${env.coursesUrl}`;
  constructor(private http: HttpClient) {}

  getAll():                               Observable<ApiResponse<Course[]>>  { return this.http.get<ApiResponse<Course[]>>(this.base); }
  getById(id: number):                    Observable<ApiResponse<Course>>    { return this.http.get<ApiResponse<Course>>(`${this.base}/${id}`); }
  create(req: CourseRequest):             Observable<ApiResponse<Course>>    { return this.http.post<ApiResponse<Course>>(this.base, req); }
  update(id: number, req: CourseRequest): Observable<ApiResponse<Course>>    { return this.http.put<ApiResponse<Course>>(`${this.base}/${id}`, req); }
}

// ── Enrollment Service ────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class EnrollmentService {
  private base = `${env.enrollmentsUrl}`;
  constructor(private http: HttpClient) {}

  enroll(req: EnrollmentRequest):            Observable<ApiResponse<Enrollment>>    { return this.http.post<ApiResponse<Enrollment>>(this.base, req); }
  getById(id: number):                       Observable<ApiResponse<Enrollment>>    { return this.http.get<ApiResponse<Enrollment>>(`${this.base}/${id}`); }
  getByStudent(studentId: number):           Observable<ApiResponse<Enrollment[]>>  { return this.http.get<ApiResponse<Enrollment[]>>(`${this.base}/student/${studentId}`); }
  getByCourse(courseId: number):             Observable<ApiResponse<Enrollment[]>>  { return this.http.get<ApiResponse<Enrollment[]>>(`${this.base}/course/${courseId}`); }
  updateStatus(id: number, status: EnrollmentStatus): Observable<ApiResponse<Enrollment>> {
    return this.http.patch<ApiResponse<Enrollment>>(`${this.base}/${id}/status`, null, { params: new HttpParams().set('status', status) });
  }
  unenroll(id: number):                      Observable<ApiResponse<Enrollment>>    { return this.http.patch<ApiResponse<Enrollment>>(`${this.base}/${id}/unenroll`, {}); }
}

// ── Progress Service ──────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ProgressService {
  private base = `${env.progressUrl}`;
  constructor(private http: HttpClient) {}

  init(studentId: number, courseId: number, studentName?: string, courseTitle?: string): Observable<ApiResponse<Progress>> {
    let p = new HttpParams().set('studentId', studentId).set('courseId', courseId);
    if (studentName) p = p.set('studentName', studentName);
    if (courseTitle) p = p.set('courseTitle', courseTitle);
    return this.http.post<ApiResponse<Progress>>(`${this.base}/init`, null, { params: p });
  }
  update(studentId: number, courseId: number, req: ProgressUpdateRequest): Observable<ApiResponse<Progress>> {
    return this.http.put<ApiResponse<Progress>>(`${this.base}/student/${studentId}/course/${courseId}`, req);
  }
  getByStudentAndCourse(studentId: number, courseId: number): Observable<ApiResponse<Progress>> {
    return this.http.get<ApiResponse<Progress>>(`${this.base}/student/${studentId}/course/${courseId}`);
  }
  getByStudent(studentId: number): Observable<ApiResponse<Progress[]>> {
    return this.http.get<ApiResponse<Progress[]>>(`${this.base}/student/${studentId}`);
  }
  getByCourse(courseId: number): Observable<ApiResponse<Progress[]>> {
    return this.http.get<ApiResponse<Progress[]>>(`${this.base}/course/${courseId}`);
  }
  getCompleted(): Observable<ApiResponse<Progress[]>> {
    return this.http.get<ApiResponse<Progress[]>>(`${this.base}/completed`);
  }
}

// ── Assessment Service ────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class AssessmentService {
  private base = `${env.assessmentsUrl}`;
  constructor(private http: HttpClient) {}

  create(req: AssessmentRequest):             Observable<ApiResponse<Assessment>>   { return this.http.post<ApiResponse<Assessment>>(this.base, req); }
  getByCourse(courseId: number):              Observable<ApiResponse<Assessment[]>> { return this.http.get<ApiResponse<Assessment[]>>(`${this.base}/course/${courseId}`); }
  getById(id: number):                        Observable<ApiResponse<Assessment>>   { return this.http.get<ApiResponse<Assessment>>(`${this.base}/${id}`); }
  activate(id: number):                       Observable<ApiResponse<Assessment>>   { return this.http.patch<ApiResponse<Assessment>>(`${this.base}/${id}/activate`, {}); }
  submit(req: SubmissionRequest):             Observable<ApiResponse<Submission>>   { return this.http.post<ApiResponse<Submission>>(`${this.base}/submissions`, req); }
  grade(submissionId: number, req: GradeRequest): Observable<ApiResponse<Submission>> { return this.http.patch<ApiResponse<Submission>>(`${this.base}/submissions/${submissionId}/grade`, req); }
  getSubmissionsByStudent(studentId: number): Observable<ApiResponse<Submission[]>> { return this.http.get<ApiResponse<Submission[]>>(`${this.base}/submissions/student/${studentId}`); }
  getSubmissionsByAssessment(assessmentId: number): Observable<ApiResponse<Submission[]>> { return this.http.get<ApiResponse<Submission[]>>(`${this.base}/${assessmentId}/submissions`); }
}

// ── Content Service ───────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ContentService {
  private base = `${env.contentsUrl}`;
  constructor(private http: HttpClient) {}

  create(req: ContentRequest):     Observable<ApiResponse<Content>>         { return this.http.post<ApiResponse<Content>>(this.base, req); }
  getByCourse(courseId: number):   Observable<ApiResponse<Content[]>>       { return this.http.get<ApiResponse<Content[]>>(`${this.base}/course/${courseId}`); }
  getById(id: number):             Observable<ApiResponse<Content>>         { return this.http.get<ApiResponse<Content>>(`${this.base}/${id}`); }
  recordAccess(contentId: number, studentId: number): Observable<ApiResponse<ContentAccess>> {
    return this.http.post<ApiResponse<ContentAccess>>(`${this.base}/${contentId}/access`, null, { params: new HttpParams().set('studentId', studentId) });
  }
  getAccessByStudent(studentId: number): Observable<ApiResponse<ContentAccess[]>> {
    return this.http.get<ApiResponse<ContentAccess[]>>(`${this.base}/access/student/${studentId}`);
  }
  updateStatus(id: number, status: ContentStatus): Observable<ApiResponse<Content>> {
    return this.http.patch<ApiResponse<Content>>(`${this.base}/${id}/status`, null, { params: new HttpParams().set('status', status) });
  }
}

// ── Notification Service ──────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private base = `${env.notificationsUrl}`;
  constructor(private http: HttpClient) {}

  create(req: NotificationRequest):       Observable<ApiResponse<Notification>>   { return this.http.post<ApiResponse<Notification>>(this.base, req); }
  getByUser(userId: number):              Observable<ApiResponse<Notification[]>> { return this.http.get<ApiResponse<Notification[]>>(`${this.base}/user/${userId}`); }
  getUnread(userId: number):              Observable<ApiResponse<Notification[]>> { return this.http.get<ApiResponse<Notification[]>>(`${this.base}/user/${userId}/unread`); }
  markRead(id: number):                   Observable<ApiResponse<Notification>>   { return this.http.patch<ApiResponse<Notification>>(`${this.base}/${id}/read`, {}); }
  archive(id: number):                    Observable<ApiResponse<Notification>>   { return this.http.patch<ApiResponse<Notification>>(`${this.base}/${id}/archive`, {}); }
}

// ── Compliance Service ────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ComplianceService {
  private base = `${env.complianceUrl}`;
  constructor(private http: HttpClient) {}

  create(req: ComplianceRecordRequest):   Observable<ApiResponse<ComplianceRecord>>   { return this.http.post<ApiResponse<ComplianceRecord>>(this.base, req); }
  getAll():                               Observable<ApiResponse<ComplianceRecord[]>>  { return this.http.get<ApiResponse<ComplianceRecord[]>>(this.base); }
  getByEntity(entityId: number):          Observable<ApiResponse<ComplianceRecord[]>>  { return this.http.get<ApiResponse<ComplianceRecord[]>>(`${this.base}/entity/${entityId}`); }
  updateResult(id: number, result: ComplianceResult): Observable<ApiResponse<ComplianceRecord>> {
    return this.http.patch<ApiResponse<ComplianceRecord>>(`${this.base}/${id}/result`, null, { params: new HttpParams().set('result', result) });
  }
}

// ── Audit Service ─────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class AuditService {
  private base = `${env.auditsUrl}`;
  constructor(private http: HttpClient) {}

  create(req: AuditRequest):     Observable<ApiResponse<Audit>>   { return this.http.post<ApiResponse<Audit>>(this.base, req); }
  getAll():                      Observable<ApiResponse<Audit[]>> { return this.http.get<ApiResponse<Audit[]>>(this.base); }
  updateStatus(id: number, status: string): Observable<ApiResponse<Audit>> {
    return this.http.patch<ApiResponse<Audit>>(`${this.base}/${id}/status`, null, { params: new HttpParams().set('status', status) });
  }
  getLogs(): Observable<ApiResponse<AuditLog[]>> { return this.http.get<ApiResponse<AuditLog[]>>(`${this.base}/logs`); }
  logAction(req: AuditLogRequest):         Observable<ApiResponse<AuditLog>>   { return this.http.post<ApiResponse<AuditLog>>(`${this.base}/logs`, req); }
  getLogsByEntity(entityType: string, entityId: number): Observable<ApiResponse<AuditLog[]>> {
    return this.http.get<ApiResponse<AuditLog[]>>(`${this.base}/logs/entity`, { params: new HttpParams().set('entityType', entityType).set('entityId', entityId) });
  }
  getLogsByUser(userId: number): Observable<ApiResponse<AuditLog[]>> { return this.http.get<ApiResponse<AuditLog[]>>(`${this.base}/logs/user/${userId}`); }
}

// ── Report Service ────────────────────────────────────────────
@Injectable({ providedIn: 'root' })
export class ReportService {
  private base = `${env.reportsUrl}`;
  constructor(private http: HttpClient) {}

  getDashboard():              Observable<ApiResponse<DashboardMetrics>> { return this.http.get<ApiResponse<DashboardMetrics>>(`${this.base}/dashboard`); }
  generate(scope: string, generatedBy = 'system'): Observable<ApiResponse<DashboardMetrics>> {
    return this.http.post<ApiResponse<DashboardMetrics>>(`${this.base}/generate`, null, { params: new HttpParams().set('scope', scope).set('generatedBy', generatedBy) });
  }
  getAll():                    Observable<ApiResponse<Report[]>>        { return this.http.get<ApiResponse<Report[]>>(this.base); }
  getById(id: number):         Observable<ApiResponse<Report>>          { return this.http.get<ApiResponse<Report>>(`${this.base}/${id}`); }
  getByScope(scope: string):   Observable<ApiResponse<Report[]>>        { return this.http.get<ApiResponse<Report[]>>(`${this.base}/scope/${scope}`); }
}

// ── Toast / UI State Service ──────────────────────────────────
export interface Toast {
  id:      string;
  type:    'success' | 'error' | 'info' | 'warning';
  title:   string;
  message?: string;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  private _toasts = signal<Toast[]>([]);
  readonly toasts = this._toasts.asReadonly();

  show(type: Toast['type'], title: string, message?: string, duration = 4000): void {
    const id = Date.now().toString();
    this._toasts.update(t => [...t, { id, type, title, message }]);
    setTimeout(() => this.remove(id), duration);
  }

  success(title: string, msg?: string): void { this.show('success', title, msg); }
  error(title: string, msg?: string):   void { this.show('error', title, msg); }
  info(title: string, msg?: string):    void { this.show('info', title, msg); }
  warning(title: string, msg?: string): void { this.show('warning', title, msg); }

  remove(id: string): void { this._toasts.update(t => t.filter(x => x.id !== id)); }
}

// Make signal importable
import { signal } from '@angular/core';
