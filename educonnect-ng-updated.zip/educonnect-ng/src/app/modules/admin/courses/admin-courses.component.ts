// ─────────────────────────────────────────────────────────────
// Admin Courses Component
// ─────────────────────────────────────────────────────────────
import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseService, AdminUserService } from '../../../core/services/index';
import { Course, CourseStatus, User } from '../../../core/models';

@Component({
  selector: 'app-admin-courses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Platform Content</span>
          <h1 class="page-title">All Courses</h1>
          <p class="page-desc">{{ courses().length }} courses across the platform</p>
        </div>
      </header>

      <div class="filter-bar">
        @for (f of statusFilters; track f) {
          <button class="filter-btn" [class.active]="statusFilter() === f" (click)="statusFilter.set(f)">
            {{ f }} <span class="fc">{{ countByStatus(f) }}</span>
          </button>
        }
        <div class="search-wrap">
          <i class="bi bi-search"></i>
          <input type="text" [(ngModel)]="search" class="search-input" placeholder="Search courses..." />
        </div>
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      } @else if (filtered().length === 0) {
        <div class="empty-state">
          <i class="bi bi-book-slash"></i>
          <h3>No courses found</h3>
          <p>Try changing your filters.</p>
        </div>
      } @else {
        <div class="table-wrap">
          <table class="ec-table">
            <thead>
              <tr><th>Title</th><th>Teacher</th><th>Status</th><th>Start</th><th>End</th></tr>
            </thead>
            <tbody>
              @for (c of filtered(); track c.courseId) {
                <tr>
                  <td>
                    <div class="cell-title">{{ c.title }}</div>
                    <div class="cell-sub">{{ c.description | slice:0:60 }}{{ c.description.length > 60 ? '...' : '' }}</div>
                  </td>
                  <td class="muted">{{ teacherName(c.teacherUserId) }}</td>
                  <td><span class="st-badge" [ngClass]="'st-' + c.status.toLowerCase()">{{ c.status }}</span></td>
                  <td class="muted">{{ c.startDate | date:'mediumDate' }}</td>
                  <td class="muted">{{ c.endDate | date:'mediumDate' }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    </div>
  `,
  styles: [`
    :host{--accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);display:block;font-family:'Plus Jakarta Sans',sans-serif;}
    .page{display:flex;flex-direction:column;gap:1.5rem;}
    .page-head{display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap;}
    .eyebrow{display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;}
    .page-title{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0;}
    .page-desc{font-size:0.92rem;color:var(--text-muted);margin-top:6px;}
    .filter-bar{display:flex;flex-wrap:wrap;gap:0.5rem;align-items:center;}
    .filter-btn{padding:0.45rem 0.875rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:100px;color:var(--text-muted);font-size:0.82rem;font-weight:600;font-family:inherit;cursor:pointer;transition:all 0.2s;display:inline-flex;align-items:center;gap:5px;&:hover{color:#fff;}&.active{background:rgba(46,123,246,0.15);border-color:rgba(46,123,246,0.35);color:var(--accent-light);}  .fc{font-size:0.68rem;padding:1px 6px;border-radius:100px;background:rgba(255,255,255,0.08);}}
    .search-wrap{position:relative;margin-left:auto; i{position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:0.85rem;}}
    .search-input{padding:0.55rem 0.85rem 0.55rem 2.1rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.85rem;font-family:inherit;outline:none;width:240px;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);}}
    .table-wrap{overflow-x:auto;border-radius:16px;border:1px solid var(--border);}
    .ec-table{width:100%;border-collapse:collapse;thead tr{background:rgba(255,255,255,0.03);}th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;}td{padding:0.875rem 1rem;font-size:0.875rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);}tbody tr:last-child td{border-bottom:none;}tbody tr:hover{background:rgba(255,255,255,0.025);}}
    .cell-title{font-weight:600;color:#fff;}.cell-sub{font-size:0.75rem;color:var(--text-muted);margin-top:2px;}.muted{color:var(--text-muted);font-size:0.85rem;}
    .st-badge{display:inline-flex;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;}
    .st-active{background:rgba(16,185,129,0.15);color:#34D399;border:1px solid rgba(16,185,129,0.25);}
    .st-draft{background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25);}
    .st-completed{background:rgba(46,123,246,0.15);color:var(--accent-light);border:1px solid rgba(46,123,246,0.25);}
    .st-archived{background:rgba(148,163,184,0.1);color:#94A3B8;border:1px solid rgba(148,163,184,0.2);}
    .empty-state{padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;}h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;}p{font-size:0.875rem;color:var(--text-muted);}}
    .load-center{display:flex;justify-content:center;padding:3rem;}
    .ec-spin{display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite;}
    @keyframes spin{to{transform:rotate(360deg);}}
  `],
})
export class AdminCoursesComponent implements OnInit {
  private courseSvc = inject(CourseService);
  private adminSvc  = inject(AdminUserService);
  loading      = signal(true);
  courses      = signal<Course[]>([]);
  teacherMap   = signal<Map<number, string>>(new Map());
  statusFilter = signal('ALL');
  search       = '';
  statusFilters = ['ALL', 'DRAFT', 'ACTIVE', 'COMPLETED', 'ARCHIVED'];

  filtered = computed(() => {
    let list = this.courses();
    if (this.statusFilter() !== 'ALL') list = list.filter(c => c.status === this.statusFilter());
    if (this.search.trim()) list = list.filter(c => c.title.toLowerCase().includes(this.search.toLowerCase()));
    return list;
  });

  countByStatus(s: string): number {
    if (s === 'ALL') return this.courses().length;
    return this.courses().filter(c => c.status === s).length;
  }

  ngOnInit(): void {
    this.courseSvc.getAll().subscribe({
      next: r => { if (r.success) this.courses.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
    this.adminSvc.getAllTeachers().subscribe({
      next: r => {
        if (r.success) {
          const m = new Map<number, string>();
          (r.data ?? []).forEach(u => m.set(u.userId, u.name));
          this.teacherMap.set(m);
        }
      },
    });
  }

  teacherName(id: number): string {
    return this.teacherMap().get(id) ?? `Teacher #${id}`;
  }
  }
}
