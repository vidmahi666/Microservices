import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuditService, ComplianceService, ReportService } from '../../../core/services/index';
import { Audit, ComplianceRecord, Report } from '../../../core/models';

@Component({
  selector: 'app-admin-audit-overview',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Read-Only Governance Overview</span>
          <h1 class="page-title">Audit Overview</h1>
          <p class="page-desc">Consolidated read-only view of Auditor and Compliance Officer reports</p>
        </div>
        <div class="ro-badge"><i class="bi bi-eye-fill"></i> Read Only</div>
      </header>

      <!-- Summary strip -->
      <div class="sum-strip">
        <div class="ss-item" data-tone="rose">
          <div class="ss-icon"><i class="bi bi-search"></i></div>
          <div class="ss-val">{{ audits().length }}</div>
          <div class="ss-lbl">Total Audits</div>
        </div>
        <div class="ss-item" data-tone="purple">
          <div class="ss-icon"><i class="bi bi-shield-check-fill"></i></div>
          <div class="ss-val">{{ complianceRecords().length }}</div>
          <div class="ss-lbl">Compliance Records</div>
        </div>
        <div class="ss-item" data-tone="mint">
          <div class="ss-icon"><i class="bi bi-check-circle-fill"></i></div>
          <div class="ss-val">{{ compliantCount() }}</div>
          <div class="ss-lbl">Compliant</div>
        </div>
        <div class="ss-item" data-tone="gold">
          <div class="ss-icon"><i class="bi bi-file-earmark-bar-graph"></i></div>
          <div class="ss-val">{{ reports().length }}</div>
          <div class="ss-lbl">Reports Generated</div>
        </div>
        <div class="ss-item" data-tone="blue">
          <div class="ss-icon"><i class="bi bi-hourglass-split"></i></div>
          <div class="ss-val">{{ auditInProgress() }}</div>
          <div class="ss-lbl">Audits In Progress</div>
        </div>
      </div>

      <!-- Two column layout -->
      <div class="ov-grid">

        <!-- Auditor section -->
        <section class="ov-panel">
          <div class="panel-head">
            <div class="panel-icon rose"><i class="bi bi-search"></i></div>
            <div>
              <h2 class="panel-title">Government Auditor Reports</h2>
              <p class="panel-sub">Formal government audit records and their current status</p>
            </div>
          </div>
          @if (loadingAudits()) {
            <div class="load-row"><span class="spin"></span> Loading...</div>
          } @else if (audits().length === 0) {
            <div class="mini-empty">
              <i class="bi bi-search"></i>
              <p>No audits initiated yet</p>
            </div>
          } @else {
            <div class="table-wrap">
              <table class="ec-table">
                <thead>
                  <tr><th>Title</th><th>Status</th><th>Initiated</th></tr>
                </thead>
                <tbody>
                  @for (a of audits(); track a.auditId) {
                    <tr>
                      <td>
                        <div class="cell-main">{{ a.title }}</div>
                        @if (a.description) {
                          <div class="cell-sub">{{ a.description | slice:0:60 }}...</div>
                        }
                      </td>
                      <td>
                        <span class="audit-status" [ngClass]="'as-' + a.status.toLowerCase().replace('_','-')">
                          {{ a.status.replace('_',' ') }}
                        </span>
                      </td>
                      <td class="muted">{{ a.createdAt | date:'mediumDate' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </section>

        <!-- Compliance Officer section -->
        <section class="ov-panel">
          <div class="panel-head">
            <div class="panel-icon purple"><i class="bi bi-shield-check-fill"></i></div>
            <div>
              <h2 class="panel-title">Compliance Officer Records</h2>
              <p class="panel-sub">Policy adherence records managed by the Compliance Officer</p>
            </div>
          </div>
          @if (loadingCompliance()) {
            <div class="load-row"><span class="spin"></span> Loading...</div>
          } @else if (complianceRecords().length === 0) {
            <div class="mini-empty">
              <i class="bi bi-shield-check"></i>
              <p>No compliance records available</p>
            </div>
          } @else {
            <div class="table-wrap">
              <table class="ec-table">
                <thead>
                  <tr><th>Entity</th><th>Type</th><th>Result</th><th>Date</th></tr>
                </thead>
                <tbody>
                  @for (r of complianceRecords(); track r.complianceId) {
                    <tr>
                      <td class="cell-main">#{{ r.entityId }}</td>
                      <td><span class="type-pill">{{ r.type }}</span></td>
                      <td>
                        <span class="result-badge" [ngClass]="'rb-' + (r.result ?? 'pending').toLowerCase().replace('_','-')">
                          {{ (r.result ?? 'PENDING').replace('_',' ') }}
                        </span>
                      </td>
                      <td class="muted">{{ r.recordDate | date:'mediumDate' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </section>
      </div>

      <!-- Combined Reports History -->
      <section class="reports-section">
        <div class="rs-head">
          <div class="panel-icon blue"><i class="bi bi-file-earmark-bar-graph-fill"></i></div>
          <div>
            <h2 class="panel-title">All Generated Reports</h2>
            <p class="panel-sub">Reports from both Auditor and Compliance Officer, consolidated</p>
          </div>
        </div>
        @if (loadingReports()) {
          <div class="load-row"><span class="spin"></span> Loading reports...</div>
        } @else if (reports().length === 0) {
          <div class="mini-empty">
            <i class="bi bi-file-earmark-x"></i>
            <p>No reports generated yet</p>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr><th>Scope</th><th>Generated By</th><th>Date</th><th>Metrics Preview</th></tr>
              </thead>
              <tbody>
                @for (r of reports(); track r.reportId) {
                  <tr>
                    <td><span class="scope-pill" [attr.data-scope]="r.scope.toLowerCase()">{{ r.scope }}</span></td>
                    <td class="cell-main">{{ r.generatedBy }}</td>
                    <td class="muted">{{ r.generatedDate | date:'mediumDate' }}</td>
                    <td class="muted">{{ r.metrics ? (r.metrics | slice:0:70) + '...' : '—' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </section>
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page{display:flex;flex-direction:column;gap:1.75rem;}
    .page-head{display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap;}
    .eyebrow{display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;}
    .page-title{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0;}
    .page-desc{font-size:0.92rem;color:var(--text-muted);margin-top:6px;}
    .ro-badge{display:inline-flex;align-items:center;gap:7px;padding:0.55rem 1.1rem;background:rgba(240,165,0,0.12);border:1px solid rgba(240,165,0,0.3);border-radius:10px;color:var(--gold);font-size:0.82rem;font-weight:700;flex-shrink:0;}
    .sum-strip{display:grid;grid-template-columns:repeat(5,1fr);gap:1rem;}
    .ss-item{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;padding:1.25rem;text-align:center;transition:all 0.2s;&:hover{transform:translateY(-3px);}
      &[data-tone="rose"]{border-top:3px solid var(--rose);.ss-icon{color:var(--rose);}}
      &[data-tone="purple"]{border-top:3px solid var(--purple);.ss-icon{color:var(--purple);}}
      &[data-tone="mint"]{border-top:3px solid var(--mint);.ss-icon{color:var(--mint);}}
      &[data-tone="gold"]{border-top:3px solid var(--gold);.ss-icon{color:var(--gold);}}
      &[data-tone="blue"]{border-top:3px solid var(--accent);.ss-icon{color:var(--accent-light);}}
    }
    .ss-icon{font-size:1.4rem;margin-bottom:0.5rem;}
    .ss-val{font-family:'Fraunces',serif;font-size:1.8rem;font-weight:800;color:#fff;letter-spacing:-0.02em;}
    .ss-lbl{font-size:0.72rem;color:var(--text-muted);font-weight:600;text-transform:uppercase;letter-spacing:0.06em;margin-top:2px;}
    .ov-grid{display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;}
    .ov-panel,.reports-section{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.5rem;display:flex;flex-direction:column;gap:1.25rem;}
    .rs-head,.panel-head{display:flex;align-items:flex-start;gap:1rem;}
    .panel-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;
      &.rose{background:rgba(251,113,133,0.15);color:var(--rose);}
      &.purple{background:rgba(167,139,250,0.15);color:var(--purple);}
      &.blue{background:rgba(46,123,246,0.15);color:var(--accent-light);}
    }
    .panel-title{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:700;color:#fff;margin:0;}
    .panel-sub{font-size:0.82rem;color:var(--text-muted);margin-top:4px;}
    .table-wrap{overflow-x:auto;border-radius:14px;border:1px solid var(--border);}
    .ec-table{width:100%;border-collapse:collapse;
      thead tr{background:rgba(255,255,255,0.03);}
      th{padding:0.75rem 1rem;font-size:0.7rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;}
      td{padding:0.8rem 1rem;font-size:0.85rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);}
      tbody tr:last-child td{border-bottom:none;}
      tbody tr:hover{background:rgba(255,255,255,0.02);}
    }
    .cell-main{font-weight:600;color:#fff;}
    .cell-sub{font-size:0.75rem;color:var(--text-muted);margin-top:2px;}
    .muted{color:var(--text-muted);font-size:0.82rem;}
    .audit-status{display:inline-flex;align-items:center;padding:2px 9px;border-radius:100px;font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;}
    .as-scheduled{background:rgba(245,158,11,0.15);color:#FCD34D;}
    .as-in-progress{background:rgba(46,123,246,0.15);color:var(--accent-light);}
    .as-completed{background:rgba(0,201,167,0.15);color:var(--mint);}
    .as-cancelled{background:rgba(239,68,68,0.15);color:#FCA5A5;}
    .type-pill{display:inline-flex;padding:2px 9px;border-radius:100px;font-size:0.68rem;font-weight:700;text-transform:uppercase;background:rgba(167,139,250,0.12);color:var(--purple);}
    .result-badge{display:inline-flex;padding:2px 9px;border-radius:100px;font-size:0.68rem;font-weight:700;text-transform:uppercase;}
    .rb-compliant{background:rgba(0,201,167,0.15);color:var(--mint);}
    .rb-non-compliant{background:rgba(251,113,133,0.15);color:var(--rose);}
    .rb-under-review{background:rgba(240,165,0,0.15);color:var(--gold);}
    .rb-remediated{background:rgba(46,123,246,0.15);color:var(--accent-light);}
    .rb-pending{background:rgba(148,163,184,0.1);color:#94A3B8;}
    .scope-pill{display:inline-flex;padding:2px 9px;border-radius:100px;font-size:0.68rem;font-weight:700;text-transform:uppercase;
      &[data-scope="compliance"]{background:rgba(167,139,250,0.12);color:var(--purple);}
      &[data-scope="program"]{background:rgba(46,123,246,0.12);color:var(--accent-light);}
      &[data-scope="course"]{background:rgba(0,201,167,0.12);color:var(--mint);}
      &[data-scope="assessment"]{background:rgba(251,113,133,0.12);color:var(--rose);}
      &[data-scope="dashboard"]{background:rgba(240,165,0,0.12);color:var(--gold);}
    }
    .mini-empty{padding:2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:12px;
      i{font-size:1.8rem;color:var(--text-muted);display:block;margin-bottom:0.5rem;}
      p{font-size:0.85rem;color:var(--text-muted);margin:0;}
    }
    .load-row{display:flex;align-items:center;gap:8px;padding:1.25rem;color:var(--text-muted);font-size:0.875rem;}
    .spin{display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;}
    @media(max-width:900px){.ov-grid{grid-template-columns:1fr;}.sum-strip{grid-template-columns:repeat(3,1fr);}}
    @media(max-width:560px){.sum-strip{grid-template-columns:repeat(2,1fr);}}
    @keyframes spin{to{transform:rotate(360deg);}}
  `],
})
export class AdminAuditOverviewComponent implements OnInit {
  private auditSvc      = inject(AuditService);
  private complianceSvc = inject(ComplianceService);
  private reportSvc     = inject(ReportService);

  loadingAudits     = signal(true);
  loadingCompliance = signal(true);
  loadingReports    = signal(true);

  audits            = signal<Audit[]>([]);
  complianceRecords = signal<ComplianceRecord[]>([]);
  reports           = signal<Report[]>([]);

  compliantCount = computed(() => this.complianceRecords().filter(r => r.result === 'COMPLIANT').length);
  auditInProgress = computed(() => this.audits().filter(a => a.status === 'IN_PROGRESS').length);

  ngOnInit(): void {
    this.auditSvc.getAll().subscribe({
      next: r => { if (r.success) this.audits.set(r.data ?? []); this.loadingAudits.set(false); },
      error: () => this.loadingAudits.set(false),
    });
    this.complianceSvc.getAll().subscribe({
      next: r => { if (r.success) this.complianceRecords.set(r.data ?? []); this.loadingCompliance.set(false); },
      error: () => this.loadingCompliance.set(false),
    });
    this.reportSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          // Show compliance + program scoped reports (generated by auditor/compliance)
          const relevant = (r.data ?? []).filter(x =>
            x.scope === 'COMPLIANCE' || x.scope === 'PROGRAM'
          );
          this.reports.set(relevant);
        }
        this.loadingReports.set(false);
      },
      error: () => this.loadingReports.set(false),
    });
  }
}
