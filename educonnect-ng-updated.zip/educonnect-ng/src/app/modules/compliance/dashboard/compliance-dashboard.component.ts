import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ComplianceService, ReportService, ToastService } from '../../../core/services/index';
import { ComplianceRecord, ComplianceResult, ComplianceType, Report } from '../../../core/models';

@Component({
  selector: 'app-compliance-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Governance & Policy</span>
          <h1 class="page-title">Compliance Dashboard</h1>
          <p class="page-desc">Monitor policy adherence, manage compliance records, and generate regulatory reports</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">
          <i class="bi bi-plus-circle-fill"></i> Add Record
        </button>
      </header>

      <!-- Summary -->
      <div class="sum-grid">
        <div class="sum-card" data-tone="mint">
          <div class="sum-icon"><i class="bi bi-shield-check-fill"></i></div>
          <div class="sum-val">{{ countByResult('COMPLIANT') }}</div>
          <div class="sum-label">Compliant</div>
        </div>
        <div class="sum-card" data-tone="rose">
          <div class="sum-icon"><i class="bi bi-shield-exclamation-fill"></i></div>
          <div class="sum-val">{{ countByResult('NON_COMPLIANT') }}</div>
          <div class="sum-label">Non-Compliant</div>
        </div>
        <div class="sum-card" data-tone="gold">
          <div class="sum-icon"><i class="bi bi-hourglass-split"></i></div>
          <div class="sum-val">{{ countByResult('UNDER_REVIEW') }}</div>
          <div class="sum-label">Under Review</div>
        </div>
        <div class="sum-card" data-tone="blue">
          <div class="sum-icon"><i class="bi bi-arrow-repeat"></i></div>
          <div class="sum-val">{{ countByResult('REMEDIATED') }}</div>
          <div class="sum-label">Remediated</div>
        </div>
        <div class="sum-card" data-tone="purple">
          <div class="sum-icon"><i class="bi bi-list-check"></i></div>
          <div class="sum-val">{{ records().length }}</div>
          <div class="sum-label">Total Records</div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="tab-bar">
        <button class="tab-item" [class.active]="tab() === 'records'" (click)="tab.set('records')">
          <i class="bi bi-shield-check"></i> Records
          <span class="tab-count">{{ records().length }}</span>
        </button>
        <button class="tab-item" [class.active]="tab() === 'reports'" (click)="tab.set('reports')">
          <i class="bi bi-file-earmark-bar-graph"></i> Reports
          <span class="tab-count">{{ reports().length }}</span>
        </button>
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      }

      <!-- Records tab -->
      @if (!loading() && tab() === 'records') {
        <!-- Filter bar -->
        <div class="filter-bar">
          <select class="filter-select" [(ngModel)]="filterResult" (ngModelChange)="applyFilter()">
            <option value="">All Results</option>
            @for (r of results; track r) {
              <option [value]="r">{{ r.replace('_', ' ') }}</option>
            }
          </select>
          <select class="filter-select" [(ngModel)]="filterType" (ngModelChange)="applyFilter()">
            <option value="">All Types</option>
            @for (t of types; track t) {
              <option [value]="t">{{ t }}</option>
            }
          </select>
        </div>

        @if (filtered().length === 0) {
          <div class="empty-state">
            <i class="bi bi-shield-check"></i>
            <h3>No compliance records found</h3>
            <p>Add compliance records to start tracking policy adherence.</p>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr>
                  <th>Entity ID</th><th>Type</th><th>Result</th><th>Recorded</th><th>Notes</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                @for (rec of filtered(); track rec.complianceId) {
                  <tr>
                    <td class="cell-main">#{{ rec.entityId }}</td>
                    <td><span class="type-pill" [attr.data-type]="rec.type.toLowerCase()">{{ rec.type }}</span></td>
                    <td>
                      <span class="result-badge" [ngClass]="'rb-' + rec.result?.toLowerCase().replace('_','-')">
                        {{ rec.result?.replace('_',' ') ?? 'PENDING' }}
                      </span>
                    </td>
                    <td class="muted">{{ rec.recordDate | date:'mediumDate' }}</td>
                    <td class="muted">{{ rec.notes ?? '—' }}</td>
                    <td>
                      <div class="row-actions">
                        <button class="action-btn mint" (click)="updateResult(rec, 'COMPLIANT')" title="Mark Compliant">
                          <i class="bi bi-check-circle-fill"></i>
                        </button>
                        <button class="action-btn warning" (click)="updateResult(rec, 'UNDER_REVIEW')" title="Under Review">
                          <i class="bi bi-hourglass-split"></i>
                        </button>
                        <button class="action-btn rose" (click)="updateResult(rec, 'NON_COMPLIANT')" title="Non-Compliant">
                          <i class="bi bi-x-circle-fill"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Reports tab -->
      @if (!loading() && tab() === 'reports') {
        <div class="reports-actions">
          <button class="btn btn-primary" (click)="generateReport()" [disabled]="generating()">
            @if (generating()) { <span class="spinner"></span> Generating... }
            @else { <i class="bi bi-file-earmark-plus-fill"></i> Generate Compliance Report }
          </button>
        </div>
        @if (reports().length === 0) {
          <div class="empty-state">
            <i class="bi bi-file-earmark-bar-graph"></i>
            <h3>No compliance reports yet</h3>
            <p>Generate your first report to document compliance status.</p>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr><th>Scope</th><th>Generated By</th><th>Date</th><th>Metrics</th></tr>
              </thead>
              <tbody>
                @for (r of reports(); track r.reportId) {
                  <tr>
                    <td><span class="scope-pill">{{ r.scope }}</span></td>
                    <td class="cell-main">{{ r.generatedBy }}</td>
                    <td class="muted">{{ r.generatedDate | date:'mediumDate' }}</td>
                    <td class="muted">{{ r.metrics ? (r.metrics | slice:0:80) + '...' : '—' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Create Modal -->
      @if (showCreateModal()) {
        <div class="modal-backdrop" (click)="showCreateModal.set(false)">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <div>
                <h3 class="modal-title">Add Compliance Record</h3>
                <p class="modal-sub">Log a new policy adherence record</p>
              </div>
              <button class="modal-close" (click)="showCreateModal.set(false)"><i class="bi bi-x"></i></button>
            </div>
            <form [formGroup]="createForm" (ngSubmit)="doCreate()">
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">Entity ID *</label>
                  <input formControlName="entityId" type="number" class="form-control" placeholder="e.g. 101" />
                  @if (createForm.get('entityId')?.invalid && createForm.get('entityId')?.touched) {
                    <span class="err">Entity ID required</span>
                  }
                </div>
                <div class="form-group">
                  <label class="form-label">Type *</label>
                  <select formControlName="type" class="form-select">
                    <option value="" disabled>Select type</option>
                    @for (t of types; track t) {
                      <option [value]="t">{{ t }}</option>
                    }
                  </select>
                  @if (createForm.get('type')?.invalid && createForm.get('type')?.touched) {
                    <span class="err">Type required</span>
                  }
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Notes</label>
                <textarea formControlName="notes" class="form-control" rows="3" placeholder="Compliance notes or observations..."></textarea>
              </div>
              @if (createError()) {
                <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ createError() }}</div>
              }
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="showCreateModal.set(false)">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="creating() || createForm.invalid">
                  @if (creating()) { <span class="spinner"></span> Saving... }
                  @else { <i class="bi bi-plus-circle-fill"></i> Add Record }
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page{display:flex;flex-direction:column;gap:1.5rem;}
    .page-head{display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap;}
    .eyebrow{display:block;font-size:0.72rem;font-weight:700;color:var(--purple);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;}
    .page-title{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0;}
    .page-desc{font-size:0.92rem;color:var(--text-muted);margin-top:6px;}
    .sum-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:1rem;}
    .sum-card{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;padding:1.25rem;text-align:center;transition:all 0.2s;&:hover{transform:translateY(-3px);}
      &[data-tone="mint"]{border-top:3px solid var(--mint);.sum-icon{color:var(--mint);}}
      &[data-tone="rose"]{border-top:3px solid var(--rose);.sum-icon{color:var(--rose);}}
      &[data-tone="gold"]{border-top:3px solid var(--gold);.sum-icon{color:var(--gold);}}
      &[data-tone="blue"]{border-top:3px solid var(--accent);.sum-icon{color:var(--accent-light);}}
      &[data-tone="purple"]{border-top:3px solid var(--purple);.sum-icon{color:var(--purple);}}
    }
    .sum-icon{font-size:1.4rem;margin-bottom:0.5rem;}
    .sum-val{font-size:1.8rem;font-weight:800;color:#fff;}
    .sum-label{font-size:0.75rem;color:var(--text-muted);font-weight:600;text-transform:uppercase;letter-spacing:0.06em;margin-top:2px;}
    .tab-bar{display:flex;gap:6px;padding:6px;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;width:fit-content;overflow-x:auto;}
    .tab-item{display:inline-flex;align-items:center;gap:8px;padding:0.55rem 1rem;background:transparent;border:none;color:var(--text-muted);font-size:0.85rem;font-weight:600;font-family:inherit;border-radius:8px;cursor:pointer;transition:all 0.2s;
      .tab-count{font-size:0.72rem;padding:2px 8px;border-radius:100px;background:rgba(255,255,255,0.06);color:var(--text-muted);}
      &.active{background:linear-gradient(135deg,rgba(167,139,250,0.2),rgba(46,123,246,0.15));color:#fff;.tab-count{background:rgba(255,255,255,0.12);color:#fff;}}
    }
    .filter-bar{display:flex;gap:0.75rem;flex-wrap:wrap;}
    .filter-select{padding:0.5rem 0.85rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.85rem;font-family:inherit;outline:none;cursor:pointer;option{background:#1A2F5E;}}
    .table-wrap{overflow-x:auto;border-radius:16px;border:1px solid var(--border);}
    .ec-table{width:100%;border-collapse:collapse;
      thead tr{background:rgba(255,255,255,0.03);}
      th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;}
      td{padding:0.875rem 1rem;font-size:0.875rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);}
      tbody tr:last-child td{border-bottom:none;}
      tbody tr:hover{background:rgba(255,255,255,0.025);}
    }
    .cell-main{font-weight:600;color:#fff;}
    .muted{color:var(--text-muted);font-size:0.85rem;}
    .type-pill{display:inline-flex;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;
      &[data-type="course"]{background:rgba(46,123,246,0.12);color:var(--accent-light);}
      &[data-type="assessment"]{background:rgba(240,165,0,0.12);color:var(--gold);}
      &[data-type="program"]{background:rgba(167,139,250,0.12);color:var(--purple);}
      &[data-type="content"]{background:rgba(0,201,167,0.12);color:var(--mint);}
    }
    .result-badge{display:inline-flex;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;}
    .rb-compliant{background:rgba(0,201,167,0.15);color:var(--mint);border:1px solid rgba(0,201,167,0.25);}
    .rb-non-compliant{background:rgba(251,113,133,0.15);color:var(--rose);border:1px solid rgba(251,113,133,0.25);}
    .rb-under-review{background:rgba(240,165,0,0.15);color:var(--gold);border:1px solid rgba(240,165,0,0.25);}
    .rb-remediated{background:rgba(46,123,246,0.15);color:var(--accent-light);border:1px solid rgba(46,123,246,0.25);}
    .scope-pill{display:inline-flex;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;background:rgba(167,139,250,0.12);color:var(--purple);border:1px solid rgba(167,139,250,0.2);}
    .row-actions{display:flex;gap:0.4rem;}
    .action-btn{width:30px;height:30px;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:8px;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:0.85rem;transition:all 0.2s;
      &.mint:hover{background:rgba(0,201,167,0.15);color:var(--mint);border-color:rgba(0,201,167,0.3);}
      &.warning:hover{background:rgba(240,165,0,0.15);color:var(--gold);border-color:rgba(240,165,0,0.3);}
      &.rose:hover{background:rgba(251,113,133,0.15);color:var(--rose);border-color:rgba(251,113,133,0.3);}
    }
    .reports-actions{display:flex;justify-content:flex-end;}
    .empty-state{padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;
      i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;}
      h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;}
      p{font-size:0.875rem;color:var(--text-muted);}
    }
    .load-center{display:flex;justify-content:center;padding:3rem;}
    .ec-spin{display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite;}
    .modal-backdrop{position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease;}
    .modal{background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:540px;max-height:90vh;overflow-y:auto;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease;}
    .modal-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.5rem;}
    .modal-title{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;margin:0;}
    .modal-sub{font-size:0.85rem;color:var(--text-muted);margin-top:4px;}
    .modal-close{width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--text-muted);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;}}
    .form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
    .form-group{margin-bottom:1rem;}
    .form-label{display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em;}
    .form-control{width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);}}
    .form-select{width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;cursor:pointer;appearance:none;option{background:#1A2F5E;}}
    textarea.form-control{min-height:80px;resize:vertical;}
    .err{font-size:0.75rem;color:#FCA5A5;margin-top:4px;display:block;}
    .alert-error{display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1rem;}
    .modal-footer{display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem;}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.25rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;&:disabled{opacity:0.55;cursor:not-allowed;}}
    .btn-primary{background:linear-gradient(135deg,var(--purple),#7C3AED);color:#fff;box-shadow:0 6px 18px rgba(167,139,250,0.3);&:hover:not(:disabled){transform:translateY(-2px);}}
    .btn-ghost{background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);}}
    .spinner{display:inline-block;width:16px;height:16px;border:2px solid rgba(255,255,255,0.2);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;}
    @keyframes spin{to{transform:rotate(360deg);}}
    @keyframes fadeIn{from{opacity:0;}to{opacity:1;}}
    @keyframes slideUp{from{opacity:0;transform:translateY(24px);}to{opacity:1;transform:none;}}
    @media(max-width:640px){.form-row{grid-template-columns:1fr;}}
  `],
})
export class ComplianceDashboardComponent implements OnInit {
  private complianceSvc = inject(ComplianceService);
  private reportSvc     = inject(ReportService);
  private toast         = inject(ToastService);
  private fb            = inject(FormBuilder);

  loading         = signal(true);
  tab             = signal<'records'|'reports'>('records');
  records         = signal<ComplianceRecord[]>([]);
  reports         = signal<Report[]>([]);
  filtered        = signal<ComplianceRecord[]>([]);
  showCreateModal = signal(false);
  creating        = signal(false);
  generating      = signal(false);
  createError     = signal('');

  filterResult = '';
  filterType   = '';

  types:   ComplianceType[]   = ['COURSE', 'ASSESSMENT', 'PROGRAM', 'CONTENT'];
  results: ComplianceResult[] = ['COMPLIANT', 'NON_COMPLIANT', 'UNDER_REVIEW', 'REMEDIATED'];

  createForm = this.fb.nonNullable.group({
    entityId: [null as unknown as number, [Validators.required, Validators.min(1)]],
    type:     ['', Validators.required],
    notes:    [''],
  });

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.complianceSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          this.records.set(r.data ?? []);
          this.filtered.set(r.data ?? []);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
    this.reportSvc.getAll().subscribe({
      next: r => { if (r.success) this.reports.set((r.data ?? []).filter(x => x.scope === 'COMPLIANCE')); },
    });
  }

  countByResult(result: string): number {
    return this.records().filter(r => r.result === result).length;
  }

  applyFilter(): void {
    let list = this.records();
    if (this.filterResult) list = list.filter(r => r.result === this.filterResult);
    if (this.filterType)   list = list.filter(r => r.type   === this.filterType);
    this.filtered.set(list);
  }

  openCreate(): void { this.createForm.reset(); this.createError.set(''); this.showCreateModal.set(true); }

  doCreate(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.creating.set(true);
    this.complianceSvc.create(this.createForm.getRawValue() as any).subscribe({
      next: r => {
        this.creating.set(false);
        if (r.success) {
          this.records.update(arr => [r.data, ...arr]);
          this.filtered.update(arr => [r.data, ...arr]);
          this.showCreateModal.set(false);
          this.toast.success('Record added!', 'Compliance record has been saved.');
        } else { this.createError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.creating.set(false); this.createError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  updateResult(rec: ComplianceRecord, result: ComplianceResult): void {
    this.complianceSvc.updateResult(rec.complianceId, result).subscribe({
      next: r => {
        if (r.success) {
          const updated = (arr: ComplianceRecord[]) => arr.map(x => x.complianceId === rec.complianceId ? { ...x, result } : x);
          this.records.update(updated);
          this.filtered.update(updated);
          this.toast.success('Result updated', `Marked as ${result.replace('_',' ')}.`);
        }
      },
    });
  }

  generateReport(): void {
    this.generating.set(true);
    this.reportSvc.generate('COMPLIANCE').subscribe({
      next: r => {
        this.generating.set(false);
        if (r.success) {
          this.reports.update(arr => [r.data, ...arr]);
          this.toast.success('Report generated!', 'Compliance report is ready.');
        }
      },
      error: () => this.generating.set(false),
    });
  }
}
