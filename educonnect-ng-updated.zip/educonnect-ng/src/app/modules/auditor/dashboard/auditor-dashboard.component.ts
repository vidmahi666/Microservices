import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AuditService, ReportService, ToastService } from '../../../core/services/index';
import { Audit, AuditLog, AuditStatus, Report } from '../../../core/models';

@Component({
  selector: 'app-auditor-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Government Oversight</span>
          <h1 class="page-title">Auditor Dashboard</h1>
          <p class="page-desc">Schedule, manage and track formal government audits of the EduConnect platform</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">
          <i class="bi bi-plus-circle-fill"></i> Initiate Audit
        </button>
      </header>

      <!-- Summary cards -->
      <div class="sum-grid">
        @for (s of summary(); track s.label) {
          <div class="sum-card" [attr.data-tone]="s.tone">
            <div class="sum-icon"><i class="bi" [ngClass]="s.icon"></i></div>
            <div class="sum-val">{{ s.count }}</div>
            <div class="sum-label">{{ s.label }}</div>
          </div>
        }
      </div>

      <!-- Tabs -->
      <div class="tab-bar">
        <button class="tab-item" [class.active]="tab() === 'audits'" (click)="tab.set('audits')">
          <i class="bi bi-search"></i> My Audits
          <span class="tab-count">{{ audits().length }}</span>
        </button>
        <button class="tab-item" [class.active]="tab() === 'logs'" (click)="loadLogs(); tab.set('logs')">
          <i class="bi bi-journal-text"></i> Audit Logs
        </button>
        <button class="tab-item" [class.active]="tab() === 'reports'" (click)="tab.set('reports')">
          <i class="bi bi-file-earmark-bar-graph"></i> Reports
          <span class="tab-count">{{ reports().length }}</span>
        </button>
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      }

      <!-- Audits tab -->
      @if (!loading() && tab() === 'audits') {
        @if (audits().length === 0) {
          <div class="empty-state">
            <i class="bi bi-search"></i>
            <h3>No audits initiated</h3>
            <p>Click "Initiate Audit" to begin a formal government review.</p>
          </div>
        } @else {
          <div class="audit-list">
            @for (a of audits(); track a.auditId) {
              <div class="audit-card">
                <div class="ac-head">
                  <div class="ac-left">
                    <span class="audit-status" [ngClass]="'as-' + a.status.toLowerCase().replace('_','-')">
                      <i class="bi" [ngClass]="statusIcon(a.status)"></i> {{ a.status.replace('_',' ') }}
                    </span>
                    <h3 class="audit-title">{{ a.title }}</h3>
                    @if (a.description) {
                      <p class="audit-desc">{{ a.description }}</p>
                    }
                    <span class="audit-date"><i class="bi bi-calendar3"></i> Initiated {{ a.createdAt | date:'mediumDate' }}</span>
                  </div>
                  <div class="ac-actions">
                    @if (a.status === 'SCHEDULED') {
                      <button class="action-btn mint" (click)="updateStatus(a, 'IN_PROGRESS')" title="Start audit">
                        <i class="bi bi-play-fill"></i>
                      </button>
                    }
                    @if (a.status === 'IN_PROGRESS') {
                      <button class="action-btn mint" (click)="updateStatus(a, 'COMPLETED')" title="Complete">
                        <i class="bi bi-check-circle-fill"></i>
                      </button>
                      <button class="action-btn warning" (click)="updateStatus(a, 'CANCELLED')" title="Cancel">
                        <i class="bi bi-x-circle-fill"></i>
                      </button>
                    }
                  </div>
                </div>
              </div>
            }
          </div>
        }
      }

      <!-- Audit Logs tab -->
      @if (!loading() && tab() === 'logs') {
        @if (logs().length === 0) {
          <div class="empty-state">
            <i class="bi bi-journal-text"></i>
            <h3>No audit logs available</h3>
            <p>System activity logs will appear here.</p>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr>
                  <th>Timestamp</th><th>Entity Type</th><th>Action</th><th>Details</th>
                </tr>
              </thead>
              <tbody>
                @for (log of logs(); track log.logId) {
                  <tr>
                    <td class="muted">{{ log.timestamp | date:'short' }}</td>
                    <td><span class="entity-pill">{{ log.entityType }}</span></td>
                    <td class="cell-main">{{ log.action }}</td>
                    <td class="muted">{{ log.details ?? '—' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Reports tab -->
      @if (!loading() && tab() === 'reports') {
        <div class="reports-actions">
          <button class="btn btn-primary" (click)="generateReport()" [disabled]="generating()">
            @if (generating()) { <span class="spinner"></span> Generating... }
            @else { <i class="bi bi-file-earmark-plus-fill"></i> Generate Audit Report }
          </button>
        </div>
        @if (reports().length === 0) {
          <div class="empty-state">
            <i class="bi bi-file-earmark-bar-graph"></i>
            <h3>No reports yet</h3>
            <p>Generate a report to create a formal audit document.</p>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr><th>Scope</th><th>Generated By</th><th>Date</th><th>Metrics Summary</th></tr>
              </thead>
              <tbody>
                @for (r of reports(); track r.reportId) {
                  <tr>
                    <td><span class="scope-pill">{{ r.scope }}</span></td>
                    <td class="cell-main">{{ r.generatedBy }}</td>
                    <td class="muted">{{ r.generatedDate | date:'mediumDate' }}</td>
                    <td class="muted">{{ r.metrics ? (r.metrics | slice:0:80) + '...' : 'No metrics' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Create Modal -->
      @if (showCreateModal()) {
        <div class="modal-backdrop" (click)="showCreateModal.set(false)">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <div>
                <h3 class="modal-title">Initiate New Audit</h3>
                <p class="modal-sub">Schedule a formal government audit review</p>
              </div>
              <button class="modal-close" (click)="showCreateModal.set(false)"><i class="bi bi-x"></i></button>
            </div>
            <form [formGroup]="auditForm" (ngSubmit)="doCreate()">
              <div class="form-group">
                <label class="form-label">Audit Title *</label>
                <input formControlName="title" type="text" class="form-control" placeholder="e.g. Annual Compliance Review 2025" />
                @if (auditForm.get('title')?.invalid && auditForm.get('title')?.touched) {
                  <span class="err">Title is required</span>
                }
              </div>
              <div class="form-group">
                <label class="form-label">Description</label>
                <textarea formControlName="description" class="form-control" rows="3" placeholder="Scope and objectives of this audit..."></textarea>
              </div>
              @if (createError()) {
                <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ createError() }}</div>
              }
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="showCreateModal.set(false)">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="creating() || auditForm.invalid">
                  @if (creating()) { <span class="spinner"></span> Saving... }
                  @else { <i class="bi bi-check-circle-fill"></i> Initiate Audit }
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page{display:flex;flex-direction:column;gap:1.5rem;}
    .page-head{display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap;}
    .eyebrow{display:block;font-size:0.72rem;font-weight:700;color:var(--rose);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;}
    .page-title{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0;}
    .page-desc{font-size:0.92rem;color:var(--text-muted);margin-top:6px;}
    .sum-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:1rem;}
    .sum-card{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;padding:1.25rem;text-align:center;transition:all 0.2s;&:hover{transform:translateY(-3px);}
      &[data-tone="mint"]{border-top:3px solid var(--mint);.sum-icon{color:var(--mint);}}
      &[data-tone="gold"]{border-top:3px solid var(--gold);.sum-icon{color:var(--gold);}}
      &[data-tone="rose"]{border-top:3px solid var(--rose);.sum-icon{color:var(--rose);}}
      &[data-tone="blue"]{border-top:3px solid var(--accent);.sum-icon{color:var(--accent-light);}}
    }
    .sum-icon{font-size:1.4rem;margin-bottom:0.5rem;}
    .sum-val{font-size:1.8rem;font-weight:800;color:#fff;}
    .sum-label{font-size:0.75rem;color:var(--text-muted);font-weight:600;text-transform:uppercase;letter-spacing:0.06em;margin-top:2px;}
    .tab-bar{display:flex;gap:6px;padding:6px;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;width:fit-content;overflow-x:auto;}
    .tab-item{display:inline-flex;align-items:center;gap:8px;padding:0.55rem 1rem;background:transparent;border:none;color:var(--text-muted);font-size:0.85rem;font-weight:600;font-family:inherit;border-radius:8px;cursor:pointer;transition:all 0.2s;
      .tab-count{font-size:0.72rem;padding:2px 8px;border-radius:100px;background:rgba(255,255,255,0.06);color:var(--text-muted);}
      &.active{background:linear-gradient(135deg,rgba(251,113,133,0.2),rgba(46,123,246,0.15));color:#fff;.tab-count{background:rgba(255,255,255,0.12);color:#fff;}}
    }
    .audit-list{display:flex;flex-direction:column;gap:1rem;}
    .audit-card{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;padding:1.5rem;transition:all 0.25s;&:hover{border-color:rgba(251,113,133,0.3);}}
    .ac-head{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;}
    .ac-left{display:flex;flex-direction:column;gap:0.4rem;}
    .ac-actions{display:flex;gap:0.4rem;flex-shrink:0;}
    .audit-title{font-size:1rem;font-weight:700;color:#fff;margin:0;}
    .audit-desc{font-size:0.85rem;color:var(--text-muted);margin:0;}
    .audit-date{font-size:0.78rem;color:var(--text-muted);display:flex;align-items:center;gap:5px;}
    .audit-status{display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:100px;font-size:0.72rem;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;}
    .as-scheduled{background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25);}
    .as-in-progress{background:rgba(46,123,246,0.15);color:var(--accent-light);border:1px solid rgba(46,123,246,0.25);}
    .as-completed{background:rgba(0,201,167,0.15);color:var(--mint);border:1px solid rgba(0,201,167,0.25);}
    .as-cancelled{background:rgba(239,68,68,0.15);color:#FCA5A5;border:1px solid rgba(239,68,68,0.25);}
    .action-btn{width:32px;height:32px;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:8px;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:0.9rem;transition:all 0.2s;
      &:hover{background:rgba(46,123,246,0.15);color:var(--accent-light);border-color:rgba(46,123,246,0.3);}
      &.mint:hover{background:rgba(0,201,167,0.15);color:var(--mint);border-color:rgba(0,201,167,0.3);}
      &.warning:hover{background:rgba(240,165,0,0.15);color:var(--gold);border-color:rgba(240,165,0,0.3);}
    }
    .table-wrap{overflow-x:auto;border-radius:16px;border:1px solid var(--border);}
    .ec-table{width:100%;border-collapse:collapse;
      thead tr{background:rgba(255,255,255,0.03);}
      th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;}
      td{padding:0.875rem 1rem;font-size:0.875rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);}
      tbody tr:last-child td{border-bottom:none;}
      tbody tr:hover{background:rgba(255,255,255,0.025);}
    }
    .cell-main{font-weight:600;color:#fff;}
    .muted{color:var(--text-muted);font-size:0.85rem;}
    .entity-pill{display:inline-flex;align-items:center;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;background:rgba(251,113,133,0.12);color:var(--rose);border:1px solid rgba(251,113,133,0.2);}
    .scope-pill{display:inline-flex;align-items:center;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;background:rgba(46,123,246,0.12);color:var(--accent-light);border:1px solid rgba(46,123,246,0.2);}
    .reports-actions{display:flex;justify-content:flex-end;}
    .empty-state{padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;
      i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;}
      h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;}
      p{font-size:0.875rem;color:var(--text-muted);}
    }
    .load-center{display:flex;justify-content:center;padding:3rem;}
    .ec-spin{display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite;}
    .modal-backdrop{position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease;}
    .modal{background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:520px;max-height:90vh;overflow-y:auto;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease;}
    .modal-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.5rem;}
    .modal-title{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;margin:0;}
    .modal-sub{font-size:0.85rem;color:var(--text-muted);margin-top:4px;}
    .modal-close{width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--text-muted);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;}}
    .form-group{margin-bottom:1rem;}
    .form-label{display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em;}
    .form-control{width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);}}
    textarea.form-control{min-height:80px;resize:vertical;}
    .err{font-size:0.75rem;color:#FCA5A5;margin-top:4px;display:block;}
    .alert-error{display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1rem;}
    .modal-footer{display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem;}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.25rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;&:disabled{opacity:0.55;cursor:not-allowed;}}
    .btn-primary{background:linear-gradient(135deg,var(--rose),#C84B5C);color:#fff;box-shadow:0 6px 18px rgba(251,113,133,0.3);&:hover:not(:disabled){transform:translateY(-2px);}}
    .btn-ghost{background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);}}
    .spinner{display:inline-block;width:16px;height:16px;border:2px solid rgba(255,255,255,0.2);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;}
    @keyframes spin{to{transform:rotate(360deg);}}
    @keyframes fadeIn{from{opacity:0;}to{opacity:1;}}
    @keyframes slideUp{from{opacity:0;transform:translateY(24px);}to{opacity:1;transform:none;}}
  `],
})
export class AuditorDashboardComponent implements OnInit {
  private auth      = inject(AuthService);
  private auditSvc  = inject(AuditService);
  private reportSvc = inject(ReportService);
  private toast     = inject(ToastService);
  private fb        = inject(FormBuilder);

  loading         = signal(true);
  tab             = signal<'audits'|'logs'|'reports'>('audits');
  audits          = signal<Audit[]>([]);
  logs            = signal<AuditLog[]>([]);
  reports         = signal<Report[]>([]);
  showCreateModal = signal(false);
  creating        = signal(false);
  generating      = signal(false);
  createError     = signal('');

  summary = computed(() => [
    { label: 'Scheduled',   tone: 'gold', icon: 'bi-calendar-check', count: this.audits().filter(a => a.status === 'SCHEDULED').length },
    { label: 'In Progress', tone: 'blue', icon: 'bi-hourglass-split', count: this.audits().filter(a => a.status === 'IN_PROGRESS').length },
    { label: 'Completed',   tone: 'mint', icon: 'bi-check-circle-fill', count: this.audits().filter(a => a.status === 'COMPLETED').length },
    { label: 'Cancelled',   tone: 'rose', icon: 'bi-x-circle-fill', count: this.audits().filter(a => a.status === 'CANCELLED').length },
  ]);

  auditForm = this.fb.nonNullable.group({
    title:       ['', Validators.required],
    description: [''],
  });

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.auditSvc.getAll().subscribe({
      next: r => {
        if (r.success) this.audits.set(r.data ?? []);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
    this.reportSvc.getAll().subscribe({
      next: r => { if (r.success) this.reports.set((r.data ?? []).filter(x => x.scope === 'COMPLIANCE' || x.scope === 'PROGRAM')); },
    });
  }

  loadLogs(): void {
    if (this.logs().length) return;
    this.auditSvc.getLogs().subscribe({
      next: r => { if (r.success) this.logs.set(r.data ?? []); },
    });
  }

  statusIcon(s: AuditStatus): string {
    const m: Record<string, string> = {
      SCHEDULED: 'bi-calendar-check', IN_PROGRESS: 'bi-hourglass-split',
      COMPLETED: 'bi-check-circle-fill', CANCELLED: 'bi-x-circle-fill',
    };
    return m[s] ?? 'bi-circle';
  }

  openCreate(): void { this.auditForm.reset(); this.createError.set(''); this.showCreateModal.set(true); }

  doCreate(): void {
    if (this.auditForm.invalid) { this.auditForm.markAllAsTouched(); return; }
    this.creating.set(true);
    const userId = this.auth.user()?.userId;
    this.auditSvc.create({ ...this.auditForm.getRawValue(), auditorUserId: userId }).subscribe({
      next: r => {
        this.creating.set(false);
        if (r.success) {
          this.audits.update(a => [r.data, ...a]);
          this.showCreateModal.set(false);
          this.toast.success('Audit initiated!', `"${r.data.title}" has been scheduled.`);
        } else { this.createError.set(r.message ?? 'Failed to create'); }
      },
      error: err => { this.creating.set(false); this.createError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  updateStatus(a: Audit, status: string): void {
    this.auditSvc.updateStatus(a.auditId, status).subscribe({
      next: r => {
        if (r.success) {
          this.audits.update(arr => arr.map(x => x.auditId === a.auditId ? { ...x, status: status as AuditStatus } : x));
          this.toast.success('Status updated', `Audit marked as ${status.replace('_',' ')}.`);
        }
      },
    });
  }

  generateReport(): void {
    this.generating.set(true);
    this.reportSvc.generate('COMPLIANCE').subscribe({
      next: r => {
        this.generating.set(false);
        if (r.success) {
          this.reports.update(arr => [r.data, ...arr]);
          this.toast.success('Report generated!', 'Audit compliance report is ready.');
        }
      },
      error: () => this.generating.set(false),
    });
  }
}
