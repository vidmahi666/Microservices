import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { EnrollmentService, ProgressService, AssessmentService } from '../../../core/services/index';
import { Course, Enrollment, Progress, Submission } from '../../../core/models';

interface CourseDisplay {
  title: string; courseId: number;
  progress: number; color: string; icon: string;
  nextLesson: string;
}
interface DeadlineDisplay {
  title: string; course: string; due: string;
  icon: string; urgent: boolean;
}

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page">

      <!-- WELCOME CARD -->
      <section class="welcome-card">
        <div class="wc-blob"></div>
        <div class="wc-inner">
          <div>
            <span class="wc-chip"><span class="dot"></span> Welcome back</span>
            <h1 class="wc-title">Hello, {{ firstName() }} <span class="wave">👋</span></h1>
            <p class="wc-desc">
              You have <strong>{{ deadlines().length }} upcoming deadlines</strong> this week.
              Keep the streak going — you're <strong>{{ overallPct() }}%</strong> through your courses.
            </p>
            <div class="wc-actions">
              <a routerLink="/student/courses" class="btn-primary">
                Continue learning <i class="bi bi-arrow-right"></i>
              </a>
              <a routerLink="/student/profile" class="btn-ghost">
                <i class="bi bi-person-circle"></i> View profile
              </a>
            </div>
          </div>
          <div class="wc-visual">
            <div class="ring">
              <svg viewBox="0 0 120 120" class="ring-svg">
                <circle cx="60" cy="60" r="52" class="ring-bg"></circle>
                <circle cx="60" cy="60" r="52" class="ring-fg"
                  [style.stroke-dashoffset]="326 * (1 - overallPct()/100)"></circle>
              </svg>
              <div class="ring-text">
                <div class="pct">{{ overallPct() }}%</div>
                <div class="pct-lbl">Progress</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- STATS -->
      <section class="stats-grid">
        @for (s of stats(); track s.label) {
          <div class="stat-card" [attr.data-tone]="s.tone">
            <div class="stat-icon"><i class="bi" [ngClass]="s.icon"></i></div>
            <div class="stat-body">
              <div class="stat-label">{{ s.label }}</div>
              <div class="stat-value">{{ s.value }}</div>
              <div class="stat-change"><i class="bi bi-arrow-up-right"></i> {{ s.change }}</div>
            </div>
          </div>
        }
      </section>

      <!-- GRID: COURSES + DEADLINES -->
      <div class="two-col">
        <!-- Enrolled Courses -->
        <section class="panel">
          <header class="panel-head">
            <div>
              <h2 class="panel-title">Enrolled courses</h2>
              <p class="panel-sub">Pick up where you left off</p>
            </div>
            <a routerLink="/student/courses" class="panel-link">View all <i class="bi bi-arrow-right"></i></a>
          </header>
          @if (loadingCourses()) {
            <div class="loading-row"><span class="spinner"></span> Loading...</div>
          } @else if (courseDisplays().length === 0) {
            <div class="empty"><i class="bi bi-book"></i> No courses enrolled yet. <a routerLink="/student/courses">Browse courses</a></div>
          } @else {
            @for (c of courseDisplays().slice(0,5); track c.courseId) {
              <div class="course-row" [attr.data-color]="c.color">
                <div class="cr-icon"><i class="bi" [ngClass]="c.icon"></i></div>
                <div class="cr-main">
                  <div class="cr-top">
                    <h3 class="cr-title">{{ c.title }}</h3>
                    <span class="cr-pct">{{ c.progress }}%</span>
                  </div>
                  <div class="cr-meta">Next: {{ c.nextLesson }}</div>
                  <div class="progress-track">
                    <div class="progress-bar" [style.width.%]="c.progress"></div>
                  </div>
                  <div class="cr-actions">
                    <a [routerLink]="['/student/course-content', c.courseId]" class="cr-link">
                      <i class="bi bi-collection-play-fill"></i> Content
                    </a>
                    <a routerLink="/student/progress" class="cr-link outline">
                      <i class="bi bi-bar-chart"></i> Progress
                    </a>
                  </div>
                </div>
              </div>
            }
          }
        </section>

        <!-- Upcoming Deadlines -->
        <section class="panel">
          <header class="panel-head">
            <div>
              <h2 class="panel-title">Upcoming deadlines</h2>
              <p class="panel-sub">Don't miss a beat</p>
            </div>
          </header>
          @if (deadlines().length === 0) {
            <div class="empty"><i class="bi bi-calendar-check"></i> No upcoming deadlines!</div>
          } @else {
            @for (d of deadlines(); track d.title) {
              <div class="deadline-row" [class.urgent]="d.urgent">
                <div class="dl-icon"><i class="bi" [ngClass]="d.icon"></i></div>
                <div class="dl-main">
                  <div class="dl-title">{{ d.title }}</div>
                  <div class="dl-meta">{{ d.course }}</div>
                </div>
                <div class="dl-due">
                  <span class="due-badge" [class.urgent]="d.urgent">{{ d.due }}</span>
                </div>
              </div>
            }
          }
        </section>
      </div>

    </div>
  `,
  styles: [`
    :host {
      --navy:         #0D1B3E; --navy-mid: #1A2F5E;
      --accent:       #2E7BF6; --accent-light: #4F95FF;
      --gold:         #F0A500; --mint: #00C9A7;
      --purple:       #A78BFA; --rose: #FB7185;
      --text-muted:   #8898B3; --border: rgba(255,255,255,0.08);
      display: block; font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .page { display:flex; flex-direction:column; gap:1.5rem; }

    /* Welcome */
    .welcome-card { position:relative; background:linear-gradient(135deg,rgba(46,123,246,0.18),rgba(0,201,167,0.08)); border:1px solid rgba(46,123,246,0.25); border-radius:22px; padding:2rem; overflow:hidden; }
    .wc-blob { position:absolute; width:420px; height:420px; background:radial-gradient(circle,rgba(46,123,246,0.35),transparent 70%); filter:blur(60px); top:-140px; right:-120px; pointer-events:none; }
    .wc-inner { position:relative; display:grid; grid-template-columns:1fr auto; gap:2rem; align-items:center; }
    .wc-chip { display:inline-flex; align-items:center; gap:6px; padding:4px 12px; background:rgba(0,201,167,0.15); border:1px solid rgba(0,201,167,0.35); border-radius:100px; font-size:0.72rem; font-weight:700; color:var(--mint); text-transform:uppercase; letter-spacing:0.08em; margin-bottom:0.9rem; .dot{width:6px;height:6px;border-radius:50%;background:var(--mint);animation:pulse 2s infinite;} }
    .wc-title { font-family:'Fraunces',serif; font-size:2.3rem; font-weight:800; color:#fff; margin:0 0 0.5rem; letter-spacing:-0.02em; .wave{display:inline-block;transform-origin:70% 70%;animation:wave 2.5s infinite;} }
    .wc-desc { color:var(--text-muted); font-size:1rem; line-height:1.6; max-width:540px; strong{color:#fff;font-weight:700;} }
    .wc-actions { display:flex; gap:0.75rem; margin-top:1.3rem; flex-wrap:wrap; }
    .btn-primary { display:inline-flex; align-items:center; gap:8px; padding:0.7rem 1.3rem; background:linear-gradient(135deg,var(--accent),#1A5FD4); border:none; border-radius:10px; color:#fff; font-size:0.9rem; font-weight:700; text-decoration:none; transition:all 0.25s; box-shadow:0 8px 22px rgba(46,123,246,0.35); &:hover{transform:translateY(-2px);box-shadow:0 14px 32px rgba(46,123,246,0.5);color:#fff;} }
    .btn-ghost { display:inline-flex; align-items:center; gap:8px; padding:0.7rem 1.2rem; background:rgba(255,255,255,0.05); border:1px solid var(--border); border-radius:10px; color:#fff; font-size:0.9rem; font-weight:600; text-decoration:none; transition:all 0.2s; &:hover{background:rgba(255,255,255,0.1);color:#fff;} }
    .wc-visual { display:flex; justify-content:center; }
    .ring { position:relative; width:160px; height:160px; }
    .ring-svg { width:100%; height:100%; transform:rotate(-90deg); }
    .ring-bg { fill:none; stroke:rgba(255,255,255,0.08); stroke-width:10; }
    .ring-fg { fill:none; stroke:var(--mint); stroke-width:10; stroke-linecap:round; stroke-dasharray:326; filter:drop-shadow(0 0 10px rgba(0,201,167,0.5)); animation:drawRing 1.2s ease; transition:stroke-dashoffset 0.8s ease; }
    .ring-text { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; .pct{font-family:'Fraunces',serif;font-size:2rem;font-weight:800;color:#fff;letter-spacing:-0.02em;} .pct-lbl{font-size:0.72rem;color:var(--text-muted);margin-top:2px;} }

    /* Stats */
    .stats-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; }
    .stat-card { display:flex; align-items:center; gap:1rem; padding:1.25rem; background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:16px; transition:all 0.3s; &:hover{transform:translateY(-3px);border-color:rgba(46,123,246,0.3);} }
    .stat-icon { width:48px; height:48px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.2rem; flex-shrink:0; }
    .stat-label { font-size:0.75rem; color:var(--text-muted); font-weight:600; text-transform:uppercase; letter-spacing:0.05em; }
    .stat-value { font-family:'Fraunces',serif; font-size:1.8rem; font-weight:800; color:#fff; line-height:1.1; margin-top:2px; letter-spacing:-0.02em; }
    .stat-change { font-size:0.72rem; color:var(--mint); margin-top:4px; }
    .stat-card[data-tone="blue"]   .stat-icon { background:rgba(46,123,246,0.15); color:var(--accent-light); }
    .stat-card[data-tone="mint"]   .stat-icon { background:rgba(0,201,167,0.15);  color:var(--mint); }
    .stat-card[data-tone="gold"]   .stat-icon { background:rgba(240,165,0,0.15);  color:var(--gold); }
    .stat-card[data-tone="purple"] .stat-icon { background:rgba(167,139,250,0.15);color:var(--purple); }

    /* Two col */
    .two-col { display:grid; grid-template-columns:1.35fr 1fr; gap:1.25rem; }
    .panel { background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:18px; padding:1.5rem; display:flex; flex-direction:column; gap:0.9rem; }
    .panel-head { display:flex; justify-content:space-between; align-items:flex-end; gap:1rem; padding-bottom:0.5rem; border-bottom:1px solid var(--border); .panel-title{font-family:'Fraunces',serif;font-size:1.2rem;font-weight:700;color:#fff;margin:0;letter-spacing:-0.01em;} .panel-sub{font-size:0.82rem;color:var(--text-muted);margin-top:3px;} .panel-link{color:var(--accent-light);text-decoration:none;font-size:0.85rem;font-weight:600;display:inline-flex;align-items:center;gap:4px;&:hover{text-decoration:underline;}} }

    /* Course row */
    .course-row { display:flex; gap:1rem; align-items:flex-start; padding:0.85rem; border-radius:12px; border:1px solid transparent; transition:all 0.2s; &:hover{background:rgba(255,255,255,0.04);border-color:var(--border);} }
    .cr-icon { width:44px; height:44px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0; margin-top:2px; }
    .cr-main { flex:1; min-width:0; }
    .cr-top { display:flex; justify-content:space-between; align-items:center; gap:1rem; }
    .cr-title { font-size:0.95rem; font-weight:700; color:#fff; margin:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    .cr-pct { font-size:0.85rem; font-weight:700; color:var(--mint); flex-shrink:0; }
    .cr-meta { font-size:0.78rem; color:var(--text-muted); margin-top:3px; }
    .course-row[data-color="blue"]   .cr-icon { background:rgba(46,123,246,0.15); color:var(--accent-light); }
    .course-row[data-color="mint"]   .cr-icon { background:rgba(0,201,167,0.15);  color:var(--mint); }
    .course-row[data-color="gold"]   .cr-icon { background:rgba(240,165,0,0.15);  color:var(--gold); }
    .course-row[data-color="purple"] .cr-icon { background:rgba(167,139,250,0.15);color:var(--purple); }
    .progress-track { margin-top:8px; height:6px; background:rgba(255,255,255,0.06); border-radius:100px; overflow:hidden; }
    .progress-bar   { height:100%; background:linear-gradient(90deg,var(--accent),var(--mint)); border-radius:100px; transition:width 0.6s ease; }
    .cr-actions { display:flex; gap:0.5rem; margin-top:8px; }
    .cr-link { display:inline-flex; align-items:center; gap:5px; padding:4px 10px; font-size:0.72rem; font-weight:700; text-decoration:none; border-radius:7px; background:linear-gradient(135deg,rgba(46,123,246,0.18),rgba(0,201,167,0.1)); border:1px solid rgba(46,123,246,0.25); color:var(--accent-light); transition:all 0.2s; &:hover{border-color:rgba(46,123,246,0.5);color:#fff;} &.outline{background:rgba(255,255,255,0.03);border-color:var(--border);color:var(--text-muted);&:hover{color:#fff;border-color:rgba(255,255,255,0.2);}} }

    /* Deadline row */
    .deadline-row { display:flex; align-items:center; gap:0.9rem; padding:0.85rem; border-radius:12px; background:rgba(255,255,255,0.02); border:1px solid var(--border); transition:all 0.2s; &:hover{background:rgba(255,255,255,0.05);} &.urgent{border-color:rgba(251,113,133,0.3);background:rgba(251,113,133,0.06);} }
    .dl-icon { width:40px; height:40px; border-radius:10px; background:rgba(46,123,246,0.15); color:var(--accent-light); display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0; }
    .deadline-row.urgent .dl-icon { background:rgba(251,113,133,0.15); color:var(--rose); }
    .dl-title { font-size:0.9rem; font-weight:700; color:#fff; }
    .dl-meta  { font-size:0.75rem; color:var(--text-muted); margin-top:2px; }
    .due-badge { font-size:0.72rem; font-weight:700; padding:4px 10px; border-radius:100px; background:rgba(46,123,246,0.15); color:var(--accent-light); white-space:nowrap; &.urgent{background:rgba(251,113,133,0.15);color:var(--rose);} }
    .empty { padding:1.25rem; text-align:center; font-size:0.85rem; color:var(--text-muted); i{margin-right:6px;} a{color:var(--accent-light);} }
    .loading-row { display:flex; align-items:center; gap:8px; padding:1rem; color:var(--text-muted); font-size:0.875rem; }
    .spinner { display:inline-block; width:18px; height:18px; border:2px solid rgba(255,255,255,0.15); border-top-color:#fff; border-radius:50%; animation:spin 0.6s linear infinite; }

    @media(max-width:991px) { .stats-grid{grid-template-columns:repeat(2,1fr);} .two-col{grid-template-columns:1fr;} .wc-inner{grid-template-columns:1fr;} .wc-visual{justify-content:flex-start;} .wc-title{font-size:1.9rem;} }
    @media(max-width:520px) { .stats-grid{grid-template-columns:1fr;} .welcome-card{padding:1.5rem;} }

    @keyframes pulse   { 0%,100%{opacity:1;} 50%{opacity:0.4;} }
    @keyframes wave    { 0%,60%,100%{transform:rotate(0);} 10%{transform:rotate(14deg);} 20%{transform:rotate(-8deg);} 30%{transform:rotate(12deg);} 40%{transform:rotate(-4deg);} 50%{transform:rotate(10deg);} }
    @keyframes drawRing{ from{stroke-dashoffset:326;} }
    @keyframes spin    { to{transform:rotate(360deg);} }
  `],
})
export class StudentDashboardComponent implements OnInit {
  private auth        = inject(AuthService);
  private enrollSvc   = inject(EnrollmentService);
  private progressSvc = inject(ProgressService);
  private assessSvc   = inject(AssessmentService);

  loadingCourses = signal(true);
  enrollments    = signal<Enrollment[]>([]);
  progressList   = signal<Progress[]>([]);
  submissions    = signal<Submission[]>([]);

  firstName = computed(() => (this.auth.user()?.name ?? 'Student').split(' ')[0]);

  overallPct = computed(() => {
    const list = this.progressList();
    if (!list.length) return 0;
    return Math.round(list.reduce((s, p) => s + p.completionPercentage, 0) / list.length);
  });

  stats = computed(() => [
    { label: 'Enrolled',    value: this.enrollments().length, tone: 'blue',   icon: 'bi-book-fill',        change: 'courses' },
    { label: 'Completed',   value: this.progressList().filter(p => p.status === 'COMPLETED').length, tone: 'mint', icon: 'bi-patch-check-fill', change: 'courses' },
    { label: 'Submissions', value: this.submissions().length, tone: 'gold',   icon: 'bi-pencil-fill',      change: 'total' },
    { label: 'Avg Score',   value: this.avgScore() + '%',     tone: 'purple', icon: 'bi-star-fill',        change: 'this term' },
  ]);

  courseDisplays = computed<CourseDisplay[]>(() => {
    const colors = ['blue', 'mint', 'gold', 'purple'];
    const icons  = ['bi-book', 'bi-code-slash', 'bi-bar-chart', 'bi-flask'];
    return this.enrollments().map((e, i) => {
      const p = this.progressList().find(x => x.courseId === e.courseId);
      return {
        title:      e.courseTitle ?? `Course #${e.courseId}`,
        courseId:   e.courseId,
        progress:   p?.completionPercentage ?? 0,
        color:      colors[i % colors.length],
        icon:       icons[i % icons.length],
        nextLesson: p?.status === 'COMPLETED' ? 'Completed!' : 'Continue',
      };
    });
  });

  deadlines = computed<DeadlineDisplay[]>(() =>
    this.submissions().filter(s => s.status === 'SUBMITTED').map(s => ({
      title:  `Assessment #${s.assessmentId}`,
      course: `Submission #${s.submissionId}`,
      due:    s.submittedAt ? new Date(s.submittedAt).toLocaleDateString() : 'TBD',
      icon:   'bi-pencil-square',
      urgent: false,
    }))
  );

  avgScore = computed(() => {
    const graded = this.submissions().filter(s => s.score !== null && s.score !== undefined);
    if (!graded.length) return 0;
    return Math.round(graded.reduce((a, b) => a + (b.score ?? 0), 0) / graded.length);
  });

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => { if (r.success) this.enrollments.set(r.data ?? []); this.loadingCourses.set(false); },
      error: () => this.loadingCourses.set(false),
    });
    this.progressSvc.getByStudent(sId).subscribe({ next: r => { if (r.success) this.progressList.set(r.data ?? []); } });
    this.assessSvc.getSubmissionsByStudent(sId).subscribe({ next: r => { if (r.success) this.submissions.set(r.data ?? []); } });
  }
}
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { EnrollmentService, ProgressService, AssessmentService } from '../../../core/services/index';
import { Course, Enrollment, Progress, Submission } from '../../../core/models';

interface CourseDisplay {
  title: string; courseId: number;
  progress: number; color: string; icon: string;
  nextLesson: string;
}
interface DeadlineDisplay {
  title: string; course: string; due: string;
  icon: string; urgent: boolean;
}

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page">

      <!-- WELCOME CARD (exact theme) -->
      <section class="welcome-card">
        <div class="wc-blob"></div>
        <div class="wc-inner">
          <div>
            <span class="wc-chip"><span class="dot"></span> Welcome back</span>
            <h1 class="wc-title">Hello, {{ firstName() }} <span class="wave">👋</span></h1>
            <p class="wc-desc">
              You have <strong>{{ deadlines().length }} upcoming deadlines</strong> this week.
              Keep the streak going — you're <strong>{{ overallPct() }}%</strong> through your courses.
            </p>
            <div class="wc-actions">
              <a routerLink="/student/courses" class="btn-primary">
                Continue learning <i class="bi bi-arrow-right"></i>
              </a>
              <a routerLink="/student/profile" class="btn-ghost">
                <i class="bi bi-person-circle"></i> View profile
              </a>
            </div>
          </div>
          <div class="wc-visual">
            <div class="ring">
              <svg viewBox="0 0 120 120" class="ring-svg">
                <circle cx="60" cy="60" r="52" class="ring-bg"></circle>
                <circle cx="60" cy="60" r="52" class="ring-fg"
                  [style.stroke-dashoffset]="326 * (1 - overallPct()/100)"></circle>
              </svg>
              <div class="ring-text">
                <div class="pct">{{ overallPct() }}%</div>
                <div class="pct-lbl">Progress</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- STATS -->
      <section class="stats-grid">
        @for (s of stats(); track s.label) {
          <div class="stat-card" [attr.data-tone]="s.tone">
            <div class="stat-icon"><i class="bi" [ngClass]="s.icon"></i></div>
            <div class="stat-body">
              <div class="stat-label">{{ s.label }}</div>
              <div class="stat-value">{{ s.value }}</div>
              <div class="stat-change"><i class="bi bi-arrow-up-right"></i> {{ s.change }}</div>
            </div>
          </div>
        }
      </section>

      <!-- GRID: COURSES + DEADLINES -->
      <div class="two-col">
        <!-- Enrolled Courses -->
        <section class="panel">
          <header class="panel-head">
            <div>
              <h2 class="panel-title">Enrolled courses</h2>
              <p class="panel-sub">Pick up where you left off</p>
            </div>
            <a routerLink="/student/courses" class="panel-link">View all <i class="bi bi-arrow-right"></i></a>
          </header>
          @if (loadingCourses()) {
            <div class="loading-row"><span class="spinner"></span> Loading...</div>
          } @else if (courseDisplays().length === 0) {
            <div class="empty"><i class="bi bi-book"></i> No courses enrolled yet. <a routerLink="/student/courses">Browse courses</a></div>
          } @else {
            @for (c of courseDisplays().slice(0,5); track c.courseId) {
              <div class="course-row" [attr.data-color]="c.color">
                <div class="cr-icon"><i class="bi" [ngClass]="c.icon"></i></div>
                <div class="cr-main">
                  <div class="cr-top">
                    <h3 class="cr-title">{{ c.title }}</h3>
                    <span class="cr-pct">{{ c.progress }}%</span>
                  </div>
                  <div class="cr-meta">Next: {{ c.nextLesson }}</div>
                  <div class="progress-track">
                    <div class="progress-bar" [style.width.%]="c.progress"></div>
                  </div>
                </div>
              </div>
            }
          }
        </section>

        <!-- Upcoming Deadlines -->
        <section class="panel">
          <header class="panel-head">
            <div>
              <h2 class="panel-title">Upcoming deadlines</h2>
              <p class="panel-sub">Don't miss a beat</p>
            </div>
          </header>
          @if (deadlines().length === 0) {
            <div class="empty"><i class="bi bi-calendar-check"></i> No upcoming deadlines!</div>
          } @else {
            @for (d of deadlines(); track d.title) {
              <div class="deadline-row" [class.urgent]="d.urgent">
                <div class="dl-icon"><i class="bi" [ngClass]="d.icon"></i></div>
                <div class="dl-main">
                  <div class="dl-title">{{ d.title }}</div>
                  <div class="dl-meta">{{ d.course }}</div>
                </div>
                <div class="dl-due">
                  <span class="due-badge" [class.urgent]="d.urgent">{{ d.due }}</span>
                </div>
              </div>
            }
          }
        </section>
      </div>

    </div>
  `,
  styles: [`
    :host {
      --navy:         #0D1B3E; --navy-mid: #1A2F5E;
      --accent:       #2E7BF6; --accent-light: #4F95FF;
      --gold:         #F0A500; --mint: #00C9A7;
      --purple:       #A78BFA; --rose: #FB7185;
      --text-muted:   #8898B3; --border: rgba(255,255,255,0.08);
      display: block; font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .page { display:flex; flex-direction:column; gap:1.5rem; }

    /* Welcome */
    .welcome-card { position:relative; background:linear-gradient(135deg,rgba(46,123,246,0.18),rgba(0,201,167,0.08)); border:1px solid rgba(46,123,246,0.25); border-radius:22px; padding:2rem; overflow:hidden; }
    .wc-blob { position:absolute; width:420px; height:420px; background:radial-gradient(circle,rgba(46,123,246,0.35),transparent 70%); filter:blur(60px); top:-140px; right:-120px; pointer-events:none; }
    .wc-inner { position:relative; display:grid; grid-template-columns:1fr auto; gap:2rem; align-items:center; }
    .wc-chip { display:inline-flex; align-items:center; gap:6px; padding:4px 12px; background:rgba(0,201,167,0.15); border:1px solid rgba(0,201,167,0.35); border-radius:100px; font-size:0.72rem; font-weight:700; color:var(--mint); text-transform:uppercase; letter-spacing:0.08em; margin-bottom:0.9rem; .dot{width:6px;height:6px;border-radius:50%;background:var(--mint);animation:pulse 2s infinite;} }
    .wc-title { font-family:'Fraunces',serif; font-size:2.3rem; font-weight:800; color:#fff; margin:0 0 0.5rem; letter-spacing:-0.02em; .wave{display:inline-block;transform-origin:70% 70%;animation:wave 2.5s infinite;} }
    .wc-desc { color:var(--text-muted); font-size:1rem; line-height:1.6; max-width:540px; strong{color:#fff;font-weight:700;} }
    .wc-actions { display:flex; gap:0.75rem; margin-top:1.3rem; flex-wrap:wrap; }
    .btn-primary { display:inline-flex; align-items:center; gap:8px; padding:0.7rem 1.3rem; background:linear-gradient(135deg,var(--accent),#1A5FD4); border:none; border-radius:10px; color:#fff; font-size:0.9rem; font-weight:700; text-decoration:none; transition:all 0.25s; box-shadow:0 8px 22px rgba(46,123,246,0.35); &:hover{transform:translateY(-2px);box-shadow:0 14px 32px rgba(46,123,246,0.5);color:#fff;} }
    .btn-ghost { display:inline-flex; align-items:center; gap:8px; padding:0.7rem 1.2rem; background:rgba(255,255,255,0.05); border:1px solid var(--border); border-radius:10px; color:#fff; font-size:0.9rem; font-weight:600; text-decoration:none; transition:all 0.2s; &:hover{background:rgba(255,255,255,0.1);color:#fff;} }
    .wc-visual { display:flex; justify-content:center; }
    .ring { position:relative; width:160px; height:160px; }
    .ring-svg { width:100%; height:100%; transform:rotate(-90deg); }
    .ring-bg { fill:none; stroke:rgba(255,255,255,0.08); stroke-width:10; }
    .ring-fg { fill:none; stroke:var(--mint); stroke-width:10; stroke-linecap:round; stroke-dasharray:326; filter:drop-shadow(0 0 10px rgba(0,201,167,0.5)); animation:drawRing 1.2s ease; transition:stroke-dashoffset 0.8s ease; }
    .ring-text { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; .pct{font-family:'Fraunces',serif;font-size:2rem;font-weight:800;color:#fff;letter-spacing:-0.02em;} .pct-lbl{font-size:0.72rem;color:var(--text-muted);margin-top:2px;} }

    /* Stats */
    .stats-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; }
    .stat-card { display:flex; align-items:center; gap:1rem; padding:1.25rem; background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:16px; transition:all 0.3s; &:hover{transform:translateY(-3px);border-color:rgba(46,123,246,0.3);} }
    .stat-icon { width:48px; height:48px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.2rem; flex-shrink:0; }
    .stat-label { font-size:0.75rem; color:var(--text-muted); font-weight:600; text-transform:uppercase; letter-spacing:0.05em; }
    .stat-value { font-family:'Fraunces',serif; font-size:1.8rem; font-weight:800; color:#fff; line-height:1.1; margin-top:2px; letter-spacing:-0.02em; }
    .stat-change { font-size:0.72rem; color:var(--mint); margin-top:4px; }
    .stat-card[data-tone="blue"]   .stat-icon { background:rgba(46,123,246,0.15); color:var(--accent-light); }
    .stat-card[data-tone="mint"]   .stat-icon { background:rgba(0,201,167,0.15);  color:var(--mint); }
    .stat-card[data-tone="gold"]   .stat-icon { background:rgba(240,165,0,0.15);  color:var(--gold); }
    .stat-card[data-tone="purple"] .stat-icon { background:rgba(167,139,250,0.15);color:var(--purple); }

    /* Two col */
    .two-col { display:grid; grid-template-columns:1.35fr 1fr; gap:1.25rem; }
    .panel { background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:18px; padding:1.5rem; display:flex; flex-direction:column; gap:0.9rem; }
    .panel-head { display:flex; justify-content:space-between; align-items:flex-end; gap:1rem; padding-bottom:0.5rem; border-bottom:1px solid var(--border); .panel-title{font-family:'Fraunces',serif;font-size:1.2rem;font-weight:700;color:#fff;margin:0;letter-spacing:-0.01em;} .panel-sub{font-size:0.82rem;color:var(--text-muted);margin-top:3px;} .panel-link{color:var(--accent-light);text-decoration:none;font-size:0.85rem;font-weight:600;display:inline-flex;align-items:center;gap:4px;&:hover{text-decoration:underline;}} }

    /* Course row */
    .course-row { display:flex; gap:1rem; align-items:center; padding:0.85rem; border-radius:12px; border:1px solid transparent; transition:all 0.2s; &:hover{background:rgba(255,255,255,0.04);border-color:var(--border);} }
    .cr-icon { width:44px; height:44px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0; }
    .cr-main { flex:1; min-width:0; }
    .cr-top { display:flex; justify-content:space-between; align-items:center; gap:1rem; }
    .cr-title { font-size:0.95rem; font-weight:700; color:#fff; margin:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    .cr-pct { font-size:0.85rem; font-weight:700; color:var(--mint); flex-shrink:0; }
    .cr-meta { font-size:0.78rem; color:var(--text-muted); margin-top:3px; }
    .course-row[data-color="blue"]   .cr-icon { background:rgba(46,123,246,0.15); color:var(--accent-light); }
    .course-row[data-color="mint"]   .cr-icon { background:rgba(0,201,167,0.15);  color:var(--mint); }
    .course-row[data-color="gold"]   .cr-icon { background:rgba(240,165,0,0.15);  color:var(--gold); }
    .course-row[data-color="purple"] .cr-icon { background:rgba(167,139,250,0.15);color:var(--purple); }
    .progress-track { margin-top:8px; height:6px; background:rgba(255,255,255,0.06); border-radius:100px; overflow:hidden; }
    .progress-bar   { height:100%; background:linear-gradient(90deg,var(--accent),var(--mint)); border-radius:100px; transition:width 0.6s ease; }

    /* Deadline row */
    .deadline-row { display:flex; align-items:center; gap:0.9rem; padding:0.85rem; border-radius:12px; background:rgba(255,255,255,0.02); border:1px solid var(--border); transition:all 0.2s; &:hover{background:rgba(255,255,255,0.05);} &.urgent{border-color:rgba(251,113,133,0.3);background:rgba(251,113,133,0.06);} }
    .dl-icon { width:40px; height:40px; border-radius:10px; background:rgba(46,123,246,0.15); color:var(--accent-light); display:flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0; }
    .deadline-row.urgent .dl-icon { background:rgba(251,113,133,0.15); color:var(--rose); }
    .dl-title { font-size:0.9rem; font-weight:700; color:#fff; }
    .dl-meta  { font-size:0.75rem; color:var(--text-muted); margin-top:2px; }
    .due-badge { font-size:0.72rem; font-weight:700; padding:4px 10px; border-radius:100px; background:rgba(46,123,246,0.15); color:var(--accent-light); white-space:nowrap; &.urgent{background:rgba(251,113,133,0.15);color:var(--rose);} }
    .empty { padding:1.25rem; text-align:center; font-size:0.85rem; color:var(--text-muted); i{margin-right:6px;} a{color:var(--accent-light);} }
    .loading-row { display:flex; align-items:center; gap:8px; padding:1rem; color:var(--text-muted); font-size:0.875rem; }
    .spinner { display:inline-block; width:18px; height:18px; border:2px solid rgba(255,255,255,0.15); border-top-color:#fff; border-radius:50%; animation:spin 0.6s linear infinite; }

    /* Responsive */
    @media(max-width:991px) { .stats-grid{grid-template-columns:repeat(2,1fr);} .two-col{grid-template-columns:1fr;} .wc-inner{grid-template-columns:1fr;} .wc-visual{justify-content:flex-start;} .wc-title{font-size:1.9rem;} }
    @media(max-width:520px) { .stats-grid{grid-template-columns:1fr;} .welcome-card{padding:1.5rem;} }

    @keyframes pulse   { 0%,100%{opacity:1;} 50%{opacity:0.4;} }
    @keyframes wave    { 0%,60%,100%{transform:rotate(0);} 10%{transform:rotate(14deg);} 20%{transform:rotate(-8deg);} 30%{transform:rotate(12deg);} 40%{transform:rotate(-4deg);} 50%{transform:rotate(10deg);} }
    @keyframes drawRing{ from{stroke-dashoffset:326;} }
    @keyframes spin    { to{transform:rotate(360deg);} }
  `],
})
export class StudentDashboardComponent implements OnInit {
  private auth        = inject(AuthService);
  private enrollSvc   = inject(EnrollmentService);
  private progressSvc = inject(ProgressService);
  private assessSvc   = inject(AssessmentService);

  loadingCourses = signal(true);
  enrollments    = signal<Enrollment[]>([]);
  progressList   = signal<Progress[]>([]);
  submissions    = signal<Submission[]>([]);

  firstName = computed(() => (this.auth.user()?.name ?? 'Student').split(' ')[0]);

  overallPct = computed(() => {
    const list = this.progressList();
    if (!list.length) return 0;
    return Math.round(list.reduce((s, p) => s + p.completionPercentage, 0) / list.length);
  });

  stats = computed(() => [
    { label: 'Enrolled', value: this.enrollments().length, tone: 'blue',   icon: 'bi-book-fill',        change: 'courses' },
    { label: 'Completed', value: this.progressList().filter(p => p.status === 'COMPLETED').length, tone: 'mint', icon: 'bi-patch-check-fill', change: 'courses' },
    { label: 'Submissions', value: this.submissions().length, tone: 'gold',   icon: 'bi-pencil-fill',      change: 'total' },
    { label: 'Avg Score', value: this.avgScore() + '%', tone: 'purple', icon: 'bi-star-fill',        change: 'this term' },
  ]);

  courseDisplays = computed<CourseDisplay[]>(() => {
    const colors = ['blue', 'mint', 'gold', 'purple'];
    const icons  = ['bi-book', 'bi-code-slash', 'bi-bar-chart', 'bi-flask'];
    return this.enrollments().map((e, i) => {
      const p = this.progressList().find(x => x.courseId === e.courseId);
      return {
        title:      e.courseTitle ?? `Course #${e.courseId}`,
        courseId:   e.courseId,
        progress:   p?.completionPercentage ?? 0,
        color:      colors[i % colors.length],
        icon:       icons[i % icons.length],
        nextLesson: p?.status === 'COMPLETED' ? 'Completed!' : 'Continue',
      };
    });
  });

  deadlines = computed<DeadlineDisplay[]>(() =>
    this.submissions().filter(s => s.status === 'SUBMITTED').map(s => ({
      title:  `Assessment #${s.assessmentId}`,
      course: `Submission #${s.submissionId}`,
      due:    s.submittedAt ? new Date(s.submittedAt).toLocaleDateString() : 'TBD',
      icon:   'bi-pencil-square',
      urgent: false,
    }))
  );

  avgScore = computed(() => {
    const graded = this.submissions().filter(s => s.score !== null && s.score !== undefined);
    if (!graded.length) return 0;
    return Math.round(graded.reduce((a, b) => a + (b.score ?? 0), 0) / graded.length);
  });

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => { if (r.success) this.enrollments.set(r.data ?? []); this.loadingCourses.set(false); },
      error: () => this.loadingCourses.set(false),
    });
    this.progressSvc.getByStudent(sId).subscribe({ next: r => { if (r.success) this.progressList.set(r.data ?? []); } });
    this.assessSvc.getSubmissionsByStudent(sId).subscribe({ next: r => { if (r.success) this.submissions.set(r.data ?? []); } });
  }
}
