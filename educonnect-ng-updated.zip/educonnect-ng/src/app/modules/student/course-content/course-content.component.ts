import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ContentService, EnrollmentService, CourseService, ToastService } from '../../../core/services/index';
import { Content, Course, Enrollment } from '../../../core/models';

@Component({
  selector: 'app-course-content',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page">
      <!-- Back nav -->
      <a routerLink="/student/courses" class="back-link">
        <i class="bi bi-arrow-left"></i> Back to My Courses
      </a>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      } @else if (!isEnrolled()) {
        <!-- Not enrolled gate -->
        <div class="gate-card">
          <div class="gate-icon"><i class="bi bi-lock-fill"></i></div>
          <h2 class="gate-title">Content Locked</h2>
          <p class="gate-desc">
            You need a valid enrollment to access content for
            <strong>{{ course()?.title ?? 'this course' }}</strong>.
          </p>
          <a routerLink="/student/courses" class="btn-primary">
            <i class="bi bi-book-fill"></i> Browse & Enroll
          </a>
        </div>
      } @else {
        <!-- Course header -->
        <header class="course-header">
          <div class="ch-left">
            <span class="eyebrow">Course Content</span>
            <h1 class="page-title">{{ course()?.title ?? 'Course #' + courseId() }}</h1>
            <p class="page-desc">{{ course()?.description }}</p>
          </div>
          <div class="ch-stats">
            <div class="cs-item">
              <span class="cs-val">{{ contentList().length }}</span>
              <span class="cs-lbl">Materials</span>
            </div>
            <div class="cs-item">
              <span class="cs-val">{{ accessedCount() }}</span>
              <span class="cs-lbl">Accessed</span>
            </div>
            <div class="cs-item">
              <span class="cs-val">{{ accessPct() }}%</span>
              <span class="cs-lbl">Viewed</span>
            </div>
          </div>
        </header>

        <!-- Progress bar -->
        <div class="content-prog">
          <div class="cp-label">
            <span>Content progress</span>
            <span class="cp-pct">{{ accessPct() }}%</span>
          </div>
          <div class="cp-track">
            <div class="cp-fill" [style.width.%]="accessPct()"></div>
          </div>
        </div>

        <!-- Type filter -->
        <div class="type-filter">
          @for (t of typeFilters; track t.key) {
            <button class="tf-btn" [class.active]="typeFilter() === t.key" (click)="typeFilter.set(t.key)">
              <i class="bi" [ngClass]="t.icon"></i> {{ t.label }}
              <span class="tf-count">{{ countByType(t.key) }}</span>
            </button>
          }
        </div>

        @if (filtered().length === 0) {
          <div class="empty-state">
            <i class="bi bi-collection-play"></i>
            <h3>No content available</h3>
            <p>Your teacher hasn't uploaded content for this type yet.</p>
          </div>
        } @else {
          <div class="content-grid">
            @for (c of filtered(); track c.contentId) {
              <div class="content-card" [class.accessed]="accessedIds().has(c.contentId)">
                <div class="cc-thumb" [attr.data-type]="c.type.toLowerCase()">
                  <i class="bi" [ngClass]="typeIcon(c.type)"></i>
                  @if (accessedIds().has(c.contentId)) {
                    <div class="cc-viewed"><i class="bi bi-check-circle-fill"></i></div>
                  }
                </div>
                <div class="cc-body">
                  <div class="cc-meta">
                    <span class="cc-type-pill" [attr.data-type]="c.type.toLowerCase()">{{ c.type }}</span>
                    @if (c.sortOrder) {
                      <span class="cc-order">#{{ c.sortOrder }}</span>
                    }
                  </div>
                  <h3 class="cc-title">{{ c.title }}</h3>
                  @if (c.description) {
                    <p class="cc-desc">{{ c.description | slice:0:90 }}{{ c.description.length > 90 ? '...' : '' }}</p>
                  }
                  <div class="cc-date"><i class="bi bi-calendar3"></i> {{ c.uploadedDate | date:'mediumDate' }}</div>
                  <div class="cc-actions">
                    <a [href]="c.fileUri" target="_blank" class="btn-view"
                       (click)="recordAccess(c)">
                      <i class="bi bi-eye-fill"></i>
                      {{ accessedIds().has(c.contentId) ? 'View Again' : 'View Content' }}
                    </a>
                    @if (accessedIds().has(c.contentId)) {
                      <span class="viewed-tag"><i class="bi bi-check2-circle"></i> Viewed</span>
                    }
                  </div>
                </div>
              </div>
            }
          </div>
        }
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page{display:flex;flex-direction:column;gap:1.5rem;}
    .back-link{display:inline-flex;align-items:center;gap:7px;color:var(--text-muted);text-decoration:none;font-size:0.875rem;font-weight:600;transition:color 0.2s;&:hover{color:#fff;}}
    .eyebrow{display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;}
    .page-title{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0;}
    .page-desc{font-size:0.92rem;color:var(--text-muted);margin-top:6px;max-width:600px;}

    /* Gate */
    .gate-card{padding:4rem 2rem;text-align:center;background:rgba(46,123,246,0.06);border:1px solid rgba(46,123,246,0.2);border-radius:24px;}
    .gate-icon{width:72px;height:72px;border-radius:50%;background:rgba(251,113,133,0.15);display:flex;align-items:center;justify-content:center;font-size:2rem;color:var(--rose);margin:0 auto 1.25rem;}
    .gate-title{font-family:'Fraunces',serif;font-size:1.5rem;font-weight:800;color:#fff;margin-bottom:0.5rem;}
    .gate-desc{font-size:0.95rem;color:var(--text-muted);max-width:440px;margin:0 auto 1.5rem;line-height:1.6;strong{color:#fff;}}
    .btn-primary{display:inline-flex;align-items:center;gap:8px;padding:0.75rem 1.5rem;background:linear-gradient(135deg,var(--accent),#1A5FD4);border:none;border-radius:12px;color:#fff;font-size:0.925rem;font-weight:700;text-decoration:none;transition:all 0.25s;box-shadow:0 8px 20px rgba(46,123,246,0.35);&:hover{transform:translateY(-2px);box-shadow:0 14px 28px rgba(46,123,246,0.5);}}

    /* Course header */
    .course-header{display:flex;justify-content:space-between;align-items:flex-start;gap:2rem;flex-wrap:wrap;}
    .ch-left{flex:1;}
    .ch-stats{display:flex;gap:1rem;flex-shrink:0;}
    .cs-item{text-align:center;padding:0.875rem 1.25rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:14px;}
    .cs-val{display:block;font-family:'Fraunces',serif;font-size:1.6rem;font-weight:800;color:#fff;letter-spacing:-0.02em;}
    .cs-lbl{font-size:0.7rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.06em;font-weight:600;margin-top:2px;}

    /* Progress */
    .content-prog{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:14px;padding:1.25rem;}
    .cp-label{display:flex;justify-content:space-between;font-size:0.82rem;color:var(--text-muted);font-weight:600;margin-bottom:0.75rem;}
    .cp-pct{color:var(--mint);font-weight:700;}
    .cp-track{height:8px;background:rgba(255,255,255,0.06);border-radius:100px;overflow:hidden;}
    .cp-fill{height:100%;background:linear-gradient(90deg,var(--accent),var(--mint));border-radius:100px;transition:width 0.8s ease;}

    /* Type filter */
    .type-filter{display:flex;gap:6px;flex-wrap:wrap;}
    .tf-btn{display:inline-flex;align-items:center;gap:7px;padding:0.5rem 1rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:10px;color:var(--text-muted);font-size:0.82rem;font-weight:600;font-family:inherit;cursor:pointer;transition:all 0.2s;
      .tf-count{font-size:0.7rem;padding:2px 7px;border-radius:100px;background:rgba(255,255,255,0.06);color:var(--text-muted);}
      &:hover{color:#fff;border-color:rgba(46,123,246,0.3);}
      &.active{background:linear-gradient(135deg,rgba(46,123,246,0.2),rgba(0,201,167,0.12));border-color:rgba(46,123,246,0.4);color:#fff;.tf-count{background:rgba(255,255,255,0.12);color:#fff;}}
    }

    /* Content grid */
    .content-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.25rem;}
    .content-card{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;overflow:hidden;transition:all 0.3s;
      &:hover{transform:translateY(-4px);border-color:rgba(46,123,246,0.3);box-shadow:0 18px 40px rgba(0,0,0,0.3);}
      &.accessed{border-color:rgba(0,201,167,0.25);background:rgba(0,201,167,0.04);}
    }
    .cc-thumb{height:100px;display:flex;align-items:center;justify-content:center;position:relative;font-size:2.2rem;
      &[data-type="video"]       {background:linear-gradient(135deg,rgba(251,113,133,0.25),rgba(46,123,246,0.15));color:var(--rose);}
      &[data-type="pdf"]         {background:linear-gradient(135deg,rgba(251,113,133,0.2),transparent);color:var(--rose);}
      &[data-type="document"]    {background:linear-gradient(135deg,rgba(46,123,246,0.2),transparent);color:var(--accent-light);}
      &[data-type="presentation"]{background:linear-gradient(135deg,rgba(240,165,0,0.2),transparent);color:var(--gold);}
      &[data-type="quiz"]        {background:linear-gradient(135deg,rgba(0,201,167,0.2),transparent);color:var(--mint);}
    }
    .cc-viewed{position:absolute;top:10px;right:10px;width:26px;height:26px;background:var(--mint);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.8rem;color:#fff;}
    .cc-body{padding:1.25rem;display:flex;flex-direction:column;gap:0.5rem;}
    .cc-meta{display:flex;align-items:center;gap:8px;}
    .cc-type-pill{display:inline-flex;padding:2px 8px;border-radius:100px;font-size:0.65rem;font-weight:700;text-transform:uppercase;
      &[data-type="video"]{background:rgba(251,113,133,0.15);color:var(--rose);}
      &[data-type="pdf"]{background:rgba(251,113,133,0.15);color:var(--rose);}
      &[data-type="document"]{background:rgba(46,123,246,0.15);color:var(--accent-light);}
      &[data-type="presentation"]{background:rgba(240,165,0,0.15);color:var(--gold);}
      &[data-type="quiz"]{background:rgba(0,201,167,0.15);color:var(--mint);}
    }
    .cc-order{font-size:0.7rem;color:var(--text-muted);font-weight:600;}
    .cc-title{font-size:0.97rem;font-weight:700;color:#fff;margin:0;line-height:1.3;}
    .cc-desc{font-size:0.82rem;color:var(--text-muted);line-height:1.5;margin:0;}
    .cc-date{font-size:0.75rem;color:var(--text-muted);display:flex;align-items:center;gap:5px;}
    .cc-actions{display:flex;align-items:center;gap:0.75rem;margin-top:0.25rem;}
    .btn-view{display:inline-flex;align-items:center;gap:7px;padding:0.6rem 1rem;background:linear-gradient(135deg,var(--accent),#1A5FD4);border:none;border-radius:10px;color:#fff;font-size:0.82rem;font-weight:700;text-decoration:none;transition:all 0.2s;cursor:pointer;font-family:inherit;&:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(46,123,246,0.4);}}
    .viewed-tag{display:inline-flex;align-items:center;gap:5px;font-size:0.78rem;color:var(--mint);font-weight:600;}

    .empty-state{padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;
      i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;}
      h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;}
      p{font-size:0.875rem;color:var(--text-muted);}
    }
    .load-center{display:flex;justify-content:center;padding:3rem;}
    .ec-spin{display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite;}
    @media(max-width:640px){.ch-stats{width:100%;}.content-grid{grid-template-columns:1fr;}}
    @keyframes spin{to{transform:rotate(360deg);}}
  `],
})
export class CourseContentComponent implements OnInit {
  private route       = inject(ActivatedRoute);
  private auth        = inject(AuthService);
  private contentSvc  = inject(ContentService);
  private enrollSvc   = inject(EnrollmentService);
  private courseSvc   = inject(CourseService);
  private toast       = inject(ToastService);

  loading     = signal(true);
  isEnrolled  = signal(false);
  course      = signal<Course | null>(null);
  contentList = signal<Content[]>([]);
  accessedIds = signal<Set<number>>(new Set());
  typeFilter  = signal<string>('all');

  courseId = computed(() => Number(this.route.snapshot.paramMap.get('courseId') ?? 0));

  accessedCount = computed(() => this.accessedIds().size);
  accessPct     = computed(() => {
    const total = this.contentList().length;
    return total ? Math.round((this.accessedIds().size / total) * 100) : 0;
  });

  typeFilters = [
    { key: 'all',          label: 'All',          icon: 'bi-collection' },
    { key: 'VIDEO',        label: 'Videos',       icon: 'bi-play-circle-fill' },
    { key: 'PDF',          label: 'PDFs',         icon: 'bi-file-earmark-pdf-fill' },
    { key: 'DOCUMENT',     label: 'Documents',    icon: 'bi-file-earmark-text-fill' },
    { key: 'PRESENTATION', label: 'Slides',       icon: 'bi-file-earmark-slides-fill' },
    { key: 'QUIZ',         label: 'Quizzes',      icon: 'bi-patch-question-fill' },
  ];

  filtered = computed(() => {
    const list = this.contentList().filter(c => c.status === 'ACTIVE');
    if (this.typeFilter() === 'all') return list;
    return list.filter(c => c.type === this.typeFilter());
  });

  countByType(key: string): number {
    if (key === 'all') return this.contentList().filter(c => c.status === 'ACTIVE').length;
    return this.contentList().filter(c => c.type === key && c.status === 'ACTIVE').length;
  }

  typeIcon(type: string): string {
    const map: Record<string, string> = {
      VIDEO: 'bi-play-circle-fill', PDF: 'bi-file-earmark-pdf-fill',
      DOCUMENT: 'bi-file-earmark-text-fill', PRESENTATION: 'bi-file-earmark-slides-fill',
      QUIZ: 'bi-patch-question-fill',
    };
    return map[type] ?? 'bi-file-earmark';
  }

  ngOnInit(): void {
    const studentId = this.auth.userId() ?? 1;
    const cId       = this.courseId();

    // Load course info
    this.courseSvc.getById(cId).subscribe({
      next: r => { if (r.success) this.course.set(r.data); },
    });

    // Check enrollment, then load content if enrolled
    this.enrollSvc.getByStudent(studentId).subscribe({
      next: r => {
        if (r.success) {
          const enrolled = (r.data ?? []).some(e =>
            e.courseId === cId && (e.status === 'ACTIVE' || e.status === 'COMPLETED')
          );
          this.isEnrolled.set(enrolled);

          if (enrolled) {
            this.loadContent(cId, studentId);
          } else {
            this.loading.set(false);
          }
        } else {
          this.loading.set(false);
        }
      },
      error: () => this.loading.set(false),
    });
  }

  loadContent(courseId: number, studentId: number): void {
    this.contentSvc.getByCourse(courseId).subscribe({
      next: r => {
        if (r.success) this.contentList.set(r.data ?? []);
        // Load access records
        this.contentSvc.getAccessByStudent(studentId).subscribe({
          next: ar => {
            if (ar.success) {
              const ids = new Set((ar.data ?? []).map(a => a.contentId));
              this.accessedIds.set(ids);
            }
            this.loading.set(false);
          },
          error: () => this.loading.set(false),
        });
      },
      error: () => this.loading.set(false),
    });
  }

  recordAccess(c: Content): void {
    if (this.accessedIds().has(c.contentId)) return;
    const studentId = this.auth.userId() ?? 1;
    this.contentSvc.recordAccess(c.contentId, studentId).subscribe({
      next: r => {
        if (r.success) {
          this.accessedIds.update(s => { s.add(c.contentId); return new Set(s); });
          this.toast.info('Progress updated', `"${c.title}" marked as viewed.`);
        }
      },
    });
  }
}
