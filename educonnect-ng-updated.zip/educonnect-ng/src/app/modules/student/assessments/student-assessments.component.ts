import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AssessmentService, EnrollmentService, ToastService } from '../../../core/services/index';
import { Assessment, AssessmentType, Submission } from '../../../core/models';

@Component({
  selector: 'app-student-assessments',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Academics</span>
          <h1 class="page-title">Assessments</h1>
          <p class="page-desc">Quizzes, exams, assignments &amp; projects</p>
        </div>
      </header>

      <!-- Tabs -->
      <div class="tabs">
        @for (t of tabs; track t.key) {
          <button class="tab" [class.active]="activeTab() === t.key" (click)="activeTab.set(t.key)">
            {{ t.label }}
            <span class="tab-count">{{ tabCount(t.key) }}</span>
          </button>
        }
      </div>

      @if (loading()) {
        <div class="loading-overlay"><span class="spinner spinner-lg"></span></div>
      }

      <!-- Available assessments -->
      @if (!loading() && activeTab() === 'available') {
        @if (assessments().length === 0) {
          <div class="empty-box">
            <i class="bi bi-journal-x"></i>
            <h3>No assessments yet</h3>
            <p>Enroll in courses to see assessments.</p>
          </div>
        } @else {
          <div class="assess-grid">
            @for (a of assessments(); track a.assessmentId) {
              <div class="assess-card" [attr.data-type]="a.type">
                <div class="ac-head">
                  <span class="type-badge type-{{ a.type.toLowerCase() }}">
                    <i class="bi" [ngClass]="typeIcon(a.type)"></i>
                    {{ a.type }}
                  </span>
                  <span class="status-badge" [class]="'sb-' + a.status.toLowerCase()">{{ a.status }}</span>
                </div>
                <h3 class="ac-title">{{ a.title }}</h3>
                @if (a.instructions) {
                  <p class="ac-instructions">{{ a.instructions | slice:0:80 }}...</p>
                }
                <div class="ac-meta">
                  @if (a.dueDate) { <span><i class="bi bi-clock"></i> Due {{ a.dueDate | date:'mediumDate' }}</span> }
                  @if (a.maxScore) { <span><i class="bi bi-trophy"></i> Max: {{ a.maxScore }} pts</span> }
                  @if (a.passingScore) { <span><i class="bi bi-check2-circle"></i> Pass: {{ a.passingScore }} pts</span> }
                </div>
                <div class="ac-footer">
                  @if (a.fileUri) {
                    <a [href]="a.fileUri" target="_blank" class="file-link">
                      <i class="bi bi-file-earmark-arrow-down-fill"></i> Assignment Material
                    </a>
                  }
                  @if (submittedIds().has(a.assessmentId)) {
                    <div class="submitted-chip">
                      <i class="bi bi-check-circle-fill"></i> Submitted
                    </div>
                    @if (getSubmission(a.assessmentId); as sub) {
                      @if (sub.score !== null && sub.score !== undefined) {
                        <div class="score-chip">{{ sub.score }}/{{ a.maxScore ?? '?' }} pts</div>
                      }
                    }
                  } @else if (a.status === 'ACTIVE') {
                    <button class="submit-btn" (click)="openSubmit(a)">
                      Submit <i class="bi bi-upload"></i>
                    </button>
                  } @else {
                    <span class="inactive-label">Not open</span>
                  }
                </div>
              </div>
            }
          </div>
        }
      }

      <!-- My submissions tab -->
      @if (!loading() && activeTab() === 'submissions') {
        @if (submissions().length === 0) {
          <div class="empty-box">
            <i class="bi bi-inbox"></i>
            <h3>No submissions yet</h3>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr>
                  <th>Assessment</th>
                  <th>Submitted</th>
                  <th>Score</th>
                  <th>Feedback</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                @for (s of submissions(); track s.submissionId) {
                  <tr>
                    <td><strong>Assessment #{{ s.assessmentId }}</strong></td>
                    <td>{{ s.submittedAt | date:'mediumDate' }}</td>
                    <td>
                      @if (s.score !== null && s.score !== undefined) {
                        <span class="score-pill">{{ s.score }} pts</span>
                      } @else { <span class="muted">—</span> }
                    </td>
                    <td style="max-width:200px;font-size:0.82rem;color:#8898B3">{{ s.comments ?? '—' }}</td>
                    <td><span class="status-badge sb-{{ s.status.toLowerCase() }}">{{ s.status }}</span></td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Submit Modal -->
      @if (showModal()) {
        <div class="modal-backdrop" (click)="closeModal()">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <div>
                <h3>Submit Assessment</h3>
                @if (selectedAssessment()) {
                  <p style="color:#8898B3;font-size:0.875rem;margin-top:4px">{{ selectedAssessment()!.title }}</p>
                }
              </div>
              <button class="modal-close" (click)="closeModal()"><i class="bi bi-x"></i></button>
            </div>

            <form [formGroup]="submitForm" (ngSubmit)="submitAssessment()">
              <div class="form-group">
                <label class="form-label">File URL / Submission Link</label>
                <div class="input-wrapper">
                  <i class="bi bi-link-45deg input-icon"></i>
                  <input formControlName="fileUri" type="url" class="form-control has-icon"
                    placeholder="https://drive.google.com/..."
                    [class.is-invalid]="isSubmitInvalid('fileUri')" />
                </div>
                @if (isSubmitInvalid('fileUri')) {
                  <span class="invalid-feedback">Valid URL required</span>
                }
              </div>
              <div class="form-group">
                <label class="form-label">Comments (optional)</label>
                <textarea formControlName="comments" class="form-control" rows="3"
                  placeholder="Any notes for your instructor..."></textarea>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-mint" [disabled]="submitting()">
                  @if (submitting()) { <span class="spinner"></span> }
                  Submit <i class="bi bi-upload"></i>
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host { display:block; font-family:'Plus Jakarta Sans',sans-serif; --accent:#2E7BF6; --mint:#00C9A7; --gold:#F0A500; --purple:#A78BFA; --rose:#FB7185; --text-muted:#8898B3; --border:rgba(255,255,255,0.08); }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .page-head { display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap; }
    .eyebrow { display:inline-block;font-size:0.72rem;font-weight:700;color:#4F95FF;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }
    .tabs { display:flex;gap:6px;padding:6px;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;width:fit-content; }
    .tab { display:inline-flex;align-items:center;gap:8px;padding:0.55rem 1rem;background:transparent;border:none;color:var(--text-muted);font-size:0.85rem;font-weight:600;font-family:inherit;border-radius:8px;cursor:pointer;transition:all 0.2s;white-space:nowrap;.tab-count{font-size:0.72rem;padding:2px 8px;border-radius:100px;background:rgba(255,255,255,0.06);color:var(--text-muted)}&.active{background:linear-gradient(135deg,rgba(46,123,246,0.25),rgba(0,201,167,0.15));color:#fff;box-shadow:0 4px 12px rgba(46,123,246,0.22);} }
    .assess-grid { display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1.25rem; }
    .assess-card { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.4rem;display:flex;flex-direction:column;gap:0.875rem;transition:all 0.3s;&:hover{border-color:rgba(46,123,246,0.3);transform:translateY(-3px);} }
    .ac-head { display:flex;justify-content:space-between;align-items:center; }
    .type-badge { display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:100px;font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:0.05em; }
    .type-quiz       { background:rgba(46,123,246,0.15);color:#4F95FF;border:1px solid rgba(46,123,246,0.25); }
    .type-exam       { background:rgba(251,113,133,0.15);color:#FB7185;border:1px solid rgba(251,113,133,0.25); }
    .type-assignment { background:rgba(240,165,0,0.15);color:#F0A500;border:1px solid rgba(240,165,0,0.25); }
    .type-project    { background:rgba(167,139,250,0.15);color:#A78BFA;border:1px solid rgba(167,139,250,0.25); }
    .status-badge { font-size:0.72rem;font-weight:700;text-transform:uppercase;padding:3px 10px;border-radius:100px;letter-spacing:0.04em; }
    .sb-active   { background:rgba(16,185,129,0.15);color:#34D399;border:1px solid rgba(16,185,129,0.25); }
    .sb-draft    { background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25); }
    .sb-closed   { background:rgba(239,68,68,0.15);color:#FCA5A5;border:1px solid rgba(239,68,68,0.25); }
    .sb-archived { background:rgba(148,163,184,0.1);color:#94A3B8;border:1px solid rgba(148,163,184,0.2); }
    .sb-submitted { background:rgba(46,123,246,0.15);color:#4F95FF;border:1px solid rgba(46,123,246,0.25); }
    .sb-graded    { background:rgba(16,185,129,0.15);color:#34D399;border:1px solid rgba(16,185,129,0.25); }
    .sb-resubmission_required { background:rgba(251,113,133,0.15);color:#FB7185;border:1px solid rgba(251,113,133,0.25); }
    .ac-title { font-size:1.05rem;font-weight:700;color:#fff;margin:0;line-height:1.35; }
    .ac-instructions { font-size:0.82rem;color:var(--text-muted);line-height:1.5;margin:0; }
    .ac-meta { display:flex;flex-wrap:wrap;gap:0.75rem;font-size:0.78rem;color:var(--text-muted);span{display:inline-flex;align-items:center;gap:4px;}i{color:#4F95FF;} }
    .ac-footer { margin-top:auto;display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap; }
    .file-link { display:inline-flex;align-items:center;gap:6px;color:var(--accent-light);font-size:0.82rem;font-weight:700;text-decoration:none;padding:5px 10px;background:rgba(46,123,246,0.1);border:1px solid rgba(46,123,246,0.25);border-radius:8px;transition:all 0.2s;&:hover{background:rgba(46,123,246,0.2);color:#fff;} }
    .submit-btn { display:inline-flex;align-items:center;gap:6px;padding:0.6rem 1.1rem;background:linear-gradient(135deg,var(--mint),#00856D);border:none;border-radius:10px;color:#fff;font-size:0.85rem;font-weight:700;font-family:inherit;cursor:pointer;transition:all 0.25s;box-shadow:0 6px 18px rgba(0,201,167,0.28);&:hover{transform:translateY(-2px);box-shadow:0 12px 28px rgba(0,201,167,0.45);} }
    .submitted-chip { display:inline-flex;align-items:center;gap:6px;padding:5px 10px;background:rgba(0,201,167,0.12);border:1px solid rgba(0,201,167,0.25);border-radius:100px;color:var(--mint);font-size:0.75rem;font-weight:700; }
    .score-chip { padding:5px 10px;background:rgba(240,165,0,0.12);border:1px solid rgba(240,165,0,0.25);border-radius:100px;color:var(--gold);font-size:0.75rem;font-weight:700; }
    .inactive-label { font-size:0.78rem;color:var(--text-muted); }
    .score-pill { padding:3px 9px;background:rgba(0,201,167,0.15);border-radius:100px;color:var(--mint);font-size:0.78rem;font-weight:700; }
    .muted { color:var(--text-muted); }
    /* Table */
    .table-wrap { overflow-x:auto;border-radius:16px;border:1px solid var(--border); }
    .ec-table { width:100%;border-collapse:collapse;thead tr{background:rgba(255,255,255,0.03);th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);}}tbody tr{border-bottom:1px solid rgba(255,255,255,0.03);transition:background 0.2s;&:last-child{border-bottom:none;}&:hover{background:rgba(255,255,255,0.02);}td{padding:0.85rem 1rem;font-size:0.875rem;vertical-align:middle;}} }
    /* Modal */
    .modal-backdrop { position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease; }
    .modal { background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:520px;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease; }
    .modal-header { display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.5rem;h3{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;} }
    .modal-close { width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:#8898B3;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;} }
    .modal-footer { display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem; }
    .form-group { margin-bottom:1rem; }
    .form-label { display:block;font-size:0.78rem;font-weight:600;color:#8898B3;margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em; }
    .input-wrapper { position:relative; }
    .input-icon { position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#8898B3;font-size:0.9rem;pointer-events:none; }
    .form-control { width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:all 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:#2E7BF6;background:rgba(46,123,246,0.06);}&.has-icon{padding-left:2.4rem;}&.is-invalid{border-color:rgba(239,68,68,0.5);}resize:vertical;min-height:80px; }
    .invalid-feedback { font-size:0.75rem;color:#FCA5A5;margin-top:4px;display:block; }
    .btn { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.2rem;font-family:inherit;font-size:0.875rem;font-weight:600;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;text-decoration:none;white-space:nowrap;&:disabled{opacity:0.55;cursor:not-allowed;} }
    .btn-ghost { background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);color:#fff;&:hover{background:rgba(255,255,255,0.1);} }
    .btn-mint { background:linear-gradient(135deg,var(--mint),#00856D);color:#fff;box-shadow:0 8px 22px rgba(0,201,167,0.28);&:hover:not(:disabled){transform:translateY(-2px);} }
    .empty-box { padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed rgba(255,255,255,0.08);border-radius:18px;i{font-size:2.5rem;color:var(--text-muted);}h3{font-family:'Fraunces',serif;font-size:1.25rem;color:#fff;margin:1rem 0 0.4rem;}p{font-size:0.875rem;color:var(--text-muted);} }
    .loading-overlay { display:flex;justify-content:center;padding:4rem; }
    .spinner { display:inline-block;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;width:18px;height:18px; }
    .spinner-lg { width:40px;height:40px;border-width:3px; }
    @keyframes spin { to{transform:rotate(360deg);} }
    @keyframes fadeIn { from{opacity:0;}to{opacity:1;} }
    @keyframes slideUp { from{opacity:0;transform:translateY(24px);}to{opacity:1;transform:none;} }
  `],
})
export class StudentAssessmentsComponent implements OnInit {
  private auth      = inject(AuthService);
  private assessSvc = inject(AssessmentService);
  private enrollSvc = inject(EnrollmentService);
  private toast     = inject(ToastService);
  private fb        = inject(FormBuilder);

  loading       = signal(true);
  submitting    = signal(false);
  assessments   = signal<Assessment[]>([]);
  submissions   = signal<Submission[]>([]);
  submittedIds  = signal<Set<number>>(new Set());
  showModal     = signal(false);
  selectedAssessment = signal<Assessment | null>(null);
  activeTab     = signal<'available' | 'submissions'>('available');

  submitForm = this.fb.nonNullable.group({
    fileUri:  ['', [Validators.required, Validators.pattern('https?://.+')]],
    comments: [''],
  });

  tabs = [
    { key: 'available',   label: 'Available' },
    { key: 'submissions', label: 'My Submissions' },
  ];

  tabCount(key: string): number {
    if (key === 'available')   return this.assessments().length;
    if (key === 'submissions') return this.submissions().length;
    return 0;
  }

  typeIcon(type: AssessmentType): string {
    const m: Partial<Record<AssessmentType, string>> = {
      QUIZ: 'bi-patch-question', EXAM: 'bi-journal-text',
      ASSIGNMENT: 'bi-pencil-square', PROJECT: 'bi-kanban',
    };
    return m[type] ?? 'bi-file-text';
  }

  isSubmitInvalid(f: string): boolean {
    const c = this.submitForm.get(f);
    return !!(c?.invalid && c?.touched);
  }

  getSubmission(assessmentId: number): Submission | undefined {
    return this.submissions().find(s => s.assessmentId === assessmentId);
  }

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    // Load submissions first
    this.assessSvc.getSubmissionsByStudent(sId).subscribe({
      next: r => {
        if (r.success) {
          this.submissions.set(r.data ?? []);
          this.submittedIds.set(new Set((r.data ?? []).map(s => s.assessmentId)));
        }
      },
    });
    // Get enrolled courses then fetch assessments
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => {
        if (!r.success || !r.data?.length) { this.loading.set(false); return; }
        const courseIds = [...new Set(r.data.map(e => e.courseId))];
        const all: Assessment[] = [];
        let pending = courseIds.length;
        courseIds.forEach(cId => {
          this.assessSvc.getByCourse(cId).subscribe({
            next: ar => { if (ar.success) all.push(...(ar.data ?? [])); },
            complete: () => { if (--pending === 0) { this.assessments.set(all); this.loading.set(false); } },
          });
        });
      },
      error: () => this.loading.set(false),
    });
  }

  openSubmit(a: Assessment): void {
    this.selectedAssessment.set(a);
    this.submitForm.reset();
    this.showModal.set(true);
  }

  closeModal(): void { this.showModal.set(false); }

  submitAssessment(): void {
    if (this.submitForm.invalid) { this.submitForm.markAllAsTouched(); return; }
    const a   = this.selectedAssessment()!;
    const sId = this.auth.userId() ?? 1;
    this.submitting.set(true);
    this.assessSvc.submit({ assessmentId: a.assessmentId, studentId: sId, ...this.submitForm.getRawValue() }).subscribe({
      next: r => {
        this.submitting.set(false);
        if (r.success) {
          this.submittedIds.update(s => { s.add(a.assessmentId); return new Set(s); });
          this.submissions.update(arr => [r.data, ...arr]);
          this.toast.success('Submitted!', `Your submission for "${a.title}" was received.`);
          this.closeModal();
        } else {
          this.toast.error('Submission failed', r.message);
        }
      },
      error: err => { this.submitting.set(false); this.toast.error('Error', err?.error?.message); },
    });
  }
}
