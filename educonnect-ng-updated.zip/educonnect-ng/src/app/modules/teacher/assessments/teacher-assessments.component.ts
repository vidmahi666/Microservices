import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AssessmentService, CourseService, ProgressService, StudentService, ToastService } from '../../../core/services/index';
import { Assessment, Submission, Course, Student, AssessmentType, AssessmentStatus } from '../../../core/models';

@Component({
  selector: 'app-teacher-assessments',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Evaluations</span>
          <h1 class="page-title">Assessments</h1>
          <p class="page-desc">Create quizzes, exams and assignments — review & grade submissions</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">
          <i class="bi bi-plus-circle-fill"></i> New Assessment
        </button>
      </header>

      <!-- Tabs -->
      <div class="tab-bar">
        <button class="tab-item" [class.active]="tab() === 'list'" (click)="tab.set('list')">
          <i class="bi bi-list-ul"></i> Assessments
          <span class="tab-count">{{ assessments().length }}</span>
        </button>
        <button class="tab-item" [class.active]="tab() === 'grading'" (click)="tab.set('grading')">
          <i class="bi bi-star-fill"></i> Grading Queue
          <span class="tab-count" [class.urgent]="pendingSubmissions().length > 0">{{ pendingSubmissions().length }}</span>
        </button>
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      }

      <!-- Assessment list -->
      @if (!loading() && tab() === 'list') {
        @if (assessments().length === 0) {
          <div class="empty-state">
            <i class="bi bi-clipboard-plus"></i>
            <h3>No assessments created</h3>
            <p>Create your first quiz or exam for your students.</p>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr>
                  <th>Title</th><th>Course</th><th>Type</th><th>Max Score</th>
                  <th>Due Date</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                @for (a of assessments(); track a.assessmentId) {
                  <tr>
                    <td>
                      <div class="cell-main">{{ a.title }}</div>
                      @if (a.instructions) {
                        <div class="cell-sub">{{ a.instructions | slice:0:50 }}...</div>
                      }
                    </td>
                    <td class="muted">{{ courseTitle(a.courseId) }}</td>
                    <td><span class="type-pill" [attr.data-type]="a.type.toLowerCase()">{{ a.type }}</span></td>
                    <td>{{ a.maxScore ?? 100 }}</td>
                    <td>{{ a.dueDate ? (a.dueDate | date:'mediumDate') : '—' }}</td>
                    <td><span class="status-badge" [ngClass]="'sb-' + a.status.toLowerCase()">{{ a.status }}</span></td>
                    <td>
                      <div class="row-actions">
                        @if (a.status === 'DRAFT') {
                          <button class="action-btn mint" (click)="activate(a)" title="Activate">
                            <i class="bi bi-play-fill"></i>
                          </button>
                        }
                        <button class="action-btn" (click)="loadSubmissions(a)" title="View submissions">
                          <i class="bi bi-inbox-fill"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }

      <!-- Grading queue -->
      @if (!loading() && tab() === 'grading') {
        @if (pendingSubmissions().length === 0) {
          <div class="empty-state">
            <i class="bi bi-check-circle"></i>
            <h3>All caught up!</h3>
            <p>No submissions waiting to be graded.</p>
          </div>
        } @else {
          <div class="grading-grid">
            @for (s of pendingSubmissions(); track s.submissionId) {
              <div class="grade-card">
                <div class="gc-header">
                  <div class="gc-student">
                    <div class="student-av">{{ studentInitials(s.studentId) }}</div>
                    <div>
                      <div class="gc-name">{{ studentName(s.studentId) }}</div>
                      <div class="gc-sub">{{ assessmentTitle(s.assessmentId) }}</div>
                    </div>
                  </div>
                  <span class="status-badge sb-submitted">SUBMITTED</span>
                </div>
                <div class="gc-date"><i class="bi bi-calendar3"></i> {{ s.submittedAt | date:'mediumDate' }}</div>
                @if (s.fileUri) {
                  <a [href]="s.fileUri" target="_blank" class="gc-file">
                    <i class="bi bi-file-earmark-arrow-down"></i> View Submission
                  </a>
                }
                @if (s.comments) {
                  <p class="gc-comments">"{{ s.comments }}"</p>
                }
                <button class="grade-btn" (click)="openGrade(s)">
                  <i class="bi bi-star-fill"></i> Grade Submission
                </button>
              </div>
            }
          </div>
        }
      }

      <!-- Create Assessment Modal -->
      @if (showCreateModal()) {
        <div class="modal-backdrop" (click)="showCreateModal.set(false)">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <div>
                <h3 class="modal-title">New Assessment</h3>
                <p class="modal-sub">Create a quiz, exam or assignment for your students</p>
              </div>
              <button class="modal-close" (click)="showCreateModal.set(false)"><i class="bi bi-x"></i></button>
            </div>
            @if (createError()) {
              <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ createError() }}</div>
            }
            <form [formGroup]="createForm" (ngSubmit)="doCreate()">
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">Course *</label>
                  <select formControlName="courseId" class="form-select">
                    <option value="">Select course</option>
                    @for (c of myCourses(); track c.courseId) {
                      <option [value]="c.courseId">{{ c.title }}</option>
                    }
                  </select>
                  @if (isCInvalid('courseId')) { <span class="err">Required</span> }
                </div>
                <div class="form-group">
                  <label class="form-label">Type *</label>
                  <select formControlName="type" class="form-select">
                    <option value="">Select type</option>
                    @for (t of types; track t) { <option [value]="t">{{ t }}</option> }
                  </select>
                  @if (isCInvalid('type')) { <span class="err">Required</span> }
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Title *</label>
                <input formControlName="title" type="text" class="form-control" placeholder="e.g. Mid-Term Exam" />
                @if (isCInvalid('title')) { <span class="err">Required</span> }
              </div>
              <div class="form-group">
                <label class="form-label">Instructions</label>
                <textarea formControlName="instructions" class="form-control" rows="3" placeholder="Instructions for students..."></textarea>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">Max Score</label>
                  <input formControlName="maxScore" type="number" class="form-control" placeholder="100" />
                </div>
                <div class="form-group">
                  <label class="form-label">Passing Score (%)</label>
                  <input formControlName="passingScore" type="number" class="form-control" placeholder="60" />
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Due Date</label>
                <input formControlName="dueDate" type="date" class="form-control" />
              </div>
              <div class="form-group">
                <label class="form-label">Assignment File URI</label>
                <input formControlName="fileUri" type="url" class="form-control" placeholder="https://drive.google.com/... or any file link" />
                <span class="field-hint"><i class="bi bi-info-circle"></i> Students will see a clickable link to download/view the assignment material</span>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="showCreateModal.set(false)">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="creating() || createForm.invalid">
                  @if (creating()) { <span class="spinner"></span> Creating... }
                  @else { <i class="bi bi-plus-circle-fill"></i> Create }
                </button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Grade Modal -->
      @if (showGradeModal()) {
        <div class="modal-backdrop" (click)="showGradeModal.set(false)">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <h3 class="modal-title">Grade Submission</h3>
              <button class="modal-close" (click)="showGradeModal.set(false)"><i class="bi bi-x"></i></button>
            </div>
            @if (selectedSub()) {
              <div class="sub-info">
                <p><strong>Student:</strong> #{{ selectedSub()!.studentId }}</p>
                <p><strong>Submitted:</strong> {{ selectedSub()!.submittedAt | date:'medium' }}</p>
                @if (selectedSub()!.fileUri) {
                  <a [href]="selectedSub()!.fileUri" target="_blank" class="gc-file">
                    <i class="bi bi-file-earmark-arrow-down"></i> View submission
                  </a>
                }
              </div>
            }
            <form [formGroup]="gradeForm" (ngSubmit)="doGrade()">
              <div class="form-group" style="margin-top:1rem">
                <label class="form-label">Score *</label>
                <input formControlName="score" type="number" class="form-control" placeholder="e.g. 85" />
                @if (gradeForm.get('score')?.invalid && gradeForm.get('score')?.touched) {
                  <span class="err">Valid score required</span>
                }
              </div>
              <div class="form-group">
                <label class="form-label">Feedback / Comments</label>
                <textarea formControlName="comments" class="form-control" rows="3" placeholder="Optional feedback for the student..."></textarea>
              </div>
              @if (gradeError()) {
                <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ gradeError() }}</div>
              }
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="showGradeModal.set(false)">Cancel</button>
                <button type="submit" class="btn btn-gold" [disabled]="grading() || gradeForm.invalid">
                  @if (grading()) { <span class="spinner"></span> Saving... }
                  @else { <i class="bi bi-star-fill"></i> Submit Grade }
                </button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Update Progress Prompt (shown after grading) -->
      @if (showProgressPrompt()) {
        <div class="modal-backdrop" (click)="showProgressPrompt.set(false)">
          <div class="modal modal-sm" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <div>
                <h3 class="modal-title"><i class="bi bi-bar-chart-fill" style="color:var(--mint);margin-right:8px;"></i>Update Student Progress?</h3>
                <p class="modal-sub">Grade submitted for Student #{{ gradedStudentId() }}. Would you like to update their course progress now?</p>
              </div>
              <button class="modal-close" (click)="showProgressPrompt.set(false)"><i class="bi bi-x"></i></button>
            </div>
            <div class="prompt-body">
              <div class="form-group">
                <label class="form-label">New Completion % for this course</label>
                <input type="number" [(ngModel)]="progressPct" class="form-control" min="0" max="100" placeholder="e.g. 75" />
              </div>
              <div class="form-group">
                <label class="form-label">Metrics Notes (optional)</label>
                <input type="text" [(ngModel)]="progressMetrics" class="form-control" placeholder="e.g. Passed mid-term with score 85" />
              </div>
            </div>
            <div class="modal-footer">
              <button class="btn btn-ghost" (click)="showProgressPrompt.set(false)">Skip</button>
              <button class="btn btn-mint" (click)="doUpdateProgress()" [disabled]="updatingProgress()">
                @if (updatingProgress()) { <span class="spinner"></span> Updating... }
                @else { <i class="bi bi-bar-chart-fill"></i> Update Progress }
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .page-head { display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap; }
    .eyebrow { display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }
    .tab-bar { display:flex;gap:6px;padding:6px;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;width:fit-content;overflow-x:auto; }
    .tab-item { display:inline-flex;align-items:center;gap:8px;padding:0.55rem 1rem;background:transparent;border:none;color:var(--text-muted);font-size:0.85rem;font-weight:600;font-family:inherit;border-radius:8px;cursor:pointer;transition:all 0.2s; .tab-count{font-size:0.72rem;padding:2px 8px;border-radius:100px;background:rgba(255,255,255,0.06);color:var(--text-muted);}&.active{background:linear-gradient(135deg,rgba(46,123,246,0.25),rgba(0,201,167,0.15));color:#fff;.tab-count{background:rgba(255,255,255,0.12);color:#fff;}} .tab-count.urgent{background:rgba(240,165,0,0.2);color:var(--gold);} }
    .table-wrap { overflow-x:auto;border-radius:16px;border:1px solid var(--border); }
    .ec-table { width:100%;border-collapse:collapse; thead tr{background:rgba(255,255,255,0.03);} th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;} td{padding:0.875rem 1rem;font-size:0.875rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);} tbody tr:last-child td{border-bottom:none;} tbody tr:hover{background:rgba(255,255,255,0.025);} }
    .cell-main { font-weight:600;color:#fff; }
    .cell-sub  { font-size:0.75rem;color:var(--text-muted);margin-top:2px; }
    .muted { color:var(--text-muted);font-size:0.85rem; }
    .type-pill { display:inline-flex;align-items:center;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em; &[data-type="quiz"]{background:rgba(46,123,246,0.15);color:var(--accent-light);} &[data-type="exam"]{background:rgba(251,113,133,0.15);color:var(--rose);} &[data-type="assignment"]{background:rgba(0,201,167,0.15);color:var(--mint);} &[data-type="project"]{background:rgba(167,139,250,0.15);color:var(--purple);} }
    .status-badge { display:inline-flex;align-items:center;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em; }
    .sb-draft     { background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25); }
    .sb-active    { background:rgba(16,185,129,0.15);color:#34D399;border:1px solid rgba(16,185,129,0.25); }
    .sb-closed    { background:rgba(239,68,68,0.15);color:#FCA5A5;border:1px solid rgba(239,68,68,0.25); }
    .sb-archived  { background:rgba(148,163,184,0.1);color:#94A3B8;border:1px solid rgba(148,163,184,0.2); }
    .sb-submitted { background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25); }
    .row-actions { display:flex;gap:0.4rem; }
    .action-btn { width:32px;height:32px;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:8px;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:0.9rem;transition:all 0.2s;&:hover{background:rgba(46,123,246,0.15);color:var(--accent-light);border-color:rgba(46,123,246,0.3);}&.mint:hover{background:rgba(0,201,167,0.15);color:var(--mint);border-color:rgba(0,201,167,0.3);} }
    .grading-grid { display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.25rem; }
    .grade-card { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.5rem;display:flex;flex-direction:column;gap:0.75rem;transition:all 0.25s;&:hover{border-color:rgba(240,165,0,0.3);transform:translateY(-3px);} }
    .gc-header { display:flex;justify-content:space-between;align-items:flex-start;gap:1rem; }
    .gc-student { display:flex;align-items:center;gap:0.75rem; }
    .student-av { width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--mint));display:flex;align-items:center;justify-content:center;font-size:0.72rem;font-weight:700;color:#fff;flex-shrink:0; }
    .gc-name { font-size:0.9rem;font-weight:700;color:#fff; }
    .gc-sub  { font-size:0.78rem;color:var(--text-muted);margin-top:2px; }
    .gc-date { font-size:0.8rem;color:var(--text-muted);display:flex;align-items:center;gap:6px; }
    .gc-file { display:inline-flex;align-items:center;gap:6px;color:var(--accent-light);font-size:0.85rem;font-weight:600;text-decoration:none;transition:color 0.2s;&:hover{color:#fff;} }
    .gc-comments { font-size:0.82rem;color:var(--text-muted);font-style:italic;line-height:1.5;margin:0; }
    .grade-btn { padding:0.7rem;background:linear-gradient(135deg,var(--gold),#B87A00);border:none;border-radius:10px;color:#1a1300;font-size:0.88rem;font-weight:700;font-family:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;transition:all 0.25s;margin-top:auto;&:hover{transform:translateY(-2px);box-shadow:0 10px 24px rgba(240,165,0,0.35);} }
    .sub-info { padding:1rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;margin-bottom:1rem;font-size:0.875rem;display:flex;flex-direction:column;gap:0.4rem;p{margin:0;color:var(--text-muted);strong{color:#fff;}} }
    .modal-backdrop { position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease; }
    .modal { background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:580px;max-height:90vh;overflow-y:auto;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease; }
    .modal-header { display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.5rem; }
    .modal-title { font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;margin:0; }
    .modal-sub   { font-size:0.85rem;color:var(--text-muted);margin-top:4px; }
    .modal-close { width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--text-muted);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;} }
    .alert-error { display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1.25rem; }
    .form-row { display:grid;grid-template-columns:1fr 1fr;gap:1rem; }
    .form-group { margin-bottom:1rem; }
    .form-label { display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em; }
    .form-control { width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);} }
    .form-select { @extend .form-control;cursor:pointer;appearance:none;option{background:#1A2F5E;} }
    textarea.form-control { min-height:80px;resize:vertical; }
    .err { font-size:0.75rem;color:#FCA5A5;margin-top:4px;display:block; }
    .modal-footer { display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem; }
    .btn { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.25rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;&:disabled{opacity:0.55;cursor:not-allowed;} }
    .btn-primary { background:linear-gradient(135deg,var(--accent),#1A5FD4);color:#fff;box-shadow:0 6px 18px rgba(46,123,246,0.3);&:hover:not(:disabled){transform:translateY(-2px);} }
    .btn-gold    { background:linear-gradient(135deg,var(--gold),#B87A00);color:#1a1300;&:hover:not(:disabled){transform:translateY(-2px);} }
    .btn-ghost   { background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);} }
    .empty-state { padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px; i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;} h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;} p{font-size:0.875rem;color:var(--text-muted);} }
    .field-hint { display:block;font-size:0.72rem;color:var(--text-muted);margin-top:4px;display:flex;align-items:center;gap:5px;i{color:var(--accent-light);} }
    .modal-sm { max-width:460px; }
    .prompt-body { margin-top:0.5rem; }
    .btn-mint { background:linear-gradient(135deg,var(--mint),#00856D);color:#fff;&:hover:not(:disabled){transform:translateY(-2px);} }
    .ec-spin  { display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite; }
    .load-center { display:flex;justify-content:center;padding:3rem; }
    @media(max-width:640px){.form-row{grid-template-columns:1fr;}.grading-grid{grid-template-columns:1fr;}}
    @keyframes spin    { to{transform:rotate(360deg);} }
    @keyframes fadeIn  { from{opacity:0;} to{opacity:1;} }
    @keyframes slideUp { from{opacity:0;transform:translateY(24px);} to{opacity:1;transform:none;} }
  `],
})
export class TeacherAssessmentsComponent implements OnInit {
  private auth        = inject(AuthService);
  private assessSvc   = inject(AssessmentService);
  private courseSvc   = inject(CourseService);
  private progressSvc = inject(ProgressService);
  private studentSvc  = inject(StudentService);
  private toast       = inject(ToastService);
  private fb          = inject(FormBuilder);

  loading              = signal(true);
  tab                  = signal<'list'|'grading'>('list');
  myCourses            = signal<Course[]>([]);
  assessments          = signal<Assessment[]>([]);
  pendingSubmissions   = signal<Submission[]>([]);
  studentNameMap       = signal<Map<number, string>>(new Map());
  showCreateModal      = signal(false);
  showGradeModal       = signal(false);
  showProgressPrompt   = signal(false);
  selectedSub          = signal<Submission|null>(null);
  gradedStudentId      = signal<number>(0);
  gradedCourseId       = signal<number>(0);
  creating             = signal(false);
  grading              = signal(false);
  updatingProgress     = signal(false);
  createError          = signal('');
  gradeError           = signal('');
  progressPct          = 0;
  progressMetrics      = '';

  types: AssessmentType[] = ['QUIZ','EXAM','ASSIGNMENT','PROJECT'];

  studentName(id: number): string {
    return this.studentNameMap().get(id) ?? `Student #${id}`;
  }

  studentInitials(id: number): string {
    const name = this.studentNameMap().get(id);
    if (name) return name.trim().split(' ').slice(0,2).map(w => w[0]).join('').toUpperCase();
    return 'S' + String(id).slice(-2);
  }

  assessmentTitle(id: number): string {
    return this.assessments().find(a => a.assessmentId === id)?.title ?? `Assessment #${id}`;
  }

  courseTitle(id: number): string {
    return this.myCourses().find(c => c.courseId === id)?.title ?? `Course #${id}`;
  }

  createForm = this.fb.nonNullable.group({
    courseId:     ['', Validators.required],
    title:        ['', Validators.required],
    type:         ['', Validators.required],
    instructions: [''],
    maxScore:     [100, [Validators.required, Validators.min(0)]],
    passingScore: [60],
    dueDate:      [''],
    fileUri:      [''],
  });

  gradeForm = this.fb.nonNullable.group({
    score:    [null as unknown as number, [Validators.required, Validators.min(0)]],
    comments: [''],
  });

  isCInvalid(f: string): boolean {
    const c = this.createForm.get(f);
    return !!(c?.invalid && c?.touched);
  }

  ngOnInit(): void {
    const tid = this.auth.userId() ?? 1;
    // Load all students to build name map
    this.studentSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const m = new Map<number, string>();
          (r.data ?? []).forEach(s => m.set(s.studentId, s.name));
          this.studentNameMap.set(m);
        }
      },
    });
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const mine = (r.data ?? []).filter(c => c.teacherUserId === tid);
          this.myCourses.set(mine);
          this.loadAssessments(mine.map(c => c.courseId));
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false),
    });
  }

  loadAssessments(courseIds: number[]): void {
    if (!courseIds.length) { this.loading.set(false); return; }
    const all: Assessment[] = [];
    let pending = courseIds.length;
    courseIds.forEach(id => {
      this.assessSvc.getByCourse(id).subscribe({
        next: r => {
          if (r.success) all.push(...(r.data ?? []));
          if (--pending === 0) {
            this.assessments.set(all);
            this.loadAllSubmissions(all.map(a => a.assessmentId));
            this.loading.set(false);
          }
        },
        error: () => { if (--pending === 0) this.loading.set(false); },
      });
    });
  }

  loadAllSubmissions(assessmentIds: number[]): void {
    if (!assessmentIds.length) return;
    const pending_subs: Submission[] = [];
    let pending = assessmentIds.length;
    assessmentIds.forEach(id => {
      this.assessSvc.getSubmissionsByAssessment(id).subscribe({
        next: r => {
          if (r.success) pending_subs.push(...(r.data ?? []).filter(s => s.status === 'SUBMITTED'));
          if (--pending === 0) this.pendingSubmissions.set(pending_subs);
        },
        error: () => { --pending; },
      });
    });
  }

  loadSubmissions(a: Assessment): void {
    this.tab.set('grading');
    this.assessSvc.getSubmissionsByAssessment(a.assessmentId).subscribe({
      next: r => {
        if (r.success) {
          const pending = (r.data ?? []).filter(s => s.status === 'SUBMITTED');
          this.pendingSubmissions.update(all => [...all.filter(x => x.assessmentId !== a.assessmentId), ...pending]);
        }
      },
    });
  }

  openCreate(): void { this.createForm.reset({ maxScore: 100, passingScore: 60 }); this.createError.set(''); this.showCreateModal.set(true); }

  doCreate(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.creating.set(true);
    const v = this.createForm.getRawValue();
    this.assessSvc.create({ ...v, courseId: +v.courseId } as any).subscribe({
      next: r => {
        this.creating.set(false);
        if (r.success) {
          this.assessments.update(a => [r.data, ...a]);
          this.showCreateModal.set(false);
          this.toast.success('Assessment created!', `"${r.data.title}" saved as draft.`);
        } else { this.createError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.creating.set(false); this.createError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  activate(a: Assessment): void {
    this.assessSvc.activate(a.assessmentId).subscribe({
      next: r => {
        if (r.success) {
          this.assessments.update(arr => arr.map(x => x.assessmentId === a.assessmentId ? { ...x, status: AssessmentStatus.ACTIVE } : x));
          this.toast.success('Activated!', `"${a.title}" is now live for students.`);
        }
      },
    });
  }

  openGrade(s: Submission): void {
    this.selectedSub.set(s);
    this.gradeForm.reset();
    this.gradeError.set('');
    this.showGradeModal.set(true);
  }

  doGrade(): void {
    if (this.gradeForm.invalid) { this.gradeForm.markAllAsTouched(); return; }
    const s = this.selectedSub()!;
    this.grading.set(true);
    this.assessSvc.grade(s.submissionId, this.gradeForm.getRawValue() as any).subscribe({
      next: r => {
        this.grading.set(false);
        if (r.success) {
          this.pendingSubmissions.update(arr => arr.filter(x => x.submissionId !== s.submissionId));
          this.showGradeModal.set(false);
          this.toast.success('Graded!', `Score of ${this.gradeForm.value.score} saved.`);
          // Find courseId for this assessment to support progress update
          const assessment = this.assessments().find(a => a.assessmentId === s.assessmentId);
          this.gradedStudentId.set(s.studentId);
          this.gradedCourseId.set(assessment?.courseId ?? 0);
          this.progressPct = 0;
          this.progressMetrics = '';
          this.showProgressPrompt.set(true);
        } else { this.gradeError.set(r.message ?? 'Grading failed'); }
      },
      error: err => { this.grading.set(false); this.gradeError.set(err?.error?.message ?? 'Grading failed'); },
    });
  }

  doUpdateProgress(): void {
    const studentId = this.gradedStudentId();
    const courseId  = this.gradedCourseId();
    if (!studentId || !courseId) { this.showProgressPrompt.set(false); return; }
    this.updatingProgress.set(true);
    this.progressSvc.update(studentId, courseId, {
      completionPercentage: this.progressPct,
      metricsJson: this.progressMetrics || undefined,
    }).subscribe({
      next: r => {
        this.updatingProgress.set(false);
        this.showProgressPrompt.set(false);
        if (r.success) {
          this.toast.success('Progress updated!', `Student #${studentId} is now at ${this.progressPct}%.`);
        } else {
          this.toast.warning('Progress update failed', r.message ?? 'Could not update progress.');
        }
      },
      error: () => {
        this.updatingProgress.set(false);
        this.showProgressPrompt.set(false);
        this.toast.error('Error', 'Could not update progress.');
      },
    });
  }
}
