import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="landing">
      <!-- Navbar -->
      <nav class="lnav">
        <div class="lnav-inner">
          <div class="brand">
            <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
            <span class="brand-name">Edu<span>Connect</span></span>
          </div>
          <div class="lnav-cta">
            <a routerLink="/login" class="btn-ghost">Log in</a>
            <a routerLink="/register" class="btn-accent">Get started</a>
          </div>
        </div>
      </nav>

      <!-- Hero -->
      <section class="hero">
        <div class="hero-blobs">
          <div class="blob blob-1"></div>
          <div class="blob blob-2"></div>
          <div class="blob blob-3"></div>
        </div>
        <div class="hero-inner">
          <div class="hero-text">
            <span class="hero-badge"><span class="dot"></span> Next-gen Learning Platform</span>
            <h1 class="hero-title">
              Empower Every<br>
              <span class="grad-text">Learner & Educator</span>
            </h1>
            <p class="hero-desc">
              EduConnect bridges students, teachers, administrators and compliance teams on one unified platform — from enrollment to certification.
            </p>
            <div class="hero-actions">
              <a routerLink="/register" class="btn-hero-primary">
                Start for free <i class="bi bi-arrow-right-circle-fill"></i>
              </a>
              <a routerLink="/login" class="btn-hero-ghost">
                <i class="bi bi-box-arrow-in-right"></i> Sign in
              </a>
            </div>
            <div class="hero-trust">
              <span><i class="bi bi-shield-check-fill"></i> Role-Based Access</span>
              <span><i class="bi bi-bar-chart-fill"></i> Progress Tracking</span>
              <span><i class="bi bi-file-earmark-check-fill"></i> Compliance Ready</span>
            </div>
          </div>
          <div class="hero-visual">
            <div class="hv-card hv-main">
              <div class="hv-head">
                <div class="hv-av"></div>
                <div>
                  <div class="hv-name">Welcome back, Alex 👋</div>
                  <div class="hv-sub">Continue where you left off</div>
                </div>
              </div>
              <div class="hv-prog-row">
                <span class="hv-course">Advanced Mathematics</span>
                <span class="hv-pct">78%</span>
              </div>
              <div class="hv-bar"><div class="hv-bar-fill" style="width:78%"></div></div>
              <div class="hv-prog-row">
                <span class="hv-course">Physics II</span>
                <span class="hv-pct">55%</span>
              </div>
              <div class="hv-bar"><div class="hv-bar-fill alt" style="width:55%"></div></div>
              <div class="hv-stat-row">
                <div class="hv-stat"><span class="hv-sv">12</span><span class="hv-sl">Lessons</span></div>
                <div class="hv-stat"><span class="hv-sv">3</span><span class="hv-sl">Pending</span></div>
                <div class="hv-stat"><span class="hv-sv">89%</span><span class="hv-sl">Score</span></div>
              </div>
            </div>
            <div class="hv-card hv-float hv-f1">
              <i class="bi bi-award-fill"></i>
              <div>
                <div class="hv-ft">Course Completed!</div>
                <div class="hv-fs">Data Structures — Grade A</div>
              </div>
            </div>
            <div class="hv-card hv-float hv-f2">
              <i class="bi bi-people-fill" style="color:#A78BFA"></i>
              <div>
                <div class="hv-ft">1,240 Learners</div>
                <div class="hv-fs">Active this week</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Features -->
      <section class="features">
        <div class="features-inner">
          <div class="sec-head">
            <span class="sec-eyebrow">Everything you need</span>
            <h2 class="sec-title">One platform for the entire education lifecycle</h2>
          </div>
          <div class="feat-grid">
            @for (f of features; track f.title) {
              <div class="feat-card">
                <div class="feat-icon" [attr.data-tone]="f.tone">
                  <i class="bi" [ngClass]="f.icon"></i>
                </div>
                <h3 class="feat-title">{{ f.title }}</h3>
                <p class="feat-desc">{{ f.desc }}</p>
              </div>
            }
          </div>
        </div>
      </section>

      <!-- Roles section -->
      <section class="roles-section">
        <div class="roles-inner">
          <div class="sec-head">
            <span class="sec-eyebrow">Built for every stakeholder</span>
            <h2 class="sec-title">A tailored experience for each role</h2>
          </div>
          <div class="roles-grid">
            @for (r of roles; track r.label) {
              <div class="role-card" [attr.data-tone]="r.tone">
                <div class="role-icon"><i class="bi" [ngClass]="r.icon"></i></div>
                <div class="role-label">{{ r.label }}</div>
                <ul class="role-list">
                  @for (item of r.items; track item) {
                    <li><i class="bi bi-check-circle-fill"></i> {{ item }}</li>
                  }
                </ul>
              </div>
            }
          </div>
        </div>
      </section>

      <!-- CTA Banner -->
      <section class="cta-banner">
        <div class="cta-inner">
          <h2 class="cta-title">Ready to transform learning?</h2>
          <p class="cta-desc">Join thousands of educators and students already on EduConnect.</p>
          <div class="cta-btns">
            <a routerLink="/register" class="btn-hero-primary">
              Create free account <i class="bi bi-arrow-right-circle-fill"></i>
            </a>
            <a routerLink="/login" class="btn-hero-ghost">
              Sign in <i class="bi bi-box-arrow-in-right"></i>
            </a>
          </div>
        </div>
      </section>

      <!-- Footer -->
      <footer class="lfoot">
        <div class="lfoot-inner">
          <div class="brand">
            <div class="brand-icon sm"><i class="bi bi-mortarboard-fill"></i></div>
            <span class="brand-name">Edu<span>Connect</span></span>
          </div>
          <p class="foot-copy">© 2025 EduConnect. All rights reserved.</p>
        </div>
      </footer>
    </div>
  `,
  styles: [`
    :host {
      --navy:         #0D1B3E;
      --navy-mid:     #1A2F5E;
      --navy-deep:    #0A1530;
      --accent:       #2E7BF6;
      --accent-light: #4F95FF;
      --gold:         #F0A500;
      --mint:         #00C9A7;
      --purple:       #A78BFA;
      --rose:         #FB7185;
      --text-muted:   #8898B3;
      --border:       rgba(255,255,255,0.08);
      display: block;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    * { box-sizing: border-box; }

    .landing { background: var(--navy-deep); min-height: 100vh; color: #fff; }

    /* NAV */
    .lnav { position: sticky; top: 0; z-index: 100; background: rgba(10,21,48,0.85); backdrop-filter: blur(12px); border-bottom: 1px solid var(--border); }
    .lnav-inner { max-width: 1200px; margin: 0 auto; padding: 1rem 2rem; display: flex; align-items: center; justify-content: space-between; }
    .lnav-cta { display: flex; align-items: center; gap: 0.75rem; }

    /* Brand */
    .brand { display: flex; align-items: center; gap: 10px; cursor: pointer; text-decoration: none; }
    .brand-icon { width: 38px; height: 38px; background: linear-gradient(135deg, #2E7BF6, #00C9A7); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 1.1rem; flex-shrink: 0; }
    .brand-icon.sm { width: 30px; height: 30px; font-size: 0.9rem; }
    .brand-name { font-family: 'Fraunces', serif; font-size: 1.3rem; font-weight: 700; color: #fff; letter-spacing: -0.02em; span { color: var(--accent-light); } }

    .btn-ghost { padding: 0.55rem 1.25rem; background: transparent; border: 1px solid var(--border); border-radius: 10px; color: #fff; font-size: 0.88rem; font-weight: 600; text-decoration: none; transition: all 0.2s; &:hover { background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.2); } }
    .btn-accent { padding: 0.55rem 1.25rem; background: linear-gradient(135deg, var(--accent), #1A5FD4); border-radius: 10px; color: #fff; font-size: 0.88rem; font-weight: 700; text-decoration: none; transition: all 0.2s; &:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(46,123,246,0.4); } }

    /* HERO */
    .hero { position: relative; overflow: hidden; min-height: 88vh; display: flex; align-items: center; }
    .hero-blobs { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
    .blob { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.25; animation: pulse 8s ease-in-out infinite alternate; }
    .blob-1 { width: 600px; height: 600px; background: radial-gradient(circle, #2E7BF6, transparent); top: -200px; left: -100px; animation-delay: 0s; }
    .blob-2 { width: 500px; height: 500px; background: radial-gradient(circle, #00C9A7, transparent); bottom: -150px; right: -50px; animation-delay: 3s; }
    .blob-3 { width: 350px; height: 350px; background: radial-gradient(circle, #A78BFA, transparent); top: 30%; right: 20%; animation-delay: 6s; }

    .hero-inner { max-width: 1200px; margin: 0 auto; padding: 5rem 2rem; display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; position: relative; z-index: 1; }
    .hero-text { display: flex; flex-direction: column; gap: 1.5rem; }
    .hero-badge { display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; background: rgba(46,123,246,0.15); border: 1px solid rgba(46,123,246,0.3); border-radius: 100px; font-size: 0.78rem; font-weight: 700; color: var(--accent-light); text-transform: uppercase; letter-spacing: 0.08em; width: fit-content; .dot { width: 7px; height: 7px; background: var(--mint); border-radius: 50%; animation: blink 1.5s ease-in-out infinite; } }
    .hero-title { font-family: 'Fraunces', serif; font-size: clamp(2.5rem, 5vw, 3.5rem); font-weight: 900; line-height: 1.1; letter-spacing: -0.03em; color: #fff; }
    .grad-text { background: linear-gradient(135deg, var(--accent-light), var(--mint)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
    .hero-desc { font-size: 1.05rem; color: var(--text-muted); line-height: 1.7; max-width: 480px; }
    .hero-actions { display: flex; gap: 1rem; flex-wrap: wrap; }

    .btn-hero-primary { display: inline-flex; align-items: center; gap: 10px; padding: 0.85rem 2rem; background: linear-gradient(135deg, var(--accent), #1A5FD4); border-radius: 14px; color: #fff; font-size: 1rem; font-weight: 700; text-decoration: none; box-shadow: 0 8px 24px rgba(46,123,246,0.4); transition: all 0.25s; &:hover { transform: translateY(-3px); box-shadow: 0 16px 36px rgba(46,123,246,0.5); } }
    .btn-hero-ghost { display: inline-flex; align-items: center; gap: 10px; padding: 0.85rem 2rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); border-radius: 14px; color: #fff; font-size: 1rem; font-weight: 600; text-decoration: none; transition: all 0.25s; &:hover { background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.25); } }

    .hero-trust { display: flex; gap: 1.5rem; flex-wrap: wrap; padding-top: 0.5rem; span { display: flex; align-items: center; gap: 6px; font-size: 0.82rem; color: var(--text-muted); font-weight: 500; i { color: var(--mint); } } }

    /* HERO VISUAL */
    .hero-visual { position: relative; height: 380px; }
    .hv-card { background: rgba(26,47,94,0.8); border: 1px solid rgba(255,255,255,0.1); border-radius: 18px; padding: 1.5rem; backdrop-filter: blur(12px); }
    .hv-main { position: absolute; top: 0; left: 0; right: 0; display: flex; flex-direction: column; gap: 1rem; }
    .hv-head { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.25rem; }
    .hv-av { width: 42px; height: 42px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), var(--mint)); flex-shrink: 0; }
    .hv-name { font-size: 0.95rem; font-weight: 700; color: #fff; }
    .hv-sub  { font-size: 0.78rem; color: var(--text-muted); }
    .hv-prog-row { display: flex; justify-content: space-between; font-size: 0.82rem; }
    .hv-course { color: var(--text-muted); }
    .hv-pct    { color: #fff; font-weight: 700; }
    .hv-bar    { height: 6px; background: rgba(255,255,255,0.07); border-radius: 100px; overflow: hidden; }
    .hv-bar-fill { height: 100%; background: linear-gradient(90deg, var(--accent), var(--accent-light)); border-radius: 100px; transition: width 1s ease; &.alt { background: linear-gradient(90deg, var(--mint), #00a889); } }
    .hv-stat-row { display: flex; gap: 1rem; margin-top: 0.5rem; }
    .hv-stat  { flex: 1; text-align: center; padding: 0.5rem; background: rgba(255,255,255,0.04); border-radius: 10px; }
    .hv-sv    { display: block; font-size: 1.1rem; font-weight: 800; color: #fff; }
    .hv-sl    { font-size: 0.7rem; color: var(--text-muted); font-weight: 500; }
    .hv-float { position: absolute; display: flex; align-items: center; gap: 0.6rem; padding: 0.75rem 1rem; border-radius: 14px; font-size: 0.82rem; box-shadow: 0 12px 32px rgba(0,0,0,0.4); i { font-size: 1.3rem; } }
    .hv-f1 { bottom: 30px; left: -30px; color: var(--gold); i { color: var(--gold); } background: rgba(26,47,94,0.9); }
    .hv-f2 { bottom: -10px; right: -20px; background: rgba(26,47,94,0.9); }
    .hv-ft   { font-weight: 700; color: #fff; }
    .hv-fs   { font-size: 0.72rem; color: var(--text-muted); margin-top: 1px; }

    /* FEATURES */
    .features { padding: 6rem 2rem; background: rgba(255,255,255,0.01); border-top: 1px solid var(--border); }
    .features-inner { max-width: 1200px; margin: 0 auto; }
    .sec-head { text-align: center; margin-bottom: 3rem; }
    .sec-eyebrow { font-size: 0.72rem; font-weight: 700; color: var(--accent-light); text-transform: uppercase; letter-spacing: 0.12em; }
    .sec-title { font-family: 'Fraunces', serif; font-size: clamp(1.6rem, 3vw, 2.2rem); font-weight: 800; color: #fff; letter-spacing: -0.02em; margin-top: 0.5rem; }
    .feat-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1.5rem; }
    .feat-card { background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 18px; padding: 1.75rem; transition: all 0.3s; &:hover { border-color: rgba(46,123,246,0.3); transform: translateY(-4px); background: rgba(255,255,255,0.05); } }
    .feat-icon { width: 48px; height: 48px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; margin-bottom: 1rem; &[data-tone="blue"]  { background: rgba(46,123,246,0.15); color: var(--accent-light); } &[data-tone="mint"]  { background: rgba(0,201,167,0.15); color: var(--mint); } &[data-tone="gold"]  { background: rgba(240,165,0,0.15); color: var(--gold); } &[data-tone="purple"]{ background: rgba(167,139,250,0.15); color: var(--purple); } &[data-tone="rose"]  { background: rgba(251,113,133,0.15); color: var(--rose); } &[data-tone="teal"]  { background: rgba(20,184,166,0.15); color: #2DD4BF; } }
    .feat-title { font-size: 1rem; font-weight: 700; color: #fff; margin-bottom: 0.5rem; }
    .feat-desc  { font-size: 0.875rem; color: var(--text-muted); line-height: 1.6; }

    /* ROLES */
    .roles-section { padding: 6rem 2rem; }
    .roles-inner   { max-width: 1200px; margin: 0 auto; }
    .roles-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1.25rem; }
    .role-card { background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 18px; padding: 1.5rem; transition: all 0.3s; &:hover { transform: translateY(-4px); } &[data-tone="blue"]   { &:hover { border-color: rgba(46,123,246,0.4); } } &[data-tone="mint"]   { &:hover { border-color: rgba(0,201,167,0.4); } } &[data-tone="gold"]   { &:hover { border-color: rgba(240,165,0,0.4); } } &[data-tone="purple"] { &:hover { border-color: rgba(167,139,250,0.4); } } &[data-tone="rose"]   { &:hover { border-color: rgba(251,113,133,0.4); } } }
    .role-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; margin-bottom: 0.875rem; background: rgba(255,255,255,0.06); color: #fff; }
    .role-label { font-size: 1rem; font-weight: 700; color: #fff; margin-bottom: 0.875rem; }
    .role-list { list-style: none; display: flex; flex-direction: column; gap: 0.5rem; li { display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: var(--text-muted); i { color: var(--mint); font-size: 0.75rem; flex-shrink: 0; } } }

    /* CTA */
    .cta-banner { margin: 2rem; border-radius: 24px; background: linear-gradient(135deg, rgba(46,123,246,0.2), rgba(0,201,167,0.1)); border: 1px solid rgba(46,123,246,0.3); padding: 4rem 2rem; text-align: center; }
    .cta-inner  { max-width: 600px; margin: 0 auto; }
    .cta-title  { font-family: 'Fraunces', serif; font-size: clamp(1.8rem, 4vw, 2.5rem); font-weight: 900; color: #fff; letter-spacing: -0.02em; margin-bottom: 1rem; }
    .cta-desc   { font-size: 1rem; color: var(--text-muted); margin-bottom: 2rem; line-height: 1.6; }
    .cta-btns   { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }

    /* FOOTER */
    .lfoot { border-top: 1px solid var(--border); padding: 2rem; }
    .lfoot-inner { max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; }
    .foot-copy { font-size: 0.82rem; color: var(--text-muted); }

    /* Animations */
    @keyframes pulse { 0% { transform: scale(1) translate(0,0); } 100% { transform: scale(1.1) translate(20px, -20px); } }
    @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

    @media (max-width: 900px) {
      .hero-inner { grid-template-columns: 1fr; }
      .hero-visual { display: none; }
    }
    @media (max-width: 600px) {
      .lnav-inner { padding: 1rem; }
      .hero-inner { padding: 3rem 1rem; }
    }
  `],
})
export class LandingComponent {
  features = [
    { title: 'Smart Enrollment', icon: 'bi-person-plus-fill', tone: 'blue', desc: 'Streamline course enrollment with automated notifications and instant status updates.' },
    { title: 'Live Progress Tracking', icon: 'bi-bar-chart-line-fill', tone: 'mint', desc: 'Per-course completion metrics updated in real-time after every graded submission.' },
    { title: 'Assessment Engine', icon: 'bi-pencil-square', tone: 'gold', desc: 'Create quizzes, exams, assignments and projects with file attachments and due dates.' },
    { title: 'Content Management', icon: 'bi-collection-play-fill', tone: 'purple', desc: 'Upload videos, PDFs and documents. Students see content only after valid enrollment.' },
    { title: 'Compliance & Auditing', icon: 'bi-shield-check-fill', tone: 'rose', desc: 'Full compliance records and government audit trails for regulatory accountability.' },
    { title: 'Role-Based Access', icon: 'bi-person-badge-fill', tone: 'teal', desc: 'Granular permissions for Students, Teachers, Admins, Compliance Officers and Auditors.' },
  ];

  roles = [
    { label: 'Student', icon: 'bi-person-fill', tone: 'blue', items: ['Enroll in courses', 'View locked content', 'Submit assessments', 'Track progress'] },
    { label: 'Teacher', icon: 'bi-person-video2', tone: 'mint', items: ['Create course content', 'Publish assessments', 'Grade submissions', 'Update progress'] },
    { label: 'Admin', icon: 'bi-gear-fill', tone: 'gold', items: ['Manage all users', 'Oversee courses', 'Audit overview', 'System reports'] },
    { label: 'Compliance Officer', icon: 'bi-shield-fill', tone: 'purple', items: ['Policy monitoring', 'Compliance records', 'Review violations', 'Generate reports'] },
    { label: 'Government Auditor', icon: 'bi-search', tone: 'rose', items: ['Audit scheduling', 'Log reviews', 'Status tracking', 'Oversight reports'] },
  ];
}
