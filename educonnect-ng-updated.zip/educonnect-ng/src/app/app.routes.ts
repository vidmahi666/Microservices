import { Routes } from '@angular/router';
import { authGuard, roleGuard, guestGuard } from './core/guards';
import { UserRole } from './core/models';

export const routes: Routes = [
  // ── Landing (default route) ──────────────────────────────────
  {
    path: '',
    loadComponent: () => import('./modules/landing/landing.component').then(m => m.LandingComponent),
  },

  // ── Auth ─────────────────────────────────────────────────────
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./modules/auth/login/login.component').then(m => m.LoginComponent),
  },
  {
    path: 'register',
    canActivate: [guestGuard],
    loadComponent: () => import('./modules/auth/register/register.component').then(m => m.RegisterComponent),
  },

  // ── Student portal ───────────────────────────────────────────
  {
    path: 'student',
    canActivate: [authGuard, roleGuard(UserRole.STUDENT)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard',   loadComponent: () => import('./modules/student/dashboard/student-dashboard.component').then(m => m.StudentDashboardComponent) },
      { path: 'courses',     loadComponent: () => import('./modules/student/courses/student-courses.component').then(m => m.StudentCoursesComponent) },
      { path: 'course-content/:courseId', loadComponent: () => import('./modules/student/course-content/course-content.component').then(m => m.CourseContentComponent) },
      { path: 'assessments', loadComponent: () => import('./modules/student/assessments/student-assessments.component').then(m => m.StudentAssessmentsComponent) },
      { path: 'progress',    loadComponent: () => import('./modules/student/progress/student-progress.component').then(m => m.StudentProgressComponent) },
      { path: 'profile',     loadComponent: () => import('./modules/student/profile/student-profile.component').then(m => m.StudentProfileComponent) },
    ],
  },

  // ── Teacher portal ───────────────────────────────────────────
  {
    path: 'teacher',
    canActivate: [authGuard, roleGuard(UserRole.TEACHER)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard',   loadComponent: () => import('./modules/teacher/dashboard/teacher-dashboard.component').then(m => m.TeacherDashboardComponent) },
      { path: 'courses',     loadComponent: () => import('./modules/teacher/courses/teacher-courses.component').then(m => m.TeacherCoursesComponent) },
      { path: 'content',     loadComponent: () => import('./modules/teacher/content/teacher-content.component').then(m => m.TeacherContentComponent) },
      { path: 'assessments', loadComponent: () => import('./modules/teacher/assessments/teacher-assessments.component').then(m => m.TeacherAssessmentsComponent) },
      { path: 'students',    loadComponent: () => import('./modules/teacher/students/teacher-students.component').then(m => m.TeacherStudentsComponent) },
    ],
  },

  // ── Admin portal (ADMIN + PROGRAM_MANAGER only) ──────────────
  {
    path: 'admin',
    canActivate: [authGuard, roleGuard(UserRole.ADMIN, UserRole.PROGRAM_MANAGER)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard',     loadComponent: () => import('./modules/admin/dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent) },
      { path: 'users',         canActivate: [roleGuard(UserRole.ADMIN)], loadComponent: () => import('./modules/admin/users/admin-users.component').then(m => m.AdminUsersComponent) },
      { path: 'courses',       loadComponent: () => import('./modules/admin/courses/admin-courses.component').then(m => m.AdminCoursesComponent) },
      { path: 'audit-overview',canActivate: [roleGuard(UserRole.ADMIN)], loadComponent: () => import('./modules/admin/audit-overview/admin-audit-overview.component').then(m => m.AdminAuditOverviewComponent) },
      { path: 'reports',       loadComponent: () => import('./modules/admin/reports/admin-reports.component').then(m => m.AdminReportsComponent) },
      // Legacy paths kept for backward-compat
      { path: 'compliance',    canActivate: [roleGuard(UserRole.ADMIN)], loadComponent: () => import('./modules/admin/compliance/admin-compliance.component').then(m => m.AdminComplianceComponent) },
      { path: 'audits',        canActivate: [roleGuard(UserRole.ADMIN)], loadComponent: () => import('./modules/admin/audits/admin-audits.component').then(m => m.AdminAuditsComponent) },
    ],
  },

  // ── Compliance Officer portal (fully isolated) ────────────────
  {
    path: 'compliance',
    canActivate: [authGuard, roleGuard(UserRole.COMPLIANCE_OFFICER)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadComponent: () => import('./modules/compliance/dashboard/compliance-dashboard.component').then(m => m.ComplianceDashboardComponent) },
    ],
  },

  // ── Government Auditor portal (fully isolated) ────────────────
  {
    path: 'auditor',
    canActivate: [authGuard, roleGuard(UserRole.GOVERNMENT_AUDITOR)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadComponent: () => import('./modules/auditor/dashboard/auditor-dashboard.component').then(m => m.AuditorDashboardComponent) },
    ],
  },

  // ── Utility ──────────────────────────────────────────────────
  {
    path: 'unauthorized',
    loadComponent: () => import('./shared/components/error-pages/unauthorized.component').then(m => m.UnauthorizedComponent),
  },
  { path: '**', redirectTo: '/' },
];
