package com.educonnect.auditlogservice.exception;
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String m) { super(m); }
    public ResourceNotFoundException(String r, Long id) { super(r + " not found with id: " + id); }
}
