package com.educonnect.reportservice.service;

import com.educonnect.reportservice.entity.Report;
import com.educonnect.reportservice.exception.ResourceNotFoundException;
import com.educonnect.reportservice.feign.CourseServiceClient;
import com.educonnect.reportservice.feign.StudentServiceClient;
import com.educonnect.reportservice.repository.ReportRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportService {

    private final ReportRepository reportRepository;
    private final StudentServiceClient studentServiceClient;
    private final CourseServiceClient courseServiceClient;

    @CircuitBreaker(name = "studentService", fallbackMethod = "studentCountFallback")
    @Retry(name = "studentService")
    public int fetchStudentCount() {
        return studentServiceClient.getAllStudents().size();
    }

    public int studentCountFallback(Exception ex) {
        log.warn("Circuit open for student-service in report: {}", ex.getMessage());
        return -1; // -1 means unavailable
    }

    @CircuitBreaker(name = "courseService", fallbackMethod = "courseCountFallback")
    @Retry(name = "courseService")
    public int fetchCourseCount() {
        return courseServiceClient.getAllCourses().size();
    }

    public int courseCountFallback(Exception ex) {
        log.warn("Circuit open for course-service in report: {}", ex.getMessage());
        return -1;
    }

    @Transactional
    public Map<String, Object> generateReport(String scope, String generatedBy) {
        Report.ReportScope reportScope = Report.ReportScope.valueOf(scope.toUpperCase());
        Map<String, Object> metrics = new LinkedHashMap<>();
        metrics.put("scope", scope);
        metrics.put("generatedAt", LocalDateTime.now().toString());
        metrics.put("generatedBy", generatedBy != null ? generatedBy : "system");

        switch (reportScope) {
            case STUDENT -> {
                int count = fetchStudentCount();
                metrics.put("totalStudents", count == -1 ? "service-unavailable" : count);
            }
            case COURSE -> {
                int count = fetchCourseCount();
                metrics.put("totalCourses", count == -1 ? "service-unavailable" : count);
            }
            case DASHBOARD -> {
                int students = fetchStudentCount();
                int courses  = fetchCourseCount();
                metrics.put("totalStudents", students == -1 ? "service-unavailable" : students);
                metrics.put("totalCourses",  courses  == -1 ? "service-unavailable" : courses);
            }
            default -> metrics.put("message", "Report for scope " + scope + " generated");
        }

        reportRepository.save(Report.builder().scope(reportScope).metrics(metrics.toString())
                .generatedBy(generatedBy != null ? generatedBy : "system").build());
        return metrics;
    }

    @Transactional
    public Map<String, Object> getDashboardMetrics() {
        Map<String, Object> metrics = new LinkedHashMap<>();
        metrics.put("totalStudents", fetchStudentCount());
        metrics.put("totalCourses",  fetchCourseCount());
        metrics.put("generatedAt", LocalDateTime.now().toString());

        reportRepository.save(Report.builder().scope(Report.ReportScope.DASHBOARD)
                .metrics(metrics.toString()).generatedBy("system").build());
        return metrics;
    }

    @Transactional(readOnly = true)
    public List<Report> getAllReports() { return reportRepository.findAll(); }

    @Transactional(readOnly = true)
    public Report getById(Long id) {
        return reportRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Report", id));
    }

    @Transactional(readOnly = true)
    public List<Report> getByScope(String scope) {
        return reportRepository.findByScope(Report.ReportScope.valueOf(scope.toUpperCase()));
    }
}
