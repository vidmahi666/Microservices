package com.educonnect.reportservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name = "reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Report {
    public enum ReportScope { COURSE, ASSESSMENT, PROGRAM, COMPLIANCE, STUDENT, DASHBOARD }
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long reportId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ReportScope scope;
    @Column(columnDefinition = "TEXT") private String metrics;
    @CreatedDate private LocalDateTime generatedDate;
    private String generatedBy;
}
