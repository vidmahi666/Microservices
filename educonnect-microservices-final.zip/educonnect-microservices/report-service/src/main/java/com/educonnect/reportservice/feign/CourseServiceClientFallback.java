package com.educonnect.reportservice.feign;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.util.Collections;
import java.util.List;
import java.util.Map;
@Slf4j @Component
public class CourseServiceClientFallback implements CourseServiceClient {
    @Override public List<Map<String,Object>> getAllCourses() {
        log.warn("course-service unavailable for report"); return Collections.emptyList();
    }
}
