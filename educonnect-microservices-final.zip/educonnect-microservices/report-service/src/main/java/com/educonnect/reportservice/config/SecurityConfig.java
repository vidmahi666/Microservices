package com.educonnect.reportservice.config;
import com.educonnect.reportservice.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean; import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;
import jakarta.servlet.FilterChain; import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest; import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority; import org.springframework.security.core.context.SecurityContextHolder;
import java.io.IOException; import java.util.List;
@Configuration @EnableWebSecurity @EnableMethodSecurity @RequiredArgsConstructor
public class SecurityConfig {
    private final JwtUtil jwtUtil;
    @Bean public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**", "/actuator/**", "/error").permitAll()
                .requestMatchers(HttpMethod.GET, "/reports/dashboard").hasAnyRole("ADMIN", "PROGRAM_MANAGER", "GOVERNMENT_AUDITOR")
                .requestMatchers("/reports/**").hasAnyRole("ADMIN", "PROGRAM_MANAGER", "COMPLIANCE_OFFICER", "GOVERNMENT_AUDITOR")
                .anyRequest().authenticated())
            .addFilterBefore(jwtAuthFilter(), UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
    @Bean public OncePerRequestFilter jwtAuthFilter() {
        return new OncePerRequestFilter() {
            @Override protected void doFilterInternal(HttpServletRequest rq, HttpServletResponse rs, FilterChain c) throws ServletException, IOException {
                String h = rq.getHeader(HttpHeaders.AUTHORIZATION);
                if (h != null && h.startsWith("Bearer ")) {
                    String t = h.substring(7);
                    if (jwtUtil.validateToken(t)) {
                        String role = rq.getHeader("X-User-Role"); if (role == null) role = "STUDENT";
                        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(jwtUtil.extractUsername(t), null, List.of(new SimpleGrantedAuthority("ROLE_" + role))));
                    }
                }
                c.doFilter(rq, rs);
            }
        };
    }
}
