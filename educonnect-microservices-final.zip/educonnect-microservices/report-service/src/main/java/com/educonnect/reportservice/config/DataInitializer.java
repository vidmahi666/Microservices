package com.educonnect.reportservice.config;

import com.educonnect.reportservice.entity.Report;
import com.educonnect.reportservice.repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final ReportRepository reportRepository;

    @Override
    public void run(String... args) {
        if (reportRepository.count() == 0) {
            reportRepository.save(Report.builder()
                    .scope(Report.ReportScope.DASHBOARD)
                    .metrics("{\"totalStudents\":1,\"totalCourses\":3,\"generatedAt\":\"startup\"}")
                    .generatedBy("system").build());
            log.info("Seeded 1 initial dashboard report");
        }
    }
}
