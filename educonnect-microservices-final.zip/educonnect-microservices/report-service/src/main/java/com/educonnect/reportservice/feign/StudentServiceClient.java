package com.educonnect.reportservice.feign;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;
import java.util.Map;
@FeignClient(name = "student-service", fallback = StudentServiceClientFallback.class)
public interface StudentServiceClient {
    @GetMapping("/api/students") List<Map<String,Object>> getAllStudents();
}
