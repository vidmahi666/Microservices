package com.educonnect.contentservice.config;

import com.educonnect.contentservice.entity.Content;
import com.educonnect.contentservice.repository.ContentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final ContentRepository contentRepository;

    @Override
    public void run(String... args) {
        if (contentRepository.count() == 0) {
            contentRepository.save(Content.builder()
                    .courseId(1L).title("Java Intro Lecture").type(Content.ContentType.VIDEO)
                    .fileUri("https://cdn.educonnect.com/courses/1/lecture1.mp4")
                    .description("Introduction to Java programming").sortOrder(1)
                    .status(Content.ContentStatus.ACTIVE).build());
            contentRepository.save(Content.builder()
                    .courseId(1L).title("Java Cheat Sheet").type(Content.ContentType.PDF)
                    .fileUri("https://cdn.educonnect.com/courses/1/cheatsheet.pdf")
                    .description("Quick reference for Java syntax").sortOrder(2)
                    .status(Content.ContentStatus.ACTIVE).build());
            log.info("Seeded 2 content items");
        }
    }
}
