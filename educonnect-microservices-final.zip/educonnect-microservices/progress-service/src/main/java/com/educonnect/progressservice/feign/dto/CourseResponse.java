package com.educonnect.progressservice.feign.dto;
import lombok.Data;
@Data public class CourseResponse { private Long courseId; private String title; private String status; }
