package com.educonnect.progressservice.config;

import com.educonnect.progressservice.entity.Progress;
import com.educonnect.progressservice.repository.ProgressRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final ProgressRepository progressRepository;

    @Override
    public void run(String... args) {
        if (progressRepository.count() == 0) {
            progressRepository.save(Progress.builder()
                    .studentId(1L).courseId(1L)
                    .studentName("Student One").courseTitle("Introduction to Java")
                    .completionPercentage(25.0).metricsJson("{\"lecturesWatched\":2,\"assignmentsDone\":0}")
                    .status(Progress.ProgressStatus.IN_PROGRESS).build());
            progressRepository.save(Progress.builder()
                    .studentId(1L).courseId(2L)
                    .studentName("Student One").courseTitle("Spring Boot Microservices")
                    .completionPercentage(0.0).metricsJson("{\"lecturesWatched\":0,\"assignmentsDone\":0}")
                    .status(Progress.ProgressStatus.IN_PROGRESS).build());
            log.info("Seeded 2 progress records");
        }
    }
}
