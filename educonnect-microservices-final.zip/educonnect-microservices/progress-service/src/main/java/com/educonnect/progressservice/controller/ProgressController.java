package com.educonnect.progressservice.controller;

import com.educonnect.progressservice.dto.ApiResponse;
import com.educonnect.progressservice.dto.ProgressResponse;
import com.educonnect.progressservice.dto.ProgressUpdateRequest;
import com.educonnect.progressservice.service.ProgressService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/progress") @RequiredArgsConstructor
@Tag(name = "Progress", description = "Student learning progress tracking")
public class ProgressController {
    private final ProgressService progressService;

    @PostMapping("/init") @Operation(summary = "Initialise progress record for a student-course pair")
    public ResponseEntity<ApiResponse<ProgressResponse>> initProgress(
            @RequestParam Long studentId, @RequestParam Long courseId,
            @RequestParam(required = false) String studentName, @RequestParam(required = false) String courseTitle) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Progress initialised", progressService.initProgress(studentId, courseId, studentName, courseTitle)));
    }

    @PutMapping("/student/{studentId}/course/{courseId}") @Operation(summary = "Update student progress for a course")
    public ResponseEntity<ApiResponse<ProgressResponse>> updateProgress(
            @PathVariable Long studentId, @PathVariable Long courseId,
            @RequestBody ProgressUpdateRequest req) {
        return ResponseEntity.ok(ApiResponse.ok("Progress updated", progressService.updateProgress(studentId, courseId, req)));
    }

    @GetMapping("/student/{studentId}/course/{courseId}") @Operation(summary = "Get progress for student-course pair")
    public ResponseEntity<ApiResponse<ProgressResponse>> getByStudentAndCourse(
            @PathVariable Long studentId, @PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.ok("Progress", progressService.getByStudentAndCourse(studentId, courseId)));
    }

    @GetMapping("/student/{studentId}") @Operation(summary = "Get all progress records for a student")
    public ResponseEntity<ApiResponse<List<ProgressResponse>>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.ok("Progress records", progressService.getByStudent(studentId)));
    }

    @GetMapping("/course/{courseId}") @Operation(summary = "Get all progress records for a course")
    public ResponseEntity<ApiResponse<List<ProgressResponse>>> getByCourse(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.ok("Progress records", progressService.getByCourse(courseId)));
    }

    @GetMapping("/completed") @Operation(summary = "Get all completed progress records")
    public ResponseEntity<ApiResponse<List<ProgressResponse>>> getCompleted() {
        return ResponseEntity.ok(ApiResponse.ok("Completed progress", progressService.getCompletedProgress()));
    }
}
