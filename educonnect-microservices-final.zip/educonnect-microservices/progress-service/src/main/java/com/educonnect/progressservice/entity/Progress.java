package com.educonnect.progressservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity
@Table(name = "progress", uniqueConstraints = @UniqueConstraint(columnNames = {"student_id","course_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class Progress {
    public enum ProgressStatus { IN_PROGRESS, COMPLETED, DROPPED }
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long progressId;
    @Column(name = "student_id", nullable = false) private Long studentId;
    @Column(name = "course_id",  nullable = false) private Long courseId;
    private String studentName;
    private String courseTitle;
    @Column(columnDefinition = "TEXT") private String metricsJson;
    private Double completionPercentage;
    @Enumerated(EnumType.STRING) @Builder.Default private ProgressStatus status = ProgressStatus.IN_PROGRESS;
    @CreatedDate @Column(name = "created_at", nullable = false, updatable = false) private LocalDateTime createdAt;
    @LastModifiedDate @Column(name = "updated_at") private LocalDateTime updatedAt;
}
