package com.educonnect.userservice.dto;
import com.educonnect.userservice.entity.User;
import lombok.Data;
@Data
public class UpdateUserRequest {
    private String name;
    private String phone;
    private User.Status status;
}
