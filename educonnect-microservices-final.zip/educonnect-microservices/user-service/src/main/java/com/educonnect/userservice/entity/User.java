package com.educonnect.userservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Entity @Table(name = "users", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EntityListeners(AuditingEntityListener.class)
public class User {
    public enum Role { STUDENT, TEACHER, PROGRAM_MANAGER, ADMIN, COMPLIANCE_OFFICER, GOVERNMENT_AUDITOR }
    public enum Status { ACTIVE, INACTIVE }
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long userId;
    @Column(nullable = false) private String name;
    @Column(nullable = false, unique = true) private String email;
    private String phone;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private Role role;
    @Enumerated(EnumType.STRING) @Column(nullable = false) @Builder.Default private Status status = Status.ACTIVE;
    @CreatedDate @Column(name = "created_at", nullable = false, updatable = false) private LocalDateTime createdAt;
    @LastModifiedDate @Column(name = "updated_at") private LocalDateTime updatedAt;
}
