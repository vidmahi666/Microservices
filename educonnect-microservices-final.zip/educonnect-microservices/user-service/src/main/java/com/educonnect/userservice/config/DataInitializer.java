package com.educonnect.userservice.config;

import com.educonnect.userservice.entity.User;
import com.educonnect.userservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final UserRepository userRepository;

    @Override
    public void run(String... args) {
        // Mirror user reference data from auth-service (userId, email, role only - no password)
        if (userRepository.count() == 0) {
            userRepository.save(User.builder().userId(1L).name("Admin User").email("admin@educonnect.com").role(User.Role.ADMIN).status(User.Status.ACTIVE).build());
            userRepository.save(User.builder().userId(2L).name("Teacher One").email("teacher@educonnect.com").role(User.Role.TEACHER).status(User.Status.ACTIVE).build());
            userRepository.save(User.builder().userId(3L).name("Student One").email("student@educonnect.com").role(User.Role.STUDENT).status(User.Status.ACTIVE).build());
            userRepository.save(User.builder().userId(4L).name("Program Manager").email("pm@educonnect.com").role(User.Role.PROGRAM_MANAGER).status(User.Status.ACTIVE).build());
            userRepository.save(User.builder().userId(5L).name("Compliance Officer").email("compliance@educonnect.com").role(User.Role.COMPLIANCE_OFFICER).status(User.Status.ACTIVE).build());
            userRepository.save(User.builder().userId(6L).name("Gov Auditor").email("auditor@educonnect.com").role(User.Role.GOVERNMENT_AUDITOR).status(User.Status.ACTIVE).build());
            log.info("Seeded 6 user records");
        }
    }
}
