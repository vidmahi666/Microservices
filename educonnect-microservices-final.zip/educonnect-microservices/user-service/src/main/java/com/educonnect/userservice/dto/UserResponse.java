package com.educonnect.userservice.dto;
import com.educonnect.userservice.entity.User;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @AllArgsConstructor @NoArgsConstructor
public class UserResponse {
    private Long userId;
    private String name;
    private String email;
    private String phone;
    private User.Role role;
    private User.Status status;
    private LocalDateTime createdAt;
}
