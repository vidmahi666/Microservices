package com.educonnect.notificationservice.config;

import com.educonnect.notificationservice.entity.Notification;
import com.educonnect.notificationservice.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final NotificationRepository notificationRepository;

    @Override
    public void run(String... args) {
        if (notificationRepository.count() == 0) {
            notificationRepository.save(Notification.builder()
                    .userId(3L).entityId(1L)
                    .message("Welcome to EduConnect! You are enrolled in Introduction to Java.")
                    .category(Notification.NotificationCategory.COURSE)
                    .status(Notification.NotificationStatus.UNREAD).build());
            notificationRepository.save(Notification.builder()
                    .userId(3L).entityId(1L)
                    .message("New assessment 'Java Basics Quiz' is now available. Due in 2 weeks.")
                    .category(Notification.NotificationCategory.ASSESSMENT)
                    .status(Notification.NotificationStatus.UNREAD).build());
            log.info("Seeded 2 notifications");
        }
    }
}
