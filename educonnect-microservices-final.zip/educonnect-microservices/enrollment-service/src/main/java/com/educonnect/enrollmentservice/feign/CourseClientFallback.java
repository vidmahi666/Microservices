package com.educonnect.enrollmentservice.feign;
import com.educonnect.enrollmentservice.feign.dto.CourseResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
@Slf4j @Component
public class CourseClientFallback implements CourseClient {
    @Override public CourseResponse getCourseById(Long courseId) {
        log.warn("course-service unavailable for courseId={}", courseId); return null;
    }
}
