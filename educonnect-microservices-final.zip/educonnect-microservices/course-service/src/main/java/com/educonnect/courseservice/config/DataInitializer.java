package com.educonnect.courseservice.config;

import com.educonnect.courseservice.entity.Course;
import com.educonnect.courseservice.repository.CourseRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

@Slf4j @Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final CourseRepository courseRepository;

    @Override
    public void run(String... args) {
        if (courseRepository.count() == 0) {
            courseRepository.save(Course.builder()
                    .title("Introduction to Java").description("Core Java fundamentals for beginners")
                    .teacherUserId(2L) // teacher@educonnect.com
                    .startDate(LocalDate.now()).endDate(LocalDate.now().plusMonths(3))
                    .status(Course.CourseStatus.ACTIVE).build());
            courseRepository.save(Course.builder()
                    .title("Spring Boot Microservices").description("Build production-grade microservices with Spring Boot")
                    .teacherUserId(2L)
                    .startDate(LocalDate.now()).endDate(LocalDate.now().plusMonths(4))
                    .status(Course.CourseStatus.ACTIVE).build());
            courseRepository.save(Course.builder()
                    .title("Database Design").description("Relational database design and MySQL")
                    .teacherUserId(2L)
                    .startDate(LocalDate.now().plusWeeks(2)).endDate(LocalDate.now().plusMonths(3))
                    .status(Course.CourseStatus.DRAFT).build());
            log.info("Seeded 3 courses");
        }
    }
}
