import { Routes } from '@angular/router';
import { authGuard, roleGuard, guestGuard } from './core/guards';
import { UserRole } from './core/models';

export const routes: Routes = [
  // Public
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./modules/auth/login/login.component').then(m => m.LoginComponent),
  },
  {
    path: 'register',
    canActivate: [guestGuard],
    loadComponent: () => import('./modules/auth/register/register.component').then(m => m.RegisterComponent),
  },

  // Student portal
  {
    path: 'student',
    canActivate: [authGuard, roleGuard(UserRole.STUDENT)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard',    loadComponent: () => import('./modules/student/dashboard/student-dashboard.component').then(m => m.StudentDashboardComponent) },
      { path: 'courses',      loadComponent: () => import('./modules/student/courses/student-courses.component').then(m => m.StudentCoursesComponent) },
      { path: 'assessments',  loadComponent: () => import('./modules/student/assessments/student-assessments.component').then(m => m.StudentAssessmentsComponent) },
      { path: 'progress',     loadComponent: () => import('./modules/student/progress/student-progress.component').then(m => m.StudentProgressComponent) },
      { path: 'profile',      loadComponent: () => import('./modules/student/profile/student-profile.component').then(m => m.StudentProfileComponent) },
    ],
  },

  // Teacher portal
  {
    path: 'teacher',
    canActivate: [authGuard, roleGuard(UserRole.TEACHER)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard',   loadComponent: () => import('./modules/teacher/dashboard/teacher-dashboard.component').then(m => m.TeacherDashboardComponent) },
      { path: 'courses',     loadComponent: () => import('./modules/teacher/courses/teacher-courses.component').then(m => m.TeacherCoursesComponent) },
      { path: 'content',     loadComponent: () => import('./modules/teacher/content/teacher-content.component').then(m => m.TeacherContentComponent) },
      { path: 'assessments', loadComponent: () => import('./modules/teacher/assessments/teacher-assessments.component').then(m => m.TeacherAssessmentsComponent) },
      { path: 'students',    loadComponent: () => import('./modules/teacher/students/teacher-students.component').then(m => m.TeacherStudentsComponent) },
    ],
  },

  // Admin / Staff portal
  {
    path: 'admin',
    canActivate: [authGuard, roleGuard(UserRole.ADMIN, UserRole.PROGRAM_MANAGER, UserRole.COMPLIANCE_OFFICER, UserRole.GOVERNMENT_AUDITOR)],
    loadComponent: () => import('./shared/components/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard',  loadComponent: () => import('./modules/admin/dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent) },
      { path: 'users',      canActivate: [roleGuard(UserRole.ADMIN)], loadComponent: () => import('./modules/admin/users/admin-users.component').then(m => m.AdminUsersComponent) },
      { path: 'courses',    loadComponent: () => import('./modules/admin/courses/admin-courses.component').then(m => m.AdminCoursesComponent) },
      { path: 'compliance', canActivate: [roleGuard(UserRole.ADMIN, UserRole.COMPLIANCE_OFFICER)], loadComponent: () => import('./modules/admin/compliance/admin-compliance.component').then(m => m.AdminComplianceComponent) },
      { path: 'audits',     canActivate: [roleGuard(UserRole.ADMIN, UserRole.COMPLIANCE_OFFICER, UserRole.GOVERNMENT_AUDITOR)], loadComponent: () => import('./modules/admin/audits/admin-audits.component').then(m => m.AdminAuditsComponent) },
      { path: 'reports',    loadComponent: () => import('./modules/admin/reports/admin-reports.component').then(m => m.AdminReportsComponent) },
    ],
  },

  // Utility pages
  {
    path: 'unauthorized',
    loadComponent: () => import('./shared/components/error-pages/unauthorized.component').then(m => m.UnauthorizedComponent),
  },
  { path: '**', redirectTo: '/login' },
];
