import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ContentService, CourseService, ToastService } from '../../../core/services/index';
import { Content, Course, ContentType, ContentStatus } from '../../../core/models';

@Component({
  selector: 'app-teacher-content',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Learning Materials</span>
          <h1 class="page-title">Course Content</h1>
          <p class="page-desc">Manage videos, PDFs and documents for your students</p>
        </div>
        <button class="btn btn-primary" (click)="openUpload()">
          <i class="bi bi-cloud-arrow-up-fill"></i> Upload Content
        </button>
      </header>

      <!-- Course filter -->
      <div class="filter-bar">
        <div class="select-wrap">
          <i class="bi bi-book"></i>
          <select [(ngModel)]="selectedCourseId" (ngModelChange)="onCourseFilter($event)" class="styled-select">
            <option [ngValue]="null">All Courses</option>
            @for (c of myCourses(); track c.courseId) {
              <option [ngValue]="c.courseId">{{ c.title }}</option>
            }
          </select>
        </div>
        <div class="select-wrap">
          <i class="bi bi-funnel"></i>
          <select [(ngModel)]="typeFilter" class="styled-select">
            <option value="">All Types</option>
            @for (t of contentTypes; track t) {
              <option [value]="t">{{ t }}</option>
            }
          </select>
        </div>
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      } @else if (filtered().length === 0) {
        <div class="empty-state">
          <i class="bi bi-collection-play"></i>
          <h3>No content yet</h3>
          <p>Upload your first video, PDF or document to get started.</p>
          <button class="btn btn-primary mt-2" (click)="openUpload()">
            <i class="bi bi-cloud-arrow-up-fill"></i> Upload Content
          </button>
        </div>
      } @else {
        <div class="content-grid">
          @for (c of filtered(); track c.contentId) {
            <div class="content-card" [attr.data-type]="c.type.toLowerCase()">
              <div class="cc-thumb">
                <i class="bi" [ngClass]="typeIcon(c.type)"></i>
                <span class="type-tag">{{ c.type }}</span>
              </div>
              <div class="cc-body">
                <h4 class="cc-title">{{ c.title }}</h4>
                @if (c.description) {
                  <p class="cc-desc">{{ c.description | slice:0:80 }}{{ (c.description?.length ?? 0) > 80 ? '...' : '' }}</p>
                }
                <div class="cc-meta">
                  <span><i class="bi bi-calendar3"></i> {{ c.uploadedDate | date:'mediumDate' }}</span>
                  <span class="status-dot" [ngClass]="'dot-' + c.status.toLowerCase()">
                    <i class="bi bi-circle-fill"></i> {{ c.status }}
                  </span>
                </div>
                <div class="cc-actions">
                  <a [href]="c.fileUri" target="_blank" class="btn-link">
                    <i class="bi bi-box-arrow-up-right"></i> Open
                  </a>
                  @if (c.status === 'ACTIVE') {
                    <button class="btn-archive" (click)="archive(c)">
                      <i class="bi bi-archive"></i> Archive
                    </button>
                  }
                </div>
              </div>
            </div>
          }
        </div>
      }

      <!-- Upload Modal -->
      @if (showModal()) {
        <div class="modal-backdrop" (click)="closeModal()">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <div>
                <h3 class="modal-title">Upload Content</h3>
                <p class="modal-sub">Add a new learning resource for your students</p>
              </div>
              <button class="modal-close" (click)="closeModal()"><i class="bi bi-x"></i></button>
            </div>
            @if (formError()) {
              <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ formError() }}</div>
            }
            <form [formGroup]="form" (ngSubmit)="doUpload()">
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">Course *</label>
                  <select formControlName="courseId" class="form-select">
                    <option value="">Select course</option>
                    @for (c of myCourses(); track c.courseId) {
                      <option [value]="c.courseId">{{ c.title }}</option>
                    }
                  </select>
                  @if (isInvalid('courseId')) { <span class="err">Course is required</span> }
                </div>
                <div class="form-group">
                  <label class="form-label">Content Type *</label>
                  <select formControlName="type" class="form-select">
                    <option value="">Select type</option>
                    @for (t of contentTypes; track t) {
                      <option [value]="t">{{ t }}</option>
                    }
                  </select>
                  @if (isInvalid('type')) { <span class="err">Type is required</span> }
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Title *</label>
                <input formControlName="title" type="text" class="form-control"
                  placeholder="e.g. Introduction to Variables" />
                @if (isInvalid('title')) { <span class="err">Title is required</span> }
              </div>
              <div class="form-group">
                <label class="form-label">File URL *</label>
                <div class="input-wrap">
                  <i class="bi bi-link-45deg input-icon"></i>
                  <input formControlName="fileUri" type="url" class="form-control has-icon"
                    placeholder="https://drive.google.com/file/..." />
                </div>
                @if (isInvalid('fileUri')) { <span class="err">Valid URL required</span> }
              </div>
              <div class="form-group">
                <label class="form-label">Description</label>
                <textarea formControlName="description" class="form-control" rows="2"
                  placeholder="Brief description of this content..."></textarea>
              </div>
              <div class="form-group">
                <label class="form-label">Sort Order</label>
                <input formControlName="sortOrder" type="number" class="form-control" placeholder="1" />
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="saving() || form.invalid">
                  @if (saving()) { <span class="spinner"></span> Uploading... }
                  @else { <i class="bi bi-cloud-arrow-up-fill"></i> Upload }
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .page-head { display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap; }
    .eyebrow { display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }

    .filter-bar { display:flex;gap:0.75rem;flex-wrap:wrap; }
    .select-wrap { position:relative; i{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:0.9rem;pointer-events:none;} }
    .styled-select { padding:0.65rem 2rem 0.65rem 2.3rem;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.88rem;font-family:inherit;outline:none;cursor:pointer;min-width:200px;appearance:none;transition:border-color 0.2s;&:focus{border-color:var(--accent);} option{background:#1A2F5E;} }

    .content-grid { display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.25rem; }
    .content-card { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;overflow:hidden;transition:all 0.25s;&:hover{transform:translateY(-4px);border-color:rgba(46,123,246,0.3);box-shadow:0 16px 40px rgba(0,0,0,0.3);} }
    .cc-thumb { height:100px;display:flex;align-items:center;justify-content:center;font-size:2.5rem;position:relative; }
    .content-card[data-type="video"]        .cc-thumb { background:linear-gradient(135deg,rgba(251,113,133,0.25),rgba(251,113,133,0.08));color:var(--rose); }
    .content-card[data-type="pdf"]          .cc-thumb { background:linear-gradient(135deg,rgba(239,68,68,0.25),rgba(239,68,68,0.08));color:#FCA5A5; }
    .content-card[data-type="quiz"]         .cc-thumb { background:linear-gradient(135deg,rgba(46,123,246,0.25),rgba(46,123,246,0.08));color:var(--accent-light); }
    .content-card[data-type="document"]     .cc-thumb { background:linear-gradient(135deg,rgba(0,201,167,0.25),rgba(0,201,167,0.08));color:var(--mint); }
    .content-card[data-type="presentation"] .cc-thumb { background:linear-gradient(135deg,rgba(167,139,250,0.25),rgba(167,139,250,0.08));color:var(--purple); }
    .type-tag { position:absolute;top:10px;right:10px;padding:3px 8px;background:rgba(0,0,0,0.4);border-radius:100px;font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;color:#fff;backdrop-filter:blur(4px); }
    .cc-body { padding:1.25rem;display:flex;flex-direction:column;gap:0.6rem; }
    .cc-title { font-size:0.975rem;font-weight:700;color:#fff;margin:0;line-height:1.35; }
    .cc-desc  { font-size:0.82rem;color:var(--text-muted);line-height:1.5;margin:0; }
    .cc-meta  { display:flex;justify-content:space-between;align-items:center;font-size:0.75rem;color:var(--text-muted); span{display:inline-flex;align-items:center;gap:4px;} }
    .status-dot { &.dot-active{color:var(--mint);} &.dot-archived{color:var(--text-muted);} &.dot-inactive{color:#FCA5A5;} i{font-size:0.4rem;} }
    .cc-actions { display:flex;justify-content:space-between;align-items:center;margin-top:0.25rem; }
    .btn-link    { display:inline-flex;align-items:center;gap:5px;color:var(--accent-light);font-size:0.82rem;font-weight:600;text-decoration:none;transition:color 0.2s;&:hover{color:#fff;} }
    .btn-archive { background:none;border:none;color:var(--text-muted);font-size:0.82rem;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:5px;font-family:inherit;transition:color 0.2s;&:hover{color:#FCA5A5;} }

    /* Modal */
    .modal-backdrop { position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease; }
    .modal { background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:580px;max-height:90vh;overflow-y:auto;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease; }
    .modal-header { display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.5rem; }
    .modal-title { font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;margin:0; }
    .modal-sub   { font-size:0.85rem;color:var(--text-muted);margin-top:4px; }
    .modal-close { width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--text-muted);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;} }
    .alert-error { display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1.25rem; }
    .form-row { display:grid;grid-template-columns:1fr 1fr;gap:1rem; }
    .form-group { margin-bottom:1rem; }
    .form-label { display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em; }
    .input-wrap { position:relative; .input-icon{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);pointer-events:none;font-size:1rem;} }
    .form-control { width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);}&.has-icon{padding-left:2.4rem;} }
    .form-select { @extend .form-control;cursor:pointer;appearance:none;option{background:#1A2F5E;} }
    textarea.form-control { min-height:72px;resize:vertical; }
    .err { font-size:0.75rem;color:#FCA5A5;margin-top:4px;display:block; }
    .modal-footer { display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem; }
    .btn { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.25rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;white-space:nowrap;&:disabled{opacity:0.55;cursor:not-allowed;} }
    .btn-primary { background:linear-gradient(135deg,var(--accent),#1A5FD4);color:#fff;box-shadow:0 6px 18px rgba(46,123,246,0.3);&:hover:not(:disabled){transform:translateY(-2px);} }
    .btn-ghost   { background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);} }
    .mt-2 { margin-top:1rem; }
    .empty-state { padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px; i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;} h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;} p{font-size:0.875rem;color:var(--text-muted);} }
    .spinner { display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite; }
    .ec-spin { display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite; }
    .load-center { display:flex;justify-content:center;padding:4rem; }
    @media(max-width:640px) { .form-row{grid-template-columns:1fr;} .content-grid{grid-template-columns:1fr;} }
    @keyframes spin    { to{transform:rotate(360deg);} }
    @keyframes fadeIn  { from{opacity:0;} to{opacity:1;} }
    @keyframes slideUp { from{opacity:0;transform:translateY(24px);} to{opacity:1;transform:none;} }
  `],
})
export class TeacherContentComponent implements OnInit {
  private auth       = inject(AuthService);
  private contentSvc = inject(ContentService);
  private courseSvc  = inject(CourseService);
  private toast      = inject(ToastService);
  private fb         = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  showModal = signal(false);
  formError = signal('');
  myCourses = signal<Course[]>([]);
  allContent = signal<Content[]>([]);
  selectedCourseId: number | null = null;
  typeFilter = '';

  contentTypes: ContentType[] = ['VIDEO','PDF','QUIZ','DOCUMENT','PRESENTATION'];

  form = this.fb.nonNullable.group({
    courseId:    ['', Validators.required],
    title:       ['', Validators.required],
    type:        ['', Validators.required],
    fileUri:     ['', [Validators.required, Validators.pattern(/^https?:\/\/.+/)]],
    description: [''],
    sortOrder:   [1],
  });

  isInvalid(f: string): boolean {
    const c = this.form.get(f);
    return !!(c?.invalid && c?.touched);
  }

  typeIcon(t: ContentType): string {
    const m: Record<ContentType,string> = {
      VIDEO:'bi-play-circle-fill', PDF:'bi-file-earmark-pdf-fill',
      QUIZ:'bi-question-circle-fill', DOCUMENT:'bi-file-earmark-text-fill',
      PRESENTATION:'bi-easel-fill',
    };
    return m[t] ?? 'bi-file-fill';
  }

  filtered = computed(() => {
    let list = this.allContent();
    if (this.selectedCourseId) list = list.filter(c => c.courseId === this.selectedCourseId);
    if (this.typeFilter) list = list.filter(c => c.type === this.typeFilter);
    return list;
  });

  onCourseFilter(id: number | null): void { this.selectedCourseId = id; }

  ngOnInit(): void {
    const tid = this.auth.userId() ?? 1;
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const mine = (r.data ?? []).filter(c => c.teacherUserId === tid);
          this.myCourses.set(mine);
          this.loadContent(mine.map(c => c.courseId));
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false),
    });
  }

  loadContent(courseIds: number[]): void {
    if (!courseIds.length) { this.loading.set(false); return; }
    const all: Content[] = [];
    let pending = courseIds.length;
    courseIds.forEach(id => {
      this.contentSvc.getByCourse(id).subscribe({
        next: r => {
          if (r.success) all.push(...(r.data ?? []));
          if (--pending === 0) { this.allContent.set(all); this.loading.set(false); }
        },
        error: () => { if (--pending === 0) this.loading.set(false); },
      });
    });
  }

  openUpload(): void { this.form.reset({ sortOrder: 1 }); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doUpload(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const v = this.form.getRawValue();
    this.contentSvc.create({ ...v, courseId: +v.courseId } as any).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.allContent.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Uploaded!', `"${r.data.title}" added successfully.`);
        } else { this.formError.set(r.message ?? 'Upload failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Upload failed'); },
    });
  }

  archive(c: Content): void {
    this.contentSvc.updateStatus(c.contentId, ContentStatus.ARCHIVED).subscribe({
      next: r => {
        if (r.success) {
          this.allContent.update(arr => arr.map(x => x.contentId === c.contentId ? { ...x, status: ContentStatus.ARCHIVED } : x));
          this.toast.info('Archived', `"${c.title}" has been archived.`);
        }
      },
    });
  }
}
