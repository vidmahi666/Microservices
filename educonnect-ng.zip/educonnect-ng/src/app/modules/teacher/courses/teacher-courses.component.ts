import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, ToastService } from '../../../core/services/index';
import { Course } from '../../../core/models';

@Component({
  selector: 'app-teacher-courses',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Catalog</span>
          <h1 class="page-title">My Courses</h1>
          <p class="page-desc">{{ courses().length }} course(s) in your catalog</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">
          <i class="bi bi-plus-lg"></i> New Course
        </button>
      </header>

      @if (loading()) {
        <div class="loading-box"><span class="spinner spinner-lg"></span></div>
      } @else if (courses().length === 0) {
        <div class="empty-box">
          <i class="bi bi-book"></i>
          <h3>No courses yet</h3>
          <p>Create your first course to start teaching.</p>
          <button class="btn btn-primary" (click)="openCreate()">Create Course</button>
        </div>
      } @else {
        <div class="table-wrap">
          <table class="ec-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              @for (c of courses(); track c.courseId) {
                <tr>
                  <td><strong>{{ c.title }}</strong></td>
                  <td style="max-width:200px;font-size:0.82rem;color:#8898B3">{{ c.description | slice:0:60 }}...</td>
                  <td>{{ c.startDate | date:'mediumDate' }}</td>
                  <td>{{ c.endDate | date:'mediumDate' }}</td>
                  <td><span class="sb sb-{{ c.status.toLowerCase() }}">{{ c.status }}</span></td>
                  <td>
                    <button class="icon-action" (click)="openEdit(c)" title="Edit"><i class="bi bi-pencil"></i></button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }

      <!-- Modal -->
      @if (showModal()) {
        <div class="modal-backdrop" (click)="closeModal()">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <h3>{{ editingId() ? 'Edit Course' : 'Create Course' }}</h3>
              <button class="modal-close" (click)="closeModal()"><i class="bi bi-x"></i></button>
            </div>
            <form [formGroup]="form" (ngSubmit)="save()">
              <div class="form-group">
                <label class="form-label">Title *</label>
                <input formControlName="title" type="text" class="form-control"
                  placeholder="Course title" [class.is-invalid]="ii('title')" />
                @if (ii('title')) { <span class="invalid-feedback">Title required</span> }
              </div>
              <div class="form-group">
                <label class="form-label">Description</label>
                <textarea formControlName="description" class="form-control" rows="3" placeholder="Course description..."></textarea>
              </div>
              <div class="two-col">
                <div class="form-group">
                  <label class="form-label">Start Date *</label>
                  <input formControlName="startDate" type="date" class="form-control" [class.is-invalid]="ii('startDate')" />
                  @if (ii('startDate')) { <span class="invalid-feedback">Required</span> }
                </div>
                <div class="form-group">
                  <label class="form-label">End Date *</label>
                  <input formControlName="endDate" type="date" class="form-control" [class.is-invalid]="ii('endDate')" />
                  @if (ii('endDate')) { <span class="invalid-feedback">Required</span> }
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="spinner"></span> }
                  {{ editingId() ? 'Update' : 'Create' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host { display:block;font-family:'Plus Jakarta Sans',sans-serif; --accent:#2E7BF6;--gold:#F0A500;--mint:#00C9A7;--text-muted:#8898B3;--border:rgba(255,255,255,0.08); }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .page-head { display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:1rem; }
    .eyebrow { display:inline-block;font-size:0.72rem;font-weight:700;color:#4F95FF;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }
    .btn { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.2rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.25s;&:disabled{opacity:0.55;cursor:not-allowed;} }
    .btn-primary { background:linear-gradient(135deg,var(--accent),#1A5FD4);color:#fff;box-shadow:0 8px 22px rgba(46,123,246,0.28);&:hover:not(:disabled){transform:translateY(-2px);} }
    .btn-ghost   { background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);} }
    .table-wrap { overflow-x:auto;border-radius:16px;border:1px solid var(--border); }
    .ec-table { width:100%;border-collapse:collapse;thead tr{background:rgba(255,255,255,0.03);th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);}}tbody tr{border-bottom:1px solid rgba(255,255,255,0.03);transition:background 0.2s;&:hover{background:rgba(255,255,255,0.02);}&:last-child{border-bottom:none;}td{padding:0.85rem 1rem;font-size:0.875rem;vertical-align:middle;}} }
    .sb { font-size:0.68rem;font-weight:700;text-transform:uppercase;padding:3px 9px;border-radius:100px;letter-spacing:0.04em; }
    .sb-active    { background:rgba(16,185,129,0.15);color:#34D399; }
    .sb-draft     { background:rgba(245,158,11,0.15);color:#FCD34D; }
    .sb-completed { background:rgba(46,123,246,0.15);color:#4F95FF; }
    .sb-archived  { background:rgba(148,163,184,0.1);color:#94A3B8; }
    .icon-action { width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:8px;background:rgba(46,123,246,0.1);border:1px solid rgba(46,123,246,0.2);color:#4F95FF;cursor:pointer;transition:all 0.2s;font-size:0.85rem;&:hover{background:rgba(46,123,246,0.2);transform:scale(1.05);} }
    .modal-backdrop { position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s; }
    .modal { background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:540px;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease; }
    .modal-header { display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;h3{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;} }
    .modal-close { width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:#8898B3;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;} }
    .modal-footer { display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem; }
    .two-col { display:grid;grid-template-columns:1fr 1fr;gap:0.75rem 1rem; }
    .form-group { margin-bottom:0.9rem; }
    .form-label { display:block;font-size:0.78rem;font-weight:600;color:#8898B3;margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em; }
    .form-control { width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:all 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:#2E7BF6;}&.is-invalid{border-color:rgba(239,68,68,0.5);}resize:vertical;min-height:80px; }
    .invalid-feedback { font-size:0.75rem;color:#FCA5A5;margin-top:4px;display:block; }
    .empty-box { padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;display:flex;flex-direction:column;align-items:center;gap:0.5rem;i{font-size:2.5rem;color:var(--text-muted);}h3{font-family:'Fraunces',serif;font-size:1.25rem;color:#fff;}p{font-size:0.875rem;color:var(--text-muted);margin-bottom:0.5rem;} }
    .loading-box { display:flex;justify-content:center;padding:4rem; }
    .spinner { display:inline-block;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;width:18px;height:18px; }
    .spinner-lg { width:40px;height:40px;border-width:3px; }
    @keyframes spin{to{transform:rotate(360deg)}}
    @keyframes fadeIn{from{opacity:0}to{opacity:1}}
    @keyframes slideUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
  `],
})
export class TeacherCoursesComponent implements OnInit {
  private auth      = inject(AuthService);
  private courseSvc = inject(CourseService);
  private toast     = inject(ToastService);
  private fb        = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  courses   = signal<Course[]>([]);
  showModal = signal(false);
  editingId = signal<number | null>(null);

  form = this.fb.nonNullable.group({
    title:       ['', Validators.required],
    description: [''],
    startDate:   ['', Validators.required],
    endDate:     ['', Validators.required],
  });

  ii(f: string): boolean { const c = this.form.get(f); return !!(c?.invalid && c?.touched); }

  ngOnInit(): void { this.load(); }

  load(): void {
    const uid = this.auth.userId();
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) this.courses.set((r.data ?? []).filter(c => c.teacherUserId === uid));
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  openCreate(): void { this.editingId.set(null); this.form.reset(); this.showModal.set(true); }

  openEdit(c: Course): void {
    this.editingId.set(c.courseId);
    this.form.patchValue({ title: c.title, description: c.description, startDate: c.startDate, endDate: c.endDate });
    this.showModal.set(true);
  }

  closeModal(): void { this.showModal.set(false); }

  save(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const payload = { ...this.form.getRawValue(), teacherUserId: this.auth.userId()! };
    const call = this.editingId()
      ? this.courseSvc.update(this.editingId()!, payload)
      : this.courseSvc.create(payload);

    call.subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.toast.success(this.editingId() ? 'Course updated!' : 'Course created!');
          this.closeModal(); this.load();
        } else {
          this.toast.error('Failed', r.message);
        }
      },
      error: err => { this.saving.set(false); this.toast.error('Error', err?.error?.message); },
    });
  }
}
