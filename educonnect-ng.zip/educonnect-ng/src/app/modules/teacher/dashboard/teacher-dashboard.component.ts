import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService, AssessmentService, ToastService } from '../../../core/services/index';
import { Course, Enrollment, Assessment, Submission } from '../../../core/models';

@Component({
  selector: 'app-teacher-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page">
      <!-- Welcome -->
      <section class="welcome-card">
        <div class="wc-bg"></div>
        <div class="wc-inner">
          <div>
            <span class="chip"><span class="dot"></span> Instructor Portal</span>
            <h1 class="wt">Hello, {{ firstName() }} <span class="wave">👨‍🏫</span></h1>
            <p class="wd">
              You have <strong>{{ pendingSubs().length }} submissions</strong> to grade this week.
              Managing <strong>{{ myCourses().length }} active courses</strong>.
            </p>
            <div class="wc-actions">
              <a routerLink="/teacher/courses" class="btn-primary">Create Course <i class="bi bi-plus-lg"></i></a>
              <a routerLink="/teacher/assessments" class="btn-ghost">
                <i class="bi bi-pencil-square"></i> Grade Submissions
              </a>
            </div>
          </div>
          <div class="wt-icon"><i class="bi bi-mortarboard-fill"></i></div>
        </div>
      </section>

      <!-- Stats -->
      <div class="stats-grid">
        @for (s of stats(); track s.label) {
          <div class="stat-card" [attr.data-tone]="s.tone">
            <div class="stat-icon"><i class="bi" [ngClass]="s.icon"></i></div>
            <div class="stat-body">
              <div class="stat-label">{{ s.label }}</div>
              <div class="stat-value">{{ s.value }}</div>
            </div>
          </div>
        }
      </div>

      <div class="two-col">
        <!-- My courses -->
        <div class="panel">
          <div class="panel-head">
            <div>
              <h2 class="panel-title">My Courses</h2>
              <p class="panel-sub">Your active course catalog</p>
            </div>
            <a routerLink="/teacher/courses" class="panel-link">View all <i class="bi bi-arrow-right"></i></a>
          </div>
          @if (myCourses().length === 0) {
            <div class="empty-inner"><i class="bi bi-book"></i> No courses yet. <a routerLink="/teacher/courses">Create one</a></div>
          } @else {
            @for (c of myCourses().slice(0,5); track c.courseId) {
              <div class="course-row">
                <div class="cr-dot" [attr.data-status]="c.status"></div>
                <div class="cr-info">
                  <div class="cr-title">{{ c.title }}</div>
                  <div class="cr-dates">{{ c.startDate | date:'medShortDate' }} → {{ c.endDate | date:'medShortDate' }}</div>
                </div>
                <span class="status-badge sb-{{ c.status.toLowerCase() }}">{{ c.status }}</span>
              </div>
            }
          }
        </div>

        <!-- Pending grading -->
        <div class="panel">
          <div class="panel-head">
            <div>
              <h2 class="panel-title">Pending Grading</h2>
              <p class="panel-sub">{{ pendingSubs().length }} submission(s) awaiting review</p>
            </div>
            <a routerLink="/teacher/assessments" class="panel-link">Grade all <i class="bi bi-arrow-right"></i></a>
          </div>
          @if (pendingSubs().length === 0) {
            <div class="empty-inner"><i class="bi bi-check2-all"></i> All submissions graded!</div>
          } @else {
            @for (s of pendingSubs().slice(0,5); track s.submissionId) {
              <div class="sub-row">
                <div class="sub-av">{{ s.studentId }}</div>
                <div class="sub-info">
                  <div class="sub-title">Student #{{ s.studentId }}</div>
                  <div class="sub-meta">Assessment #{{ s.assessmentId }} · {{ s.submittedAt | date:'mediumDate' }}</div>
                </div>
                <a routerLink="/teacher/assessments" class="grade-btn">Grade <i class="bi bi-arrow-right"></i></a>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host { display:block;font-family:'Plus Jakarta Sans',sans-serif; --accent:#2E7BF6;--mint:#00C9A7;--gold:#F0A500;--purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08); }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .welcome-card { position:relative;background:linear-gradient(135deg,rgba(240,165,0,0.15),rgba(46,123,246,0.1));border:1px solid rgba(240,165,0,0.25);border-radius:22px;padding:2rem;overflow:hidden; }
    .wc-bg { position:absolute;width:400px;height:400px;background:radial-gradient(circle,rgba(240,165,0,0.2),transparent 70%);filter:blur(60px);top:-100px;right:-80px;pointer-events:none; }
    .wc-inner { position:relative;display:flex;justify-content:space-between;align-items:center;gap:2rem; }
    .chip { display:inline-flex;align-items:center;gap:6px;padding:4px 12px;background:rgba(240,165,0,0.15);border:1px solid rgba(240,165,0,0.35);border-radius:100px;font-size:0.72rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.9rem;.dot{width:6px;height:6px;border-radius:50%;background:var(--gold);} }
    .wt { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;margin:0 0 0.5rem;letter-spacing:-0.02em;.wave{display:inline-block;} }
    .wd { color:var(--text-muted);font-size:0.95rem;line-height:1.6;strong{color:#fff;} }
    .wc-actions { display:flex;gap:0.75rem;margin-top:1.25rem;flex-wrap:wrap; }
    .btn-primary { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.2rem;background:linear-gradient(135deg,var(--gold),#B87A00);border:none;border-radius:10px;color:#1a1300;font-size:0.9rem;font-weight:700;text-decoration:none;transition:all 0.25s;&:hover{transform:translateY(-2px);color:#1a1300;} }
    .btn-ghost { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.1rem;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.9rem;font-weight:600;text-decoration:none;transition:all 0.2s;&:hover{background:rgba(255,255,255,0.1);color:#fff;} }
    .wt-icon { font-size:4rem;opacity:0.25;flex-shrink:0; }
    .stats-grid { display:grid;grid-template-columns:repeat(4,1fr);gap:1rem; }
    .stat-card { display:flex;align-items:center;gap:1rem;padding:1.25rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;transition:all 0.3s;&:hover{transform:translateY(-3px);} }
    .stat-icon { width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0; }
    .stat-label { font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em; }
    .stat-value { font-family:'Fraunces',serif;font-size:1.8rem;font-weight:800;color:#fff;line-height:1.1;letter-spacing:-0.02em; }
    .stat-card[data-tone="blue"]   .stat-icon { background:rgba(46,123,246,0.15);color:#4F95FF; }
    .stat-card[data-tone="mint"]   .stat-icon { background:rgba(0,201,167,0.15);color:var(--mint); }
    .stat-card[data-tone="gold"]   .stat-icon { background:rgba(240,165,0,0.15);color:var(--gold); }
    .stat-card[data-tone="rose"]   .stat-icon { background:rgba(251,113,133,0.15);color:var(--rose); }
    .two-col { display:grid;grid-template-columns:1fr 1fr;gap:1.25rem; }
    .panel { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.5rem;display:flex;flex-direction:column;gap:0.9rem; }
    .panel-head { display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;padding-bottom:0.5rem;border-bottom:1px solid var(--border);.panel-title{font-family:'Fraunces',serif;font-size:1.15rem;font-weight:700;color:#fff;margin:0;}.panel-sub{font-size:0.8rem;color:var(--text-muted);margin-top:3px;}.panel-link{color:#4F95FF;text-decoration:none;font-size:0.82rem;font-weight:600;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;&:hover{text-decoration:underline;}} }
    .course-row { display:flex;align-items:center;gap:0.875rem;padding:0.75rem;border-radius:10px;border:1px solid transparent;transition:all 0.2s;&:hover{background:rgba(255,255,255,0.03);border-color:var(--border);} }
    .cr-dot { width:10px;height:10px;border-radius:50%;flex-shrink:0; }
    .cr-dot[data-status="ACTIVE"]    { background:var(--mint); }
    .cr-dot[data-status="DRAFT"]     { background:var(--gold); }
    .cr-dot[data-status="COMPLETED"] { background:#4F95FF; }
    .cr-dot[data-status="ARCHIVED"]  { background:var(--text-muted); }
    .cr-info { flex:1;min-width:0; }
    .cr-title { font-size:0.9rem;font-weight:700;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }
    .cr-dates { font-size:0.75rem;color:var(--text-muted);margin-top:2px; }
    .status-badge { font-size:0.68rem;font-weight:700;text-transform:uppercase;padding:3px 9px;border-radius:100px;letter-spacing:0.04em;flex-shrink:0; }
    .sb-active    { background:rgba(16,185,129,0.15);color:#34D399; }
    .sb-draft     { background:rgba(245,158,11,0.15);color:#FCD34D; }
    .sb-completed { background:rgba(46,123,246,0.15);color:#4F95FF; }
    .sb-archived  { background:rgba(148,163,184,0.1);color:#94A3B8; }
    .sub-row { display:flex;align-items:center;gap:0.875rem;padding:0.75rem;border-radius:10px;border:1px solid var(--border);transition:all 0.2s;&:hover{background:rgba(255,255,255,0.03);} }
    .sub-av { width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,rgba(46,123,246,0.3),rgba(0,201,167,0.2));display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:700;color:#fff;flex-shrink:0; }
    .sub-info { flex:1;min-width:0; }
    .sub-title { font-size:0.88rem;font-weight:700;color:#fff; }
    .sub-meta  { font-size:0.75rem;color:var(--text-muted);margin-top:2px; }
    .grade-btn { display:inline-flex;align-items:center;gap:5px;padding:5px 10px;background:rgba(240,165,0,0.12);border:1px solid rgba(240,165,0,0.25);border-radius:8px;color:var(--gold);font-size:0.75rem;font-weight:700;text-decoration:none;transition:all 0.2s;white-space:nowrap;&:hover{background:rgba(240,165,0,0.2);} }
    .empty-inner { padding:1.25rem 0;text-align:center;font-size:0.875rem;color:var(--text-muted);i{margin-right:6px;}a{color:#4F95FF;} }
    @media(max-width:991px){.stats-grid{grid-template-columns:repeat(2,1fr)}.two-col{grid-template-columns:1fr}.wt{font-size:1.8rem}}
    @media(max-width:520px){.stats-grid{grid-template-columns:1fr}}
  `],
})
export class TeacherDashboardComponent implements OnInit {
  private auth      = inject(AuthService);
  private courseSvc = inject(CourseService);
  private enrollSvc = inject(EnrollmentService);
  private assessSvc = inject(AssessmentService);

  myCourses  = signal<Course[]>([]);
  pendingSubs = signal<Submission[]>([]);
  totalStudents = signal(0);

  firstName = computed(() => (this.auth.user()?.name ?? 'Teacher').split(' ')[0]);

  stats = computed(() => [
    { label: 'My Courses',   value: this.myCourses().length,  tone:'gold',  icon:'bi-book-fill' },
    { label: 'Total Students', value: this.totalStudents(),   tone:'blue',  icon:'bi-people-fill' },
    { label: 'Pending Grade', value: this.pendingSubs().length, tone:'rose', icon:'bi-hourglass-split' },
    { label: 'Active Courses', value: this.myCourses().filter(c => c.status === 'ACTIVE').length, tone:'mint', icon:'bi-play-circle-fill' },
  ]);

  ngOnInit(): void {
    const teacherId = this.auth.userId();
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) {
          const mine = (r.data ?? []).filter(c => c.teacherUserId === teacherId);
          this.myCourses.set(mine);
          let total = 0;
          let pending = mine.length || 1;
          mine.forEach(c => {
            this.enrollSvc.getByCourse(c.courseId).subscribe({
              next: er => { total += (er.data ?? []).length; if (--pending === 0) this.totalStudents.set(total); },
            });
            this.assessSvc.getByCourse(c.courseId).subscribe({
              next: ar => {
                (ar.data ?? []).forEach(a => {
                  this.assessSvc.getSubmissionsByAssessment(a.assessmentId).subscribe({
                    next: sr => {
                      const subs = (sr.data ?? []).filter(s => s.status === 'SUBMITTED');
                      this.pendingSubs.update(arr => [...arr, ...subs]);
                    },
                  });
                });
              },
            });
          });
        }
      },
    });
  }
}
