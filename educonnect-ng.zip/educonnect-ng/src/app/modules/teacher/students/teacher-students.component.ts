import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService, ProgressService } from '../../../core/services/index';
import { Course, Enrollment, Progress } from '../../../core/models';

@Component({
  selector: 'app-teacher-students',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Class Management</span>
          <h1 class="page-title">Students</h1>
          <p class="page-desc">View enrolled students and their progress per course</p>
        </div>
      </header>

      <!-- Course selector -->
      <div class="course-selector">
        <label class="sel-label">Select Course</label>
        <div class="course-pills">
          @for (c of myCourses(); track c.courseId) {
            <button class="course-pill"
              [class.active]="selectedCourseId() === c.courseId"
              (click)="selectCourse(c.courseId)">
              {{ c.title }}
            </button>
          }
        </div>
      </div>

      @if (!selectedCourseId()) {
        <div class="hint-box">
          <i class="bi bi-arrow-up-circle"></i>
          <p>Select a course above to view enrolled students</p>
        </div>
      } @else if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      } @else {
        <!-- Stats -->
        <div class="mini-stats">
          <div class="ms-card" data-tone="blue">
            <i class="bi bi-people-fill"></i>
            <div>
              <div class="ms-num">{{ enrollments().length }}</div>
              <div class="ms-label">Enrolled</div>
            </div>
          </div>
          <div class="ms-card" data-tone="mint">
            <i class="bi bi-patch-check-fill"></i>
            <div>
              <div class="ms-num">{{ completedCount() }}</div>
              <div class="ms-label">Completed</div>
            </div>
          </div>
          <div class="ms-card" data-tone="gold">
            <i class="bi bi-bar-chart-fill"></i>
            <div>
              <div class="ms-num">{{ avgProgress() }}%</div>
              <div class="ms-label">Avg. Progress</div>
            </div>
          </div>
        </div>

        <!-- Search -->
        <div class="search-bar">
          <i class="bi bi-search"></i>
          <input type="text" [(ngModel)]="search" class="search-input" placeholder="Search students..." />
        </div>

        @if (filtered().length === 0) {
          <div class="empty-state">
            <i class="bi bi-people"></i>
            <h3>No students enrolled</h3>
            <p>Students will appear here once they enroll in this course.</p>
          </div>
        } @else {
          <div class="table-wrap">
            <table class="ec-table">
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Enrolled</th>
                  <th>Progress</th>
                  <th>Completion</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                @for (e of filtered(); track e.enrollmentId) {
                  <tr>
                    <td>
                      <div class="student-cell">
                        <div class="s-av">{{ initials(e.studentId) }}</div>
                        <div>
                          <div class="s-name">Student #{{ e.studentId }}</div>
                          <div class="s-id">ID: {{ e.studentId }}</div>
                        </div>
                      </div>
                    </td>
                    <td>{{ e.enrollmentDate | date:'mediumDate' }}</td>
                    <td style="min-width:180px">
                      @if (progressOf(e.studentId); as p) {
                        <div class="prog-cell">
                          <div class="prog-pct">{{ p.completionPercentage }}%</div>
                          <div class="progress-track">
                            <div class="progress-bar" [style.width.%]="p.completionPercentage"
                                 [style.background]="progressColor(p.completionPercentage)"></div>
                          </div>
                        </div>
                      } @else {
                        <span class="no-data">No data</span>
                      }
                    </td>
                    <td>
                      @if (progressOf(e.studentId); as p) {
                        <span class="pct-num">{{ p.completionPercentage }}%</span>
                      } @else { <span class="no-data">—</span> }
                    </td>
                    <td>
                      @if (progressOf(e.studentId); as p) {
                        <span class="status-badge" [ngClass]="'sb-' + p.status.toLowerCase().replace('_','-')">
                          {{ p.status | titlecase }}
                        </span>
                      } @else {
                        <span class="status-badge sb-pending">Pending</span>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .page-head { margin-bottom:0; }
    .eyebrow { display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }

    .course-selector { display:flex;flex-direction:column;gap:0.6rem; }
    .sel-label { font-size:0.78rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.06em; }
    .course-pills { display:flex;flex-wrap:wrap;gap:0.5rem; }
    .course-pill { padding:0.5rem 1rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:100px;color:var(--text-muted);font-size:0.85rem;font-weight:600;font-family:inherit;cursor:pointer;transition:all 0.2s;&:hover{background:rgba(255,255,255,0.08);color:#fff;}&.active{background:linear-gradient(135deg,rgba(46,123,246,0.25),rgba(0,201,167,0.1));border-color:rgba(46,123,246,0.4);color:#fff;} }

    .hint-box { display:flex;flex-direction:column;align-items:center;justify-content:center;padding:3rem;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;text-align:center; i{font-size:2rem;color:var(--accent-light);margin-bottom:0.75rem;} p{font-size:0.9rem;color:var(--text-muted);} }

    .mini-stats { display:grid;grid-template-columns:repeat(3,1fr);gap:1rem; }
    .ms-card { display:flex;align-items:center;gap:1rem;padding:1.25rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:14px; i{font-size:1.5rem;} }
    .ms-card[data-tone="blue"] i { color:var(--accent-light); }
    .ms-card[data-tone="mint"]  i { color:var(--mint); }
    .ms-card[data-tone="gold"]  i { color:var(--gold); }
    .ms-num   { font-family:'Fraunces',serif;font-size:1.6rem;font-weight:800;color:#fff;letter-spacing:-0.02em; }
    .ms-label { font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em; }

    .search-bar { position:relative; i{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:0.9rem;} }
    .search-input { width:100%;max-width:400px;padding:0.65rem 0.9rem 0.65rem 2.3rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.88rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);} }

    .table-wrap { overflow-x:auto;border-radius:16px;border:1px solid var(--border); }
    .ec-table { width:100%;border-collapse:collapse; thead tr{background:rgba(255,255,255,0.03);} th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;} td{padding:0.875rem 1rem;font-size:0.875rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);} tbody tr:last-child td{border-bottom:none;} tbody tr:hover{background:rgba(255,255,255,0.025);} }
    .student-cell { display:flex;align-items:center;gap:0.75rem; }
    .s-av { width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--mint));display:flex;align-items:center;justify-content:center;font-size:0.72rem;font-weight:800;color:#fff;flex-shrink:0; }
    .s-name { font-size:0.9rem;font-weight:700;color:#fff; }
    .s-id   { font-size:0.72rem;color:var(--text-muted); }
    .prog-cell { display:flex;flex-direction:column;gap:0.35rem; }
    .prog-pct { font-size:0.75rem;font-weight:700;color:var(--mint); }
    .progress-track { height:6px;background:rgba(255,255,255,0.06);border-radius:100px;overflow:hidden; }
    .progress-bar { height:100%;border-radius:100px;transition:width 0.5s ease; }
    .pct-num { font-family:'Fraunces',serif;font-size:1rem;font-weight:700;color:#fff; }
    .no-data { font-size:0.82rem;color:var(--text-muted); }
    .status-badge { display:inline-flex;align-items:center;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em; }
    .sb-completed  { background:rgba(16,185,129,0.15);color:#34D399;border:1px solid rgba(16,185,129,0.25); }
    .sb-in-progress { background:rgba(46,123,246,0.15);color:var(--accent-light);border:1px solid rgba(46,123,246,0.25); }
    .sb-dropped    { background:rgba(239,68,68,0.15);color:#FCA5A5;border:1px solid rgba(239,68,68,0.25); }
    .sb-pending    { background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25); }
    .empty-state { padding:3rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px; i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;} h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;} p{font-size:0.875rem;color:var(--text-muted);} }
    .load-center { display:flex;justify-content:center;padding:3rem; }
    .ec-spin { display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite; }
    @media(max-width:768px){.mini-stats{grid-template-columns:1fr 1fr;}.page-title{font-size:1.7rem;}}
    @media(max-width:480px){.mini-stats{grid-template-columns:1fr;}}
    @keyframes spin { to{transform:rotate(360deg);} }
  `],
})
export class TeacherStudentsComponent implements OnInit {
  private auth        = inject(AuthService);
  private courseSvc   = inject(CourseService);
  private enrollSvc   = inject(EnrollmentService);
  private progressSvc = inject(ProgressService);

  loading           = signal(false);
  myCourses         = signal<Course[]>([]);
  enrollments       = signal<Enrollment[]>([]);
  progressMap       = signal<Map<number,Progress>>(new Map());
  selectedCourseId  = signal<number|null>(null);
  search            = '';

  completedCount = computed(() => Array.from(this.progressMap().values()).filter(p => p.status === 'COMPLETED').length);
  avgProgress    = computed(() => {
    const vals = Array.from(this.progressMap().values());
    if (!vals.length) return 0;
    return Math.round(vals.reduce((s,p) => s + p.completionPercentage, 0) / vals.length);
  });

  filtered = computed(() => {
    const q = this.search.toLowerCase();
    return this.enrollments().filter(e =>
      !q || String(e.studentId).includes(q)
    );
  });

  progressOf(studentId: number): Progress | undefined {
    return this.progressMap().get(studentId);
  }

  initials(studentId: number): string {
    return 'S' + String(studentId).slice(-2);
  }

  progressColor(pct: number): string {
    if (pct >= 70) return 'linear-gradient(90deg,#2E7BF6,#00C9A7)';
    if (pct >= 40) return 'linear-gradient(90deg,#F0A500,#2E7BF6)';
    return 'linear-gradient(90deg,#FB7185,#F0A500)';
  }

  ngOnInit(): void {
    const tid = this.auth.userId() ?? 1;
    this.courseSvc.getAll().subscribe({
      next: r => {
        if (r.success) this.myCourses.set((r.data ?? []).filter(c => c.teacherUserId === tid));
      },
    });
  }

  selectCourse(id: number): void {
    this.selectedCourseId.set(id);
    this.loading.set(true);
    this.enrollments.set([]);
    this.progressMap.set(new Map());

    this.enrollSvc.getByCourse(id).subscribe({
      next: r => {
        if (r.success) {
          this.enrollments.set(r.data ?? []);
          this.loadProgress(id);
        } else { this.loading.set(false); }
      },
      error: () => this.loading.set(false),
    });
  }

  loadProgress(courseId: number): void {
    this.progressSvc.getByCourse(courseId).subscribe({
      next: r => {
        if (r.success) {
          const map = new Map<number,Progress>();
          (r.data ?? []).forEach(p => map.set(p.studentId, p));
          this.progressMap.set(map);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }
}
