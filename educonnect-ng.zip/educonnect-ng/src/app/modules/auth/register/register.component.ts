import { Component, signal, inject } from '@angular/core';
import { AbstractControl, ReactiveFormsModule, FormBuilder, Validators, ValidationErrors } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

// Custom cross-field validator
function passwordMatch(ctrl: AbstractControl): ValidationErrors | null {
  const pw  = ctrl.get('password')?.value;
  const cpw = ctrl.get('confirmPassword')?.value;
  return pw && cpw && pw !== cpw ? { mismatch: true } : null;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="signup-page">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <a routerLink="/login" class="back-btn"><i class="bi bi-arrow-left"></i> Back to Login</a>

      <div class="signup-container">
        <div class="signup-header">
          <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
          <h1 class="signup-title">Create your account</h1>
          <p class="signup-sub">
            Join EduConnect as a student.
            Already have an account? <a routerLink="/login">Sign in</a>
          </p>
        </div>

        <div class="student-badge">
          <i class="bi bi-person-badge"></i>
          Registering as a <strong>Student</strong>
        </div>

        @if (error()) {
          <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ error() }}</div>
        }
        @if (success()) {
          <div class="alert-success"><i class="bi bi-check-circle-fill"></i> {{ success() }}</div>
        }

        <form [formGroup]="form" (ngSubmit)="submit()" novalidate>
          <!-- Name -->
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <div class="input-wrapper">
              <i class="bi bi-person input-icon"></i>
              <input formControlName="name" type="text" class="form-control has-icon"
                     placeholder="Your full name" [class.is-invalid]="isInvalid('name')" />
            </div>
            @if (isInvalid('name')) { <span class="invalid-feedback">Name is required</span> }
          </div>

          <!-- Email -->
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <div class="input-wrapper">
              <i class="bi bi-envelope input-icon"></i>
              <input formControlName="email" type="email" class="form-control has-icon"
                     placeholder="you@email.com" [class.is-invalid]="isInvalid('email')" />
            </div>
            @if (isInvalid('email')) { <span class="invalid-feedback">Valid email required</span> }
          </div>

          <!-- Phone -->
          <div class="form-group">
            <label class="form-label">Phone Number</label>
            <div class="input-wrapper">
              <i class="bi bi-telephone input-icon"></i>
              <input formControlName="phone" type="tel" class="form-control has-icon"
                     placeholder="10-digit number" [class.is-invalid]="isInvalid('phone')" />
            </div>
            @if (isInvalid('phone')) { <span class="invalid-feedback">Enter a valid phone number</span> }
          </div>

          <!-- Password -->
          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-wrapper">
              <i class="bi bi-lock input-icon"></i>
              <input formControlName="password" [type]="showPwd() ? 'text' : 'password'"
                     class="form-control has-icon" placeholder="Min. 6 characters"
                     [class.is-invalid]="isInvalid('password')" style="padding-right:2.6rem" />
              <button type="button" class="input-toggle" (click)="showPwd.update(v=>!v)">
                <i class="bi" [ngClass]="showPwd() ? 'bi-eye-slash':'bi-eye'"></i>
              </button>
            </div>
            @if (isInvalid('password')) { <span class="invalid-feedback">Min. 6 characters required</span> }
          </div>

          <!-- Confirm Password -->
          <div class="form-group">
            <label class="form-label">Confirm Password</label>
            <div class="input-wrapper">
              <i class="bi bi-lock-fill input-icon"></i>
              <input formControlName="confirmPassword" [type]="showPwd() ? 'text':'password'"
                     class="form-control has-icon" placeholder="Repeat your password"
                     [class.is-invalid]="form.hasError('mismatch') && form.get('confirmPassword')?.touched" />
            </div>
            @if (form.hasError('mismatch') && form.get('confirmPassword')?.touched) {
              <span class="invalid-feedback">Passwords do not match</span>
            }
          </div>

          <button type="submit" class="btn" [disabled]="loading() || form.invalid">
            @if (loading()) { <span class="spinner"></span> Creating... }
            @else { Create Account <i class="bi bi-arrow-right"></i> }
          </button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .signup-page { min-height:100vh; background:#0D1B3E; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:2rem 1rem; position:relative; overflow:hidden; font-family:'Plus Jakarta Sans',sans-serif; }
    .blob { position:absolute; border-radius:50%; filter:blur(80px); opacity:0.12; pointer-events:none; }
    .blob-1 { width:500px; height:500px; background:radial-gradient(circle,#2E7BF6,transparent); top:-100px; left:-100px; }
    .blob-2 { width:350px; height:350px; background:radial-gradient(circle,#00C9A7,transparent); bottom:-50px; right:-50px; }
    .back-btn { position:absolute; top:1.5rem; left:1.5rem; display:flex; align-items:center; gap:6px; color:#8898B3; text-decoration:none; font-size:0.875rem; font-weight:500; transition:color 0.2s; z-index:10; &:hover{color:#fff;} }
    .signup-container { width:100%; max-width:520px; background:rgba(26,47,94,0.5); border:1px solid rgba(255,255,255,0.08); border-radius:24px; padding:2.5rem 2rem; backdrop-filter:blur(20px); position:relative; z-index:1; box-shadow:0 40px 80px rgba(0,0,0,0.4); animation:slideUp 0.35s ease; }
    .signup-header { text-align:center; margin-bottom:1.5rem; }
    .brand-icon { width:52px; height:52px; background:linear-gradient(135deg,#2E7BF6,#00C9A7); border-radius:14px; display:flex; align-items:center; justify-content:center; font-size:1.4rem; color:#fff; margin:0 auto 1rem; }
    .signup-title { font-family:'Fraunces',serif; font-size:1.75rem; font-weight:700; color:#fff; margin-bottom:0.5rem; }
    .signup-sub { font-size:0.875rem; color:#8898B3; line-height:1.6; a{color:#4F95FF;text-decoration:none;font-weight:600;&:hover{text-decoration:underline;}} }
    .student-badge { display:flex; align-items:center; justify-content:center; gap:8px; padding:0.65rem 1rem; background:rgba(0,201,167,0.1); border:1px solid rgba(0,201,167,0.25); border-radius:10px; color:#00C9A7; font-size:0.875rem; font-weight:500; margin-bottom:1.5rem; strong{color:#fff;} }
    .alert-error   { display:flex; align-items:center; gap:8px; padding:0.75rem 1rem; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); border-radius:10px; color:#FCA5A5; font-size:0.875rem; margin-bottom:1.25rem; }
    .alert-success { display:flex; align-items:center; gap:8px; padding:0.75rem 1rem; background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.3); border-radius:10px; color:#34D399; font-size:0.875rem; margin-bottom:1.25rem; }
    .form-group { margin-bottom:1rem; }
    .form-label { display:block; font-size:0.78rem; font-weight:600; color:#8898B3; margin-bottom:0.4rem; text-transform:uppercase; letter-spacing:0.06em; }
    .input-wrapper { position:relative; }
    .input-icon { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#8898B3; font-size:0.9rem; pointer-events:none; }
    .input-toggle { position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; color:#8898B3; cursor:pointer; padding:4px; font-size:0.9rem; transition:color 0.2s; &:hover{color:#fff;} }
    .form-control { width:100%; padding:0.7rem 0.9rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; font-size:0.9rem; font-family:inherit; outline:none; transition:border-color 0.2s; &::placeholder{color:rgba(136,152,179,0.6);} &:focus{border-color:#2E7BF6;background:rgba(46,123,246,0.06);} &.has-icon{padding-left:2.4rem;} &.is-invalid{border-color:rgba(239,68,68,0.5);} }
    .invalid-feedback { font-size:0.75rem; color:#FCA5A5; margin-top:4px; display:block; }
    .btn { display:flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:0.85rem; background:linear-gradient(135deg,#2E7BF6,#1A5FD4); border:none; border-radius:12px; color:#fff; font-size:0.95rem; font-weight:700; font-family:inherit; cursor:pointer; transition:all 0.3s; box-shadow:0 8px 24px rgba(46,123,246,0.35); margin-top:0.5rem; &:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 16px 40px rgba(46,123,246,0.5);} &:disabled{opacity:0.6;cursor:not-allowed;transform:none;} }
    .spinner { display:inline-block; width:18px; height:18px; border:2px solid rgba(255,255,255,0.3); border-top-color:#fff; border-radius:50%; animation:spin 0.6s linear infinite; }
    @keyframes spin { to{transform:rotate(360deg);} }
    @keyframes slideUp { from{opacity:0;transform:translateY(24px);} to{opacity:1;transform:none;} }
  `],
})
export class RegisterComponent {
  private fb     = inject(FormBuilder);
  private auth   = inject(AuthService);
  private router = inject(Router);

  loading = signal(false);
  error   = signal('');
  success = signal('');
  showPwd = signal(false);

  form = this.fb.nonNullable.group({
    name:            ['', Validators.required],
    email:           ['', [Validators.required, Validators.email]],
    phone:           ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    password:        ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', Validators.required],
  }, { validators: passwordMatch });

  isInvalid(field: string): boolean {
    const c = this.form.get(field);
    return !!(c?.invalid && c?.touched);
  }

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading.set(true);
    this.error.set('');

    const { confirmPassword, ...payload } = this.form.getRawValue();
    this.auth.register(payload).subscribe({
      next: res => {
        this.loading.set(false);
        if (res.success) {
          this.success.set('Account created! Redirecting to login...');
          setTimeout(() => this.router.navigate(['/login']), 1500);
        } else {
          this.error.set(res.message ?? 'Registration failed');
        }
      },
      error: err => {
        this.loading.set(false);
        this.error.set(err?.error?.message ?? 'Registration failed. Email may already be in use.');
      },
    });
  }
}
