import { Component, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="signup-page">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>

      <a routerLink="/" class="back-btn">
        <i class="bi bi-arrow-left"></i> Back to Home
      </a>

      <div class="signup-container">
        <div class="signup-header">
          <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
          <h1 class="signup-title">Welcome back</h1>
          <p class="signup-sub">
            Login to continue your journey.
            Don't have an account? <a routerLink="/register">Sign up</a>
          </p>
        </div>

        @if (error()) {
          <div class="alert-error">
            <i class="bi bi-exclamation-triangle-fill"></i> {{ error() }}
          </div>
        }

        <form [formGroup]="form" (ngSubmit)="submit()" novalidate>

          <!-- Email -->
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <div class="input-wrapper">
              <i class="bi bi-envelope input-icon"></i>
              <input formControlName="email" type="email"
                     class="form-control has-icon" placeholder="you@email.com"
                     [class.is-invalid]="isInvalid('email')" />
            </div>
            @if (isInvalid('email')) {
              <span class="invalid-feedback">Enter a valid email address</span>
            }
          </div>

          <!-- Password -->
          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-wrapper">
              <i class="bi bi-lock input-icon"></i>
              <input formControlName="password" [type]="showPwd() ? 'text' : 'password'"
                     class="form-control has-icon" placeholder="Enter your password"
                     [class.is-invalid]="isInvalid('password')" style="padding-right:2.6rem" />
              <button type="button" class="input-toggle" (click)="showPwd.update(v => !v)">
                <i class="bi" [ngClass]="showPwd() ? 'bi-eye-slash' : 'bi-eye'"></i>
              </button>
            </div>
            @if (isInvalid('password')) {
              <span class="invalid-feedback">Password is required</span>
            }
          </div>

          <!-- Demo accounts -->
          <div class="demo-row">
            <span class="demo-label">Quick demo:</span>
            @for (d of demos; track d.role) {
              <button type="button" class="demo-chip" (click)="fillDemo(d)">{{ d.role }}</button>
            }
          </div>

          <button type="submit" class="btn btn-primary btn-block btn-lg"
                  [disabled]="loading() || form.invalid">
            @if (loading()) { <span class="spinner"></span> Signing in... }
            @else { Login <i class="bi bi-arrow-right"></i> }
          </button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .signup-page {
      min-height: 100vh; background: #0D1B3E;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      padding: 2rem 1rem; position: relative; overflow: hidden;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .blob { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.12; pointer-events: none; }
    .blob-1 { width: 500px; height: 500px; background: radial-gradient(circle, #2E7BF6, transparent); top: -100px; left: -100px; }
    .blob-2 { width: 350px; height: 350px; background: radial-gradient(circle, #00C9A7, transparent); bottom: -50px; right: -50px; }
    .back-btn { position: absolute; top: 1.5rem; left: 1.5rem; display: flex; align-items: center; gap: 6px; color: #8898B3; text-decoration: none; font-size: 0.875rem; font-weight: 500; transition: color 0.2s; z-index: 10; &:hover { color: #fff; } }
    .signup-container {
      width: 100%; max-width: 520px;
      background: rgba(26,47,94,0.5); border: 1px solid rgba(255,255,255,0.08);
      border-radius: 24px; padding: 2.5rem 2rem;
      backdrop-filter: blur(20px); position: relative; z-index: 1;
      box-shadow: 0 40px 80px rgba(0,0,0,0.4);
      animation: slideUp 0.35s ease;
    }
    .signup-header { text-align: center; margin-bottom: 1.75rem; }
    .brand-icon { width: 52px; height: 52px; background: linear-gradient(135deg, #2E7BF6, #00C9A7); border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; color: #fff; margin: 0 auto 1rem; }
    .signup-title { font-family: 'Fraunces', serif; font-size: 1.75rem; font-weight: 700; color: #fff; margin-bottom: 0.5rem; }
    .signup-sub { font-size: 0.875rem; color: #8898B3; line-height: 1.6; a { color: #4F95FF; text-decoration: none; font-weight: 600; &:hover { text-decoration: underline; } } }
    .alert-error { display: flex; align-items: center; gap: 8px; padding: 0.75rem 1rem; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); border-radius: 10px; color: #FCA5A5; font-size: 0.875rem; margin-bottom: 1.25rem; }
    .form-group { margin-bottom: 1rem; }
    .form-label { display: block; font-size: 0.78rem; font-weight: 600; color: #8898B3; margin-bottom: 0.4rem; text-transform: uppercase; letter-spacing: 0.06em; }
    .input-wrapper { position: relative; }
    .input-icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #8898B3; font-size: 0.9rem; pointer-events: none; }
    .input-toggle { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); background: none; border: none; color: #8898B3; cursor: pointer; padding: 4px; font-size: 0.9rem; transition: color 0.2s; &:hover { color: #fff; } }
    .form-control {
      width: 100%; padding: 0.7rem 0.9rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; color: #fff; font-size: 0.9rem; font-family: 'Plus Jakarta Sans', sans-serif; outline: none; transition: border-color 0.2s, background 0.2s;
      &::placeholder { color: rgba(136,152,179,0.6); }
      &:focus { border-color: #2E7BF6; background: rgba(46,123,246,0.06); }
      &.has-icon { padding-left: 2.4rem; }
      &.is-invalid { border-color: rgba(239,68,68,0.5); }
    }
    .invalid-feedback { font-size: 0.75rem; color: #FCA5A5; margin-top: 4px; display: block; }
    .demo-row { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 1.25rem; }
    .demo-label { font-size: 0.72rem; color: #8898B3; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; }
    .demo-chip { padding: 3px 10px; background: rgba(46,123,246,0.12); border: 1px solid rgba(46,123,246,0.25); border-radius: 100px; color: #4F95FF; font-size: 0.72rem; font-weight: 700; font-family: inherit; cursor: pointer; transition: all 0.2s; &:hover { background: rgba(46,123,246,0.25); } }
    .btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 0.85rem; background: linear-gradient(135deg, #2E7BF6, #1A5FD4); border: none; border-radius: 12px; color: #fff; font-size: 0.95rem; font-weight: 700; font-family: 'Plus Jakarta Sans', sans-serif; cursor: pointer; transition: all 0.3s; box-shadow: 0 8px 24px rgba(46,123,246,0.35); width: 100%; &:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 16px 40px rgba(46,123,246,0.5); } &:disabled { opacity: 0.6; cursor: not-allowed; transform: none; } }
    .spinner { display: inline-block; width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.3); border-top-color: #fff; border-radius: 50%; animation: spin 0.6s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    @keyframes slideUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: none; } }
  `],
})
export class LoginComponent {
  private fb     = inject(FormBuilder);
  private auth   = inject(AuthService);
  private router = inject(Router);

  loading  = signal(false);
  error    = signal('');
  showPwd  = signal(false);

  form = this.fb.nonNullable.group({
    email:    ['', [Validators.required, Validators.email]],
    password: ['', Validators.required],
  });

  demos = [
    { role: 'Admin',   email: 'admin@edu.com',   password: 'Admin@1234' },
    { role: 'Student', email: 'alice@edu.com',    password: 'Alice@1234' },
    { role: 'Teacher', email: 'bob@edu.com',      password: 'Bob@12345' },
  ];

  isInvalid(field: string): boolean {
    const c = this.form.get(field);
    return !!(c?.invalid && c?.touched);
  }

  fillDemo(d: { email: string; password: string }): void {
    this.form.patchValue(d);
  }

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading.set(true);
    this.error.set('');

    this.auth.login(this.form.getRawValue()).subscribe({
      next: res => {
        this.loading.set(false);
        if (res.data?.role) this.router.navigateByUrl(this.auth.dashboardRoute());
        else this.error.set(res.message ?? 'Login failed');
      },
      error: err => {
        this.loading.set(false);
        this.error.set(err?.error?.message ?? 'Invalid credentials. Please try again.');
      },
    });
  }
}
