import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ComplianceService, ToastService } from '../../../core/services/index';
import { ComplianceRecord, ComplianceResult, ComplianceType } from '../../../core/models';

@Component({
  selector: 'app-admin-compliance',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Governance</span>
          <h1 class="page-title">Compliance Records</h1>
          <p class="page-desc">Track policy adherence across courses, assessments and programs</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">
          <i class="bi bi-plus-circle-fill"></i> Add Record
        </button>
      </header>

      <!-- Summary stats -->
      <div class="summary-grid">
        <div class="sum-card" data-tone="mint">
          <i class="bi bi-shield-check"></i>
          <div class="sum-val">{{ countByResult('COMPLIANT') }}</div>
          <div class="sum-label">Compliant</div>
        </div>
        <div class="sum-card" data-tone="rose">
          <i class="bi bi-shield-exclamation"></i>
          <div class="sum-val">{{ countByResult('NON_COMPLIANT') }}</div>
          <div class="sum-label">Non-Compliant</div>
        </div>
        <div class="sum-card" data-tone="gold">
          <i class="bi bi-hourglass-split"></i>
          <div class="sum-val">{{ countByResult('UNDER_REVIEW') }}</div>
          <div class="sum-label">Under Review</div>
        </div>
        <div class="sum-card" data-tone="blue">
          <i class="bi bi-arrow-repeat"></i>
          <div class="sum-val">{{ countByResult('REMEDIATED') }}</div>
          <div class="sum-label">Remediated</div>
        </div>
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      } @else if (records().length === 0) {
        <div class="empty-state">
          <i class="bi bi-shield-check"></i>
          <h3>No compliance records</h3>
          <p>Add records to start tracking policy adherence.</p>
        </div>
      } @else {
        <div class="table-wrap">
          <table class="ec-table">
            <thead>
              <tr><th>Entity ID</th><th>Type</th><th>Result</th><th>Recorded</th><th>Notes</th><th>Actions</th></tr>
            </thead>
            <tbody>
              @for (r of records(); track r.complianceId) {
                <tr>
                  <td><strong>#{{ r.entityId }}</strong></td>
                  <td><span class="type-tag">{{ r.type }}</span></td>
                  <td>
                    <span class="res-badge" [ngClass]="'res-' + (r.result ?? 'UNDER_REVIEW').toLowerCase()">
                      {{ r.result ?? 'UNDER_REVIEW' }}
                    </span>
                  </td>
                  <td class="muted">{{ r.recordDate | date:'mediumDate' }}</td>
                  <td class="muted small">{{ r.notes ?? '—' }}</td>
                  <td>
                    @if (!r.result || r.result === 'UNDER_REVIEW') {
                      <div class="row-actions">
                        <button class="action-btn mint" (click)="setResult(r, 'COMPLIANT')" title="Mark compliant">
                          <i class="bi bi-check-lg"></i>
                        </button>
                        <button class="action-btn danger" (click)="setResult(r, 'NON_COMPLIANT')" title="Mark non-compliant">
                          <i class="bi bi-x-lg"></i>
                        </button>
                      </div>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }

      <!-- Add Record Modal -->
      @if (showModal()) {
        <div class="modal-backdrop" (click)="closeModal()">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <h3 class="modal-title">Add Compliance Record</h3>
              <button class="modal-close" (click)="closeModal()"><i class="bi bi-x"></i></button>
            </div>
            @if (formError()) {
              <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ formError() }}</div>
            }
            <form [formGroup]="form" (ngSubmit)="doCreate()">
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">Entity ID *</label>
                  <input formControlName="entityId" type="number" class="form-control" placeholder="e.g. 1" />
                </div>
                <div class="form-group">
                  <label class="form-label">Type *</label>
                  <select formControlName="type" class="form-select">
                    <option value="">Select type</option>
                    @for (t of compTypes; track t) { <option [value]="t">{{ t }}</option> }
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Notes</label>
                <textarea formControlName="notes" class="form-control" rows="3" placeholder="Optional notes..."></textarea>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="saving() || form.invalid">
                  @if (saving()) { <span class="spinner"></span> Saving... }
                  @else { Add Record }
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host{--accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;--purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);display:block;font-family:'Plus Jakarta Sans',sans-serif;}
    .page{display:flex;flex-direction:column;gap:1.5rem;}
    .page-head{display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap;}
    .eyebrow{display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;}
    .page-title{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0;}
    .page-desc{font-size:0.92rem;color:var(--text-muted);margin-top:6px;}
    .summary-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;}
    .sum-card{display:flex;flex-direction:column;align-items:center;padding:1.5rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;text-align:center;transition:all 0.25s;&:hover{transform:translateY(-3px);}i{font-size:1.75rem;margin-bottom:0.75rem;}.sum-val{font-family:'Fraunces',serif;font-size:2rem;font-weight:800;color:#fff;letter-spacing:-0.02em;}.sum-label{font-size:0.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em;margin-top:4px;}}
    .sum-card[data-tone="mint"]   i{color:var(--mint);}
    .sum-card[data-tone="rose"]   i{color:var(--rose);}
    .sum-card[data-tone="gold"]   i{color:var(--gold);}
    .sum-card[data-tone="blue"]   i{color:var(--accent-light);}
    .table-wrap{overflow-x:auto;border-radius:16px;border:1px solid var(--border);}
    .ec-table{width:100%;border-collapse:collapse;thead tr{background:rgba(255,255,255,0.03);}th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;}td{padding:0.875rem 1rem;font-size:0.875rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);}tbody tr:last-child td{border-bottom:none;}tbody tr:hover{background:rgba(255,255,255,0.025);}}
    .type-tag{display:inline-flex;padding:3px 8px;border-radius:6px;font-size:0.7rem;font-weight:700;background:rgba(46,123,246,0.12);color:var(--accent-light);text-transform:uppercase;letter-spacing:0.04em;}
    .res-badge{display:inline-flex;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;}
    .res-compliant{background:rgba(16,185,129,0.15);color:#34D399;border:1px solid rgba(16,185,129,0.25);}
    .res-non_compliant{background:rgba(239,68,68,0.15);color:#FCA5A5;border:1px solid rgba(239,68,68,0.25);}
    .res-under_review{background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25);}
    .res-remediated{background:rgba(46,123,246,0.15);color:var(--accent-light);border:1px solid rgba(46,123,246,0.25);}
    .muted{color:var(--text-muted);font-size:0.85rem;}.small{font-size:0.8rem;max-width:200px;}
    .row-actions{display:flex;gap:0.4rem;}
    .action-btn{width:30px;height:30px;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:8px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:0.9rem;color:var(--text-muted);transition:all 0.2s;}
    .action-btn.mint:hover{background:rgba(0,201,167,0.15);color:var(--mint);border-color:rgba(0,201,167,0.3);}
    .action-btn.danger:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;border-color:rgba(239,68,68,0.3);}
    .modal-backdrop{position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease;}
    .modal{background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:520px;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease;}
    .modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;}
    .modal-title{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;margin:0;}
    .modal-close{width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--text-muted);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;}}
    .alert-error{display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1.25rem;}
    .form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
    .form-group{margin-bottom:1rem;}
    .form-label{display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em;}
    .form-control{width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);}}
    .form-select{@extend .form-control;cursor:pointer;appearance:none;option{background:#1A2F5E;}}
    textarea.form-control{min-height:80px;resize:vertical;}
    .modal-footer{display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem;}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.25rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;&:disabled{opacity:0.55;cursor:not-allowed;}}
    .btn-primary{background:linear-gradient(135deg,var(--accent),#1A5FD4);color:#fff;box-shadow:0 6px 18px rgba(46,123,246,0.3);&:hover:not(:disabled){transform:translateY(-2px);}}
    .btn-ghost{background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);}}
    .empty-state{padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;}h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;}p{font-size:0.875rem;color:var(--text-muted);}}
    .spinner{display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;}
    .ec-spin{display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite;}
    .load-center{display:flex;justify-content:center;padding:3rem;}
    @media(max-width:768px){.summary-grid{grid-template-columns:repeat(2,1fr);}  .form-row{grid-template-columns:1fr;}}
    @keyframes spin{to{transform:rotate(360deg);}}
    @keyframes fadeIn{from{opacity:0;}to{opacity:1;}}
    @keyframes slideUp{from{opacity:0;transform:translateY(24px);}to{opacity:1;transform:none;}}
  `],
})
export class AdminComplianceComponent implements OnInit {
  private complianceSvc = inject(ComplianceService);
  private toast         = inject(ToastService);
  private fb            = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  showModal = signal(false);
  records   = signal<ComplianceRecord[]>([]);
  formError = signal('');

  compTypes: ComplianceType[] = ['COURSE','ASSESSMENT','PROGRAM','CONTENT'];

  form = this.fb.nonNullable.group({
    entityId: [null as unknown as number, Validators.required],
    type:     ['', Validators.required],
    notes:    [''],
  });

  countByResult(r: string): number {
    return this.records().filter(x => (x.result ?? 'UNDER_REVIEW') === r).length;
  }

  ngOnInit(): void {
    this.complianceSvc.getAll().subscribe({
      next: r => { if (r.success) this.records.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    this.complianceSvc.create(this.form.getRawValue() as any).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.records.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Record added', 'Compliance record created.');
        } else { this.formError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  setResult(rec: ComplianceRecord, result: ComplianceResult): void {
    this.complianceSvc.updateResult(rec.complianceId, result).subscribe({
      next: r => {
        if (r.success) {
          this.records.update(arr => arr.map(x => x.complianceId === rec.complianceId ? { ...x, result } : x));
          this.toast.success('Updated', `Record marked as ${result}.`);
        }
      },
    });
  }
}
