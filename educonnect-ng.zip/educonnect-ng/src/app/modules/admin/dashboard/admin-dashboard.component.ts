import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ReportService, AdminUserService } from '../../../core/services/index';
import { DashboardMetrics, User } from '../../../core/models';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page">
      <!-- HERO -->
      <section class="hero-card">
        <div class="hc-blob"></div>
        <div class="hc-blob2"></div>
        <div class="hc-inner">
          <div>
            <span class="eyebrow-chip">Admin Console</span>
            <h1 class="hc-title">Platform Overview</h1>
            <p class="hc-desc">
              Full visibility into EduConnect's operations —
              users, courses, compliance, audits and reports in one place.
            </p>
            <div class="hc-actions">
              <a routerLink="/admin/users" class="btn-accent">
                <i class="bi bi-people-fill"></i> Manage Users
              </a>
              <a routerLink="/admin/reports" class="btn-ghost">
                <i class="bi bi-file-earmark-bar-graph"></i> View Reports
              </a>
            </div>
          </div>
          <div class="hc-badges">
            <div class="badge-pill blue"><i class="bi bi-shield-check"></i> Secure</div>
            <div class="badge-pill mint"><i class="bi bi-graph-up"></i> Analytics</div>
            <div class="badge-pill gold"><i class="bi bi-stars"></i> Full Access</div>
          </div>
        </div>
      </section>

      <!-- KPI STATS -->
      @if (loadingMetrics()) {
        <div class="kpi-skeleton">
          @for (i of [1,2,3,4,5,6]; track i) { <div class="skel-card"></div> }
        </div>
      } @else if (metrics()) {
        <div class="kpi-grid">
          <div class="kpi-card" data-tone="blue">
            <div class="kpi-icon"><i class="bi bi-people-fill"></i></div>
            <div class="kpi-body">
              <div class="kpi-label">Total Students</div>
              <div class="kpi-val">{{ metrics()!.totalStudents | number }}</div>
              <div class="kpi-change positive"><i class="bi bi-arrow-up-right"></i> Active Learners</div>
            </div>
          </div>
          <div class="kpi-card" data-tone="mint">
            <div class="kpi-icon"><i class="bi bi-person-video2"></i></div>
            <div class="kpi-body">
              <div class="kpi-label">Total Teachers</div>
              <div class="kpi-val">{{ metrics()!.totalTeachers | number }}</div>
              <div class="kpi-change positive"><i class="bi bi-arrow-up-right"></i> Instructors</div>
            </div>
          </div>
          <div class="kpi-card" data-tone="gold">
            <div class="kpi-icon"><i class="bi bi-book-fill"></i></div>
            <div class="kpi-body">
              <div class="kpi-label">Total Courses</div>
              <div class="kpi-val">{{ metrics()!.totalCourses | number }}</div>
              <div class="kpi-change neutral"><i class="bi bi-dash"></i> Published</div>
            </div>
          </div>
          <div class="kpi-card" data-tone="purple">
            <div class="kpi-icon"><i class="bi bi-person-check-fill"></i></div>
            <div class="kpi-body">
              <div class="kpi-label">Enrollments</div>
              <div class="kpi-val">{{ metrics()!.totalEnrollments | number }}</div>
              <div class="kpi-change positive"><i class="bi bi-arrow-up-right"></i> Total</div>
            </div>
          </div>
          <div class="kpi-card" data-tone="rose">
            <div class="kpi-icon"><i class="bi bi-pencil-square"></i></div>
            <div class="kpi-body">
              <div class="kpi-label">Assessments</div>
              <div class="kpi-val">{{ metrics()!.totalAssessments | number }}</div>
              <div class="kpi-change neutral"><i class="bi bi-dash"></i> Created</div>
            </div>
          </div>
          <div class="kpi-card completion">
            <div class="kpi-icon"><i class="bi bi-patch-check-fill"></i></div>
            <div class="kpi-body">
              <div class="kpi-label">Completion Rate</div>
              <div class="kpi-val">{{ metrics()!.completionRate ?? 0 }}%</div>
              <div class="kpi-bar">
                <div class="kpi-bar-fill" [style.width.%]="metrics()!.completionRate ?? 0"></div>
              </div>
            </div>
          </div>
        </div>
      }

      <!-- BOTTOM GRID -->
      <div class="bottom-grid">
        <!-- Recent Users Panel -->
        <section class="panel">
          <div class="panel-header">
            <div>
              <h3 class="panel-title">Recent Users</h3>
              <p class="panel-sub">Latest registered accounts</p>
            </div>
            <a routerLink="/admin/users" class="panel-link">
              Manage all <i class="bi bi-arrow-right"></i>
            </a>
          </div>
          @if (loadingUsers()) {
            <div class="load-row"><span class="spinner"></span> Loading users...</div>
          } @else if (recentUsers().length === 0) {
            <div class="empty-mini"><i class="bi bi-people"></i> No users found</div>
          } @else {
            @for (u of recentUsers(); track u.userId) {
              <div class="user-row">
                <div class="ur-left">
                  <div class="ur-av">{{ u.name.charAt(0).toUpperCase() }}</div>
                  <div>
                    <div class="ur-name">{{ u.name }}</div>
                    <div class="ur-email">{{ u.email }}</div>
                  </div>
                </div>
                <div class="ur-right">
                  <span class="role-badge" [ngClass]="'role-' + u.role.toLowerCase()">{{ u.role }}</span>
                  <span class="status-dot" [class.active]="u.status === 'ACTIVE'">
                    <i class="bi bi-circle-fill"></i>
                  </span>
                </div>
              </div>
            }
          }
        </section>

        <!-- Quick Actions Panel -->
        <section class="panel">
          <div class="panel-header">
            <div>
              <h3 class="panel-title">Quick Actions</h3>
              <p class="panel-sub">Jump to common tasks</p>
            </div>
          </div>
          <div class="qa-grid">
            @for (qa of quickActions; track qa.label) {
              <a [routerLink]="qa.route" class="qa-item" [attr.data-tone]="qa.tone">
                <div class="qa-icon"><i class="bi" [ngClass]="qa.icon"></i></div>
                <div class="qa-label">{{ qa.label }}</div>
                <div class="qa-desc">{{ qa.desc }}</div>
                <i class="bi bi-chevron-right qa-arrow"></i>
              </a>
            }
          </div>
        </section>
      </div>
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page { display:flex;flex-direction:column;gap:1.5rem; }

    /* Hero */
    .hero-card { position:relative;background:linear-gradient(135deg,rgba(46,123,246,0.15),rgba(0,201,167,0.06));border:1px solid rgba(46,123,246,0.2);border-radius:24px;padding:2.25rem;overflow:hidden; }
    .hc-blob  { position:absolute;width:400px;height:400px;background:radial-gradient(circle,rgba(46,123,246,0.3),transparent 70%);filter:blur(70px);top:-150px;right:-80px;pointer-events:none; }
    .hc-blob2 { position:absolute;width:250px;height:250px;background:radial-gradient(circle,rgba(0,201,167,0.25),transparent 70%);filter:blur(50px);bottom:-80px;left:-40px;pointer-events:none; }
    .hc-inner { position:relative;display:flex;justify-content:space-between;align-items:center;gap:2rem;flex-wrap:wrap; }
    .eyebrow-chip { display:inline-flex;align-items:center;gap:6px;padding:4px 12px;background:rgba(240,165,0,0.15);border:1px solid rgba(240,165,0,0.3);border-radius:100px;font-size:0.72rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.9rem; }
    .hc-title { font-family:'Fraunces',serif;font-size:2rem;font-weight:800;color:#fff;margin:0 0 0.5rem;letter-spacing:-0.02em; }
    .hc-desc  { color:var(--text-muted);font-size:0.95rem;line-height:1.6;max-width:480px; }
    .hc-actions { display:flex;gap:0.75rem;margin-top:1.25rem;flex-wrap:wrap; }
    .btn-accent { display:inline-flex;align-items:center;gap:8px;padding:0.7rem 1.3rem;background:linear-gradient(135deg,var(--accent),#1A5FD4);border:none;border-radius:10px;color:#fff;font-size:0.9rem;font-weight:700;text-decoration:none;transition:all 0.25s;box-shadow:0 8px 22px rgba(46,123,246,0.35);&:hover{transform:translateY(-2px);box-shadow:0 14px 32px rgba(46,123,246,0.5);color:#fff;} }
    .btn-ghost { display:inline-flex;align-items:center;gap:8px;padding:0.7rem 1.2rem;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.9rem;font-weight:600;text-decoration:none;transition:all 0.2s;&:hover{background:rgba(255,255,255,0.1);color:#fff;} }
    .hc-badges { display:flex;flex-direction:column;gap:0.6rem;flex-shrink:0; }
    .badge-pill { display:flex;align-items:center;gap:8px;padding:0.6rem 1rem;border-radius:12px;font-size:0.82rem;font-weight:700; }
    .badge-pill.blue { background:rgba(46,123,246,0.15);color:var(--accent-light);border:1px solid rgba(46,123,246,0.25); }
    .badge-pill.mint  { background:rgba(0,201,167,0.15); color:var(--mint);         border:1px solid rgba(0,201,167,0.25); }
    .badge-pill.gold  { background:rgba(240,165,0,0.15);  color:var(--gold);         border:1px solid rgba(240,165,0,0.25); }

    /* KPI grid */
    .kpi-grid { display:grid;grid-template-columns:repeat(6,1fr);gap:1rem; }
    .kpi-skeleton { display:grid;grid-template-columns:repeat(6,1fr);gap:1rem; }
    .skel-card { height:100px;background:rgba(255,255,255,0.04);border-radius:16px;animation:pulse 1.5s ease-in-out infinite; }
    .kpi-card { display:flex;align-items:center;gap:1rem;padding:1.25rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;transition:all 0.25s;overflow:hidden;&:hover{transform:translateY(-3px);border-color:rgba(46,123,246,0.3);} }
    .kpi-card.completion { flex-direction:column;align-items:flex-start;gap:0.75rem; }
    .kpi-icon { width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0; }
    .kpi-card[data-tone="blue"]   .kpi-icon { background:rgba(46,123,246,0.15);color:var(--accent-light); }
    .kpi-card[data-tone="mint"]   .kpi-icon { background:rgba(0,201,167,0.15); color:var(--mint); }
    .kpi-card[data-tone="gold"]   .kpi-icon { background:rgba(240,165,0,0.15); color:var(--gold); }
    .kpi-card[data-tone="purple"] .kpi-icon { background:rgba(167,139,250,0.15);color:var(--purple); }
    .kpi-card[data-tone="rose"]   .kpi-icon { background:rgba(251,113,133,0.15);color:var(--rose); }
    .kpi-card.completion          .kpi-icon { background:rgba(0,201,167,0.15); color:var(--mint); }
    .kpi-label { font-size:0.7rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.06em; }
    .kpi-val   { font-family:'Fraunces',serif;font-size:1.7rem;font-weight:800;color:#fff;line-height:1.1;letter-spacing:-0.02em; }
    .kpi-change { font-size:0.7rem;margin-top:3px;display:flex;align-items:center;gap:4px; &.positive{color:var(--mint);} &.neutral{color:var(--text-muted);} }
    .kpi-bar { width:100%;height:6px;background:rgba(255,255,255,0.06);border-radius:100px;overflow:hidden;margin-top:4px; }
    .kpi-bar-fill { height:100%;background:linear-gradient(90deg,var(--accent),var(--mint));border-radius:100px;transition:width 0.8s ease; }

    /* Bottom grid */
    .bottom-grid { display:grid;grid-template-columns:1.1fr 1fr;gap:1.5rem; }
    .panel { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:20px;padding:1.5rem;display:flex;flex-direction:column;gap:0 }
    .panel-header { display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.25rem;padding-bottom:1rem;border-bottom:1px solid var(--border); }
    .panel-title { font-family:'Fraunces',serif;font-size:1.15rem;font-weight:700;color:#fff;margin:0; }
    .panel-sub   { font-size:0.82rem;color:var(--text-muted);margin-top:3px; }
    .panel-link  { color:var(--accent-light);text-decoration:none;font-size:0.85rem;font-weight:600;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;&:hover{text-decoration:underline;} }
    .load-row { display:flex;align-items:center;gap:8px;padding:1rem;color:var(--text-muted);font-size:0.875rem; }
    .empty-mini { padding:1.5rem;text-align:center;font-size:0.85rem;color:var(--text-muted); i{margin-right:6px;} }

    /* User rows */
    .user-row { display:flex;justify-content:space-between;align-items:center;padding:0.85rem 0;border-bottom:1px solid rgba(255,255,255,0.04);&:last-child{border-bottom:none;} }
    .ur-left  { display:flex;align-items:center;gap:0.75rem; }
    .ur-av    { width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,rgba(46,123,246,0.4),rgba(0,201,167,0.4));display:flex;align-items:center;justify-content:center;font-size:0.82rem;font-weight:700;color:#fff;flex-shrink:0; }
    .ur-name  { font-size:0.875rem;font-weight:700;color:#fff; }
    .ur-email { font-size:0.72rem;color:var(--text-muted); }
    .ur-right { display:flex;align-items:center;gap:0.6rem; }
    .role-badge { display:inline-flex;padding:2px 8px;border-radius:100px;font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em; }
    .role-student            { background:rgba(0,201,167,0.12);color:var(--mint);border:1px solid rgba(0,201,167,0.2); }
    .role-teacher            { background:rgba(167,139,250,0.12);color:var(--purple);border:1px solid rgba(167,139,250,0.2); }
    .role-admin              { background:rgba(240,165,0,0.12);color:var(--gold);border:1px solid rgba(240,165,0,0.2); }
    .role-program_manager    { background:rgba(46,123,246,0.12);color:var(--accent-light);border:1px solid rgba(46,123,246,0.2); }
    .role-compliance_officer { background:rgba(251,113,133,0.12);color:var(--rose);border:1px solid rgba(251,113,133,0.2); }
    .role-government_auditor { background:rgba(245,158,11,0.12);color:#FCD34D;border:1px solid rgba(245,158,11,0.2); }
    .status-dot { font-size:0.5rem; &.active{color:var(--mint);} &:not(.active){color:var(--text-muted);} }

    /* Quick Actions */
    .qa-grid { display:grid;grid-template-columns:1fr 1fr;gap:0.75rem; }
    .qa-item { display:flex;flex-direction:column;gap:0.3rem;padding:1rem;background:rgba(255,255,255,0.02);border:1px solid var(--border);border-radius:14px;text-decoration:none;transition:all 0.2s;position:relative;&:hover{background:rgba(255,255,255,0.05);border-color:rgba(46,123,246,0.3);transform:translateY(-2px);} }
    .qa-icon  { width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.05rem;margin-bottom:0.25rem; }
    .qa-item[data-tone="blue"]   .qa-icon { background:rgba(46,123,246,0.15);color:var(--accent-light); }
    .qa-item[data-tone="mint"]   .qa-icon { background:rgba(0,201,167,0.15); color:var(--mint); }
    .qa-item[data-tone="gold"]   .qa-icon { background:rgba(240,165,0,0.15); color:var(--gold); }
    .qa-item[data-tone="purple"] .qa-icon { background:rgba(167,139,250,0.15);color:var(--purple); }
    .qa-item[data-tone="rose"]   .qa-icon { background:rgba(251,113,133,0.15);color:var(--rose); }
    .qa-label { font-size:0.875rem;font-weight:700;color:#fff; }
    .qa-desc  { font-size:0.72rem;color:var(--text-muted); }
    .qa-arrow { position:absolute;top:12px;right:12px;color:var(--text-muted);font-size:0.75rem; }

    .spinner { display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite; }

    @media(max-width:1280px) { .kpi-grid,.kpi-skeleton{grid-template-columns:repeat(3,1fr);} }
    @media(max-width:900px)  { .kpi-grid,.kpi-skeleton{grid-template-columns:repeat(2,1fr);} .bottom-grid{grid-template-columns:1fr;} }
    @media(max-width:600px)  { .kpi-grid,.kpi-skeleton{grid-template-columns:1fr;} .hc-badges{display:none;} .qa-grid{grid-template-columns:1fr;} }
    @keyframes spin  { to{transform:rotate(360deg);} }
    @keyframes pulse { 0%,100%{opacity:0.5;} 50%{opacity:1;} }
  `],
})
export class AdminDashboardComponent implements OnInit {
  private auth       = inject(AuthService);
  private reportSvc  = inject(ReportService);
  private adminSvc   = inject(AdminUserService);

  loadingMetrics = signal(true);
  loadingUsers   = signal(true);
  metrics        = signal<DashboardMetrics | null>(null);
  recentUsers    = signal<User[]>([]);

  quickActions = [
    { label: 'User Management', desc: 'Roles & accounts',  icon: 'bi-people-fill',            route: '/admin/users',      tone: 'blue' },
    { label: 'Courses',         desc: 'All platform courses', icon: 'bi-book-fill',            route: '/admin/courses',    tone: 'mint' },
    { label: 'Compliance',      desc: 'Policy records',    icon: 'bi-shield-check',            route: '/admin/compliance', tone: 'gold' },
    { label: 'Audits',          desc: 'Formal audits',     icon: 'bi-search',                  route: '/admin/audits',     tone: 'purple' },
    { label: 'Reports',         desc: 'Analytics & KPIs',  icon: 'bi-file-earmark-bar-graph',  route: '/admin/reports',    tone: 'rose' },
  ];

  ngOnInit(): void {
    this.reportSvc.getDashboard().subscribe({
      next: r => { if (r.success) this.metrics.set(r.data); this.loadingMetrics.set(false); },
      error: () => this.loadingMetrics.set(false),
    });
    this.adminSvc.getAllUsers().subscribe({
      next: r => { if (r.success) this.recentUsers.set((r.data ?? []).slice(0, 6)); this.loadingUsers.set(false); },
      error: () => this.loadingUsers.set(false),
    });
  }
}
