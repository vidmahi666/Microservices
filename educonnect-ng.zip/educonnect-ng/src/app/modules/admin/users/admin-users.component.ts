import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AdminUserService, ToastService } from '../../../core/services/index';
import { User, UserRole, UserStatus, CreateUserRequest } from '../../../core/models';

type StaffRole = 'TEACHER' | 'PROGRAM_MANAGER' | 'COMPLIANCE_OFFICER' | 'GOVERNMENT_AUDITOR';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Administration</span>
          <h1 class="page-title">User Management</h1>
          <p class="page-desc">{{ allUsers().length }} total users · {{ activeCount() }} active</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">
          <i class="bi bi-person-plus-fill"></i> Create Staff Account
        </button>
      </header>

      <!-- Role filter tabs -->
      <div class="tab-bar">
        @for (tab of roleTabs; track tab.key) {
          <button class="tab-item" [class.active]="roleFilter() === tab.key" (click)="roleFilter.set(tab.key)">
            <i class="bi" [ngClass]="tab.icon"></i> {{ tab.label }}
            <span class="tab-count">{{ countByRole(tab.key) }}</span>
          </button>
        }
      </div>

      <!-- Search + Status filter -->
      <div class="filter-row">
        <div class="search-wrap">
          <i class="bi bi-search"></i>
          <input type="text" [(ngModel)]="search" class="search-input" placeholder="Search by name or email..." />
        </div>
        <div class="status-filter">
          <button class="sf-btn" [class.active]="statusFilter() === 'ALL'" (click)="statusFilter.set('ALL')">All</button>
          <button class="sf-btn" [class.active]="statusFilter() === 'ACTIVE'" (click)="statusFilter.set('ACTIVE')">Active</button>
          <button class="sf-btn" [class.active]="statusFilter() === 'INACTIVE'" (click)="statusFilter.set('INACTIVE')">Inactive</button>
        </div>
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      } @else if (filtered().length === 0) {
        <div class="empty-state">
          <i class="bi bi-person-slash"></i>
          <h3>No users found</h3>
          <p>Try adjusting your filters or creating a new staff account.</p>
        </div>
      } @else {
        <div class="table-wrap">
          <table class="ec-table">
            <thead>
              <tr>
                <th>User</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              @for (u of filtered(); track u.userId) {
                <tr>
                  <td>
                    <div class="user-cell">
                      <div class="u-av">{{ u.name.charAt(0).toUpperCase() }}</div>
                      <div>
                        <div class="u-name">{{ u.name }}</div>
                        <div class="u-email">{{ u.email }}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span class="role-badge" [ngClass]="'role-' + u.role.toLowerCase()">
                      <i class="bi" [ngClass]="roleIcon(u.role)"></i> {{ roleLabel(u.role) }}
                    </span>
                  </td>
                  <td>
                    <span class="status-badge" [class.active]="u.status === 'ACTIVE'" [class.inactive]="u.status !== 'ACTIVE'">
                      <i class="bi bi-circle-fill"></i> {{ u.status }}
                    </span>
                  </td>
                  <td class="muted">{{ u.createdAt | date:'mediumDate' }}</td>
                  <td>
                    <div class="row-actions">
                      @if (u.status === 'ACTIVE') {
                        <button class="action-btn danger" (click)="deactivate(u)" title="Deactivate user">
                          <i class="bi bi-slash-circle"></i>
                        </button>
                      } @else {
                        <button class="action-btn mint" (click)="activate(u)" title="Activate user">
                          <i class="bi bi-check-circle-fill"></i>
                        </button>
                      }
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        <p class="table-count">Showing {{ filtered().length }} of {{ allUsers().length }} users</p>
      }

      <!-- Create Staff Modal -->
      @if (showModal()) {
        <div class="modal-backdrop" (click)="closeModal()">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <div>
                <h3 class="modal-title">Create Staff Account</h3>
                <p class="modal-sub">Admin-only: create teacher or staff logins</p>
              </div>
              <button class="modal-close" (click)="closeModal()"><i class="bi bi-x"></i></button>
            </div>
            @if (formError()) {
              <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ formError() }}</div>
            }
            @if (formSuccess()) {
              <div class="alert-success"><i class="bi bi-check-circle-fill"></i> {{ formSuccess() }}</div>
            }
            <form [formGroup]="createForm" (ngSubmit)="doCreate()">
              <div class="form-group">
                <label class="form-label">Staff Role *</label>
                <div class="role-grid">
                  @for (r of staffRoles; track r.value) {
                    <label class="role-option" [class.selected]="createForm.get('role')?.value === r.value">
                      <input type="radio" formControlName="role" [value]="r.value" hidden />
                      <i class="bi" [ngClass]="r.icon"></i>
                      <span>{{ r.label }}</span>
                    </label>
                  }
                </div>
                @if (isInvalid('role')) { <span class="err">Select a role</span> }
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">Full Name *</label>
                  <input formControlName="name" type="text" class="form-control" placeholder="Full name" />
                  @if (isInvalid('name')) { <span class="err">Required</span> }
                </div>
                <div class="form-group">
                  <label class="form-label">Phone</label>
                  <input formControlName="phone" type="tel" class="form-control" placeholder="Phone (optional)" />
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Email *</label>
                <input formControlName="email" type="email" class="form-control" placeholder="email@institution.com" />
                @if (isInvalid('email')) { <span class="err">Valid email required</span> }
              </div>
              <div class="form-group">
                <label class="form-label">Temporary Password *</label>
                <input formControlName="password" type="password" class="form-control" placeholder="Min. 6 characters" />
                @if (isInvalid('password')) { <span class="err">Min. 6 characters required</span> }
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="saving() || createForm.invalid">
                  @if (saving()) { <span class="spinner"></span> Creating... }
                  @else { <i class="bi bi-person-plus-fill"></i> Create Account }
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block;font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .page-head { display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap; }
    .eyebrow { display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }

    /* Tabs */
    .tab-bar { display:flex;gap:6px;padding:6px;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;overflow-x:auto;max-width:100%; }
    .tab-item { display:inline-flex;align-items:center;gap:8px;padding:0.55rem 0.9rem;background:transparent;border:none;color:var(--text-muted);font-size:0.82rem;font-weight:600;font-family:inherit;border-radius:8px;cursor:pointer;transition:all 0.2s;white-space:nowrap; .tab-count{font-size:0.7rem;padding:2px 7px;border-radius:100px;background:rgba(255,255,255,0.06);color:var(--text-muted);} &:hover{color:#fff;} &.active{background:linear-gradient(135deg,rgba(46,123,246,0.25),rgba(0,201,167,0.15));color:#fff;box-shadow:0 4px 12px rgba(46,123,246,0.22);.tab-count{background:rgba(255,255,255,0.12);color:#fff;}} }

    /* Filters */
    .filter-row { display:flex;gap:0.75rem;align-items:center;flex-wrap:wrap; }
    .search-wrap { position:relative;flex:1;min-width:240px; i{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:0.9rem;} }
    .search-input { width:100%;padding:0.65rem 0.9rem 0.65rem 2.3rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.88rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);} }
    .status-filter { display:flex;gap:4px;padding:4px;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:8px; }
    .sf-btn { padding:0.4rem 0.875rem;background:transparent;border:none;border-radius:6px;color:var(--text-muted);font-size:0.82rem;font-weight:600;font-family:inherit;cursor:pointer;transition:all 0.2s;white-space:nowrap;&:hover{color:#fff;}&.active{background:rgba(255,255,255,0.1);color:#fff;} }

    /* Table */
    .table-wrap { overflow-x:auto;border-radius:16px;border:1px solid var(--border); }
    .ec-table { width:100%;border-collapse:collapse; thead tr{background:rgba(255,255,255,0.03);} th{padding:0.85rem 1rem;font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;} td{padding:0.875rem 1rem;font-size:0.875rem;vertical-align:middle;border-bottom:1px solid rgba(255,255,255,0.03);} tbody tr:last-child td{border-bottom:none;} tbody tr:hover{background:rgba(255,255,255,0.025);} }
    .user-cell { display:flex;align-items:center;gap:0.75rem; }
    .u-av   { width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,rgba(46,123,246,0.35),rgba(0,201,167,0.35));display:flex;align-items:center;justify-content:center;font-size:0.82rem;font-weight:700;color:#fff;flex-shrink:0; }
    .u-name { font-size:0.9rem;font-weight:700;color:#fff; }
    .u-email{ font-size:0.72rem;color:var(--text-muted); }
    .role-badge { display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em; }
    .role-student            { background:rgba(0,201,167,0.12);color:var(--mint);border:1px solid rgba(0,201,167,0.2); }
    .role-teacher            { background:rgba(167,139,250,0.12);color:var(--purple);border:1px solid rgba(167,139,250,0.2); }
    .role-admin              { background:rgba(240,165,0,0.12);color:var(--gold);border:1px solid rgba(240,165,0,0.2); }
    .role-program_manager    { background:rgba(46,123,246,0.12);color:var(--accent-light);border:1px solid rgba(46,123,246,0.2); }
    .role-compliance_officer { background:rgba(251,113,133,0.12);color:var(--rose);border:1px solid rgba(251,113,133,0.2); }
    .role-government_auditor { background:rgba(245,158,11,0.12);color:#FCD34D;border:1px solid rgba(245,158,11,0.2); }
    .status-badge { display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:100px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em; i{font-size:0.4rem;} &.active{background:rgba(16,185,129,0.12);color:#34D399;border:1px solid rgba(16,185,129,0.2);} &.inactive{background:rgba(239,68,68,0.12);color:#FCA5A5;border:1px solid rgba(239,68,68,0.2);} }
    .muted { color:var(--text-muted);font-size:0.82rem; }
    .row-actions { display:flex;gap:0.4rem; }
    .action-btn { width:32px;height:32px;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:8px;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:0.9rem;transition:all 0.2s; }
    .action-btn.danger:hover { background:rgba(239,68,68,0.15);color:#FCA5A5;border-color:rgba(239,68,68,0.3); }
    .action-btn.mint:hover   { background:rgba(0,201,167,0.15);color:var(--mint);border-color:rgba(0,201,167,0.3); }
    .table-count { font-size:0.78rem;color:var(--text-muted);margin-top:0.5rem; }

    /* Modal */
    .modal-backdrop { position:fixed;inset:0;background:rgba(5,10,24,0.85);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease; }
    .modal { background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:600px;max-height:90vh;overflow-y:auto;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease; }
    .modal-header { display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.5rem; }
    .modal-title { font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;margin:0; }
    .modal-sub   { font-size:0.85rem;color:var(--text-muted);margin-top:4px; }
    .modal-close { width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--text-muted);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;} }
    .alert-error   { display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1.25rem; }
    .alert-success { display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);border-radius:10px;color:#34D399;font-size:0.875rem;margin-bottom:1.25rem; }
    .role-grid { display:grid;grid-template-columns:repeat(2,1fr);gap:0.5rem;margin-top:0.25rem; }
    .role-option { display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:10px;cursor:pointer;transition:all 0.2s;font-size:0.875rem;font-weight:600;color:var(--text-muted);&:hover{border-color:rgba(46,123,246,0.3);color:#fff;}&.selected{background:rgba(46,123,246,0.15);border-color:rgba(46,123,246,0.4);color:#fff;} i{font-size:1rem;} }
    .form-row { display:grid;grid-template-columns:1fr 1fr;gap:1rem; }
    .form-group { margin-bottom:1rem; }
    .form-label { display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em; }
    .form-control { width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);} }
    .err { font-size:0.75rem;color:#FCA5A5;margin-top:4px;display:block; }
    .modal-footer { display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem; }
    .btn { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.25rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;&:disabled{opacity:0.55;cursor:not-allowed;} }
    .btn-primary { background:linear-gradient(135deg,var(--accent),#1A5FD4);color:#fff;box-shadow:0 6px 18px rgba(46,123,246,0.3);&:hover:not(:disabled){transform:translateY(-2px);} }
    .btn-ghost   { background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);} }
    .empty-state { padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px; i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;} h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;} p{font-size:0.875rem;color:var(--text-muted);} }
    .spinner { display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite; }
    .ec-spin  { display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite; }
    .load-center { display:flex;justify-content:center;padding:3rem; }
    @media(max-width:640px) { .form-row{grid-template-columns:1fr;} .role-grid{grid-template-columns:1fr;} .tab-item{font-size:0.78rem;padding:0.5rem 0.6rem;} }
    @keyframes spin    { to{transform:rotate(360deg);} }
    @keyframes fadeIn  { from{opacity:0;} to{opacity:1;} }
    @keyframes slideUp { from{opacity:0;transform:translateY(24px);} to{opacity:1;transform:none;} }
  `],
})
export class AdminUsersComponent implements OnInit {
  private adminSvc = inject(AdminUserService);
  private toast    = inject(ToastService);
  private fb       = inject(FormBuilder);

  loading      = signal(true);
  saving       = signal(false);
  showModal    = signal(false);
  allUsers     = signal<User[]>([]);
  roleFilter   = signal('ALL');
  statusFilter = signal('ALL');
  search       = '';
  formError    = signal('');
  formSuccess  = signal('');

  activeCount = computed(() => this.allUsers().filter(u => u.status === 'ACTIVE').length);

  roleTabs = [
    { key: 'ALL',              label: 'All',        icon: 'bi-people-fill' },
    { key: 'STUDENT',          label: 'Students',   icon: 'bi-mortarboard' },
    { key: 'TEACHER',          label: 'Teachers',   icon: 'bi-person-video2' },
    { key: 'ADMIN',            label: 'Admins',     icon: 'bi-shield-fill' },
    { key: 'PROGRAM_MANAGER',  label: 'PM',         icon: 'bi-briefcase-fill' },
    { key: 'COMPLIANCE_OFFICER', label: 'Compliance', icon: 'bi-shield-check' },
    { key: 'GOVERNMENT_AUDITOR', label: 'Auditors', icon: 'bi-search' },
  ];

  staffRoles = [
    { label: 'Teacher',            value: 'TEACHER',            icon: 'bi-person-video2' },
    { label: 'Program Manager',    value: 'PROGRAM_MANAGER',    icon: 'bi-briefcase' },
    { label: 'Compliance Officer', value: 'COMPLIANCE_OFFICER', icon: 'bi-shield-check' },
    { label: 'Govt. Auditor',      value: 'GOVERNMENT_AUDITOR', icon: 'bi-search' },
  ];

  createForm = this.fb.nonNullable.group({
    role:     ['', Validators.required],
    name:     ['', Validators.required],
    email:    ['', [Validators.required, Validators.email]],
    phone:    [''],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  filtered = computed(() => {
    let list = this.allUsers();
    const rf = this.roleFilter();
    if (rf !== 'ALL') list = list.filter(u => u.role === rf);
    const sf = this.statusFilter();
    if (sf !== 'ALL') list = list.filter(u => u.status === sf);
    const q = this.search.toLowerCase().trim();
    if (q) list = list.filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
    return list;
  });

  countByRole(key: string): number {
    if (key === 'ALL') return this.allUsers().length;
    return this.allUsers().filter(u => u.role === key).length;
  }

  roleLabel(r: string): string {
    const m: Record<string,string> = {
      STUDENT:'Student', TEACHER:'Teacher', ADMIN:'Admin',
      PROGRAM_MANAGER:'PM', COMPLIANCE_OFFICER:'Compliance', GOVERNMENT_AUDITOR:'Auditor',
    };
    return m[r] ?? r;
  }

  roleIcon(r: string): string {
    const m: Record<string,string> = {
      STUDENT:'bi-mortarboard', TEACHER:'bi-person-video2', ADMIN:'bi-shield-fill',
      PROGRAM_MANAGER:'bi-briefcase-fill', COMPLIANCE_OFFICER:'bi-shield-check', GOVERNMENT_AUDITOR:'bi-search',
    };
    return m[r] ?? 'bi-person';
  }

  isInvalid(f: string): boolean {
    const c = this.createForm.get(f);
    return !!(c?.invalid && c?.touched);
  }

  ngOnInit(): void { this.loadUsers(); }

  loadUsers(): void {
    this.adminSvc.getAllUsers().subscribe({
      next: r => { if (r.success) this.allUsers.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  deactivate(u: User): void {
    this.adminSvc.deactivateUser(u.userId).subscribe({
      next: r => {
        if (r.success) {
          this.allUsers.update(arr => arr.map(x => x.userId === u.userId ? { ...x, status: UserStatus.INACTIVE } : x));
          this.toast.warning('Deactivated', `${u.name}'s account has been deactivated.`);
        }
      },
    });
  }

  activate(u: User): void {
    this.adminSvc.activateUser(u.userId).subscribe({
      next: r => {
        if (r.success) {
          this.allUsers.update(arr => arr.map(x => x.userId === u.userId ? { ...x, status: UserStatus.ACTIVE } : x));
          this.toast.success('Activated', `${u.name}'s account is now active.`);
        }
      },
    });
  }

  openCreate(): void {
    this.createForm.reset();
    this.formError.set('');
    this.formSuccess.set('');
    this.showModal.set(true);
  }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.saving.set(true);
    const { role, name, email, phone, password } = this.createForm.getRawValue();
    const payload: CreateUserRequest = { name, email, password, phone: phone || undefined };

    const callMap: Record<StaffRole, any> = {
      TEACHER:            this.adminSvc.createTeacher(payload),
      PROGRAM_MANAGER:    this.adminSvc.createProgramManager(payload),
      COMPLIANCE_OFFICER: this.adminSvc.createComplianceOfficer(payload),
      GOVERNMENT_AUDITOR: this.adminSvc.createGovernmentAuditor(payload),
    };

    const call = callMap[role as StaffRole];
    if (!call) { this.formError.set('Invalid role'); this.saving.set(false); return; }

    call.subscribe({
      next: (r: any) => {
        this.saving.set(false);
        if (r.success) {
          this.formSuccess.set(`Account created for ${r.data.name}!`);
          this.allUsers.update(arr => [r.data, ...arr]);
          setTimeout(() => this.closeModal(), 1500);
        } else { this.formError.set(r.message ?? 'Creation failed'); }
      },
      error: (err: any) => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Creation failed'); },
    });
  }
}
