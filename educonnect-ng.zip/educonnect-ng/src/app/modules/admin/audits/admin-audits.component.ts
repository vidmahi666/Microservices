import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { AuditService, ToastService } from '../../../core/services/index';
import { Audit, AuditStatus } from '../../../core/models';

@Component({
  selector: 'app-admin-audits',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Oversight</span>
          <h1 class="page-title">Audits</h1>
          <p class="page-desc">Manage formal government and compliance audits</p>
        </div>
        <button class="btn btn-primary" (click)="openCreate()">
          <i class="bi bi-plus-circle-fill"></i> Initiate Audit
        </button>
      </header>

      <!-- Summary -->
      <div class="sum-grid">
        @for (s of statusSummary(); track s.label) {
          <div class="sum-card" [attr.data-tone]="s.tone">
            <i class="bi" [ngClass]="s.icon"></i>
            <div class="sum-val">{{ s.count }}</div>
            <div class="sum-label">{{ s.label }}</div>
          </div>
        }
      </div>

      @if (loading()) {
        <div class="load-center"><span class="ec-spin"></span></div>
      } @else if (audits().length === 0) {
        <div class="empty-state">
          <i class="bi bi-search"></i>
          <h3>No audits yet</h3>
          <p>Initiate an audit to begin a formal review.</p>
        </div>
      } @else {
        <div class="audit-list">
          @for (a of audits(); track a.auditId) {
            <div class="audit-card">
              <div class="ac-head">
                <div class="ac-info">
                  <span class="audit-status" [ngClass]="'as-' + a.status.toLowerCase().replace('_','-')">
                    <i class="bi" [ngClass]="statusIcon(a.status)"></i> {{ a.status }}
                  </span>
                  <span class="audit-date"><i class="bi bi-calendar3"></i> {{ a.createdAt | date:'mediumDate' }}</span>
                </div>
                <div class="ac-actions">
                  @if (a.status === 'SCHEDULED' || a.status === 'IN_PROGRESS') {
                    <button class="action-btn mint" (click)="updateStatus(a, 'COMPLETED')" title="Mark complete">
                      <i class="bi bi-check-circle-fill"></i>
                    </button>
                    <button class="action-btn warning" (click)="updateStatus(a, 'CANCELLED')" title="Cancel">
                      <i class="bi bi-x-circle-fill"></i>
                    </button>
                  }
                </div>
              </div>
              <h3 class="audit-title">{{ a.title }}</h3>
              @if (a.description) {
                <p class="audit-desc">{{ a.description }}</p>
              }
              @if (a.auditorUserId) {
                <div class="auditor-tag">
                  <i class="bi bi-person-badge"></i> Auditor #{{ a.auditorUserId }}
                </div>
              }
            </div>
          }
        </div>
      }

      @if (showModal()) {
        <div class="modal-backdrop" (click)="closeModal()">
          <div class="modal" (click)="$event.stopPropagation()">
            <div class="modal-header">
              <h3 class="modal-title">Initiate Audit</h3>
              <button class="modal-close" (click)="closeModal()"><i class="bi bi-x"></i></button>
            </div>
            @if (formError()) {
              <div class="alert-error"><i class="bi bi-exclamation-triangle-fill"></i> {{ formError() }}</div>
            }
            <form [formGroup]="form" (ngSubmit)="doCreate()">
              <div class="form-group">
                <label class="form-label">Audit Title *</label>
                <input formControlName="title" type="text" class="form-control" placeholder="e.g. Annual Platform Compliance Audit" />
              </div>
              <div class="form-group">
                <label class="form-label">Description</label>
                <textarea formControlName="description" class="form-control" rows="3" placeholder="Scope and objectives..."></textarea>
              </div>
              <div class="form-group">
                <label class="form-label">Auditor User ID</label>
                <input formControlName="auditorUserId" type="number" class="form-control" placeholder="User ID of the auditor" />
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-ghost" (click)="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary" [disabled]="saving() || form.invalid">
                  @if (saving()) { <span class="spinner"></span> Creating... }
                  @else { <i class="bi bi-search"></i> Initiate }
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host{--accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);display:block;font-family:'Plus Jakarta Sans',sans-serif;}
    .page{display:flex;flex-direction:column;gap:1.5rem;}
    .page-head{display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap;}
    .eyebrow{display:block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;}
    .page-title{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0;}
    .page-desc{font-size:0.92rem;color:var(--text-muted);margin-top:6px;}
    .sum-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;}
    .sum-card{display:flex;flex-direction:column;align-items:center;padding:1.5rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;text-align:center;transition:all 0.25s;&:hover{transform:translateY(-3px);}i{font-size:1.75rem;margin-bottom:0.75rem;}.sum-val{font-family:'Fraunces',serif;font-size:2rem;font-weight:800;color:#fff;}.sum-label{font-size:0.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em;margin-top:4px;}}
    .sum-card[data-tone="blue"] i{color:var(--accent-light);}.sum-card[data-tone="mint"] i{color:var(--mint);}.sum-card[data-tone="gold"] i{color:var(--gold);}.sum-card[data-tone="rose"] i{color:var(--rose);}
    .audit-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1.25rem;}
    .audit-card{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.5rem;display:flex;flex-direction:column;gap:0.75rem;transition:all 0.25s;&:hover{border-color:rgba(46,123,246,0.3);transform:translateY(-3px);}}
    .ac-head{display:flex;justify-content:space-between;align-items:center;gap:1rem;}
    .ac-info{display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;}
    .audit-status{display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:100px;font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;}
    .as-scheduled{background:rgba(46,123,246,0.15);color:var(--accent-light);border:1px solid rgba(46,123,246,0.25);}
    .as-in-progress{background:rgba(245,158,11,0.15);color:#FCD34D;border:1px solid rgba(245,158,11,0.25);}
    .as-completed{background:rgba(16,185,129,0.15);color:#34D399;border:1px solid rgba(16,185,129,0.25);}
    .as-cancelled{background:rgba(239,68,68,0.15);color:#FCA5A5;border:1px solid rgba(239,68,68,0.25);}
    .audit-date{font-size:0.78rem;color:var(--text-muted);display:inline-flex;align-items:center;gap:5px;}
    .ac-actions{display:flex;gap:0.4rem;flex-shrink:0;}
    .action-btn{width:30px;height:30px;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:8px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:0.9rem;color:var(--text-muted);transition:all 0.2s;}
    .action-btn.mint:hover{background:rgba(0,201,167,0.15);color:var(--mint);border-color:rgba(0,201,167,0.3);}
    .action-btn.warning:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;border-color:rgba(239,68,68,0.3);}
    .audit-title{font-family:'Fraunces',serif;font-size:1.1rem;font-weight:700;color:#fff;margin:0;}
    .audit-desc{font-size:0.85rem;color:var(--text-muted);line-height:1.5;margin:0;}
    .auditor-tag{display:inline-flex;align-items:center;gap:6px;font-size:0.8rem;color:var(--text-muted);}
    .modal-backdrop{position:fixed;inset:0;background:rgba(5,10,24,0.8);backdrop-filter:blur(8px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;animation:fadeIn 0.2s ease;}
    .modal{background:#1A2F5E;border:1px solid rgba(255,255,255,0.1);border-radius:22px;padding:2rem;width:100%;max-width:520px;box-shadow:0 40px 80px rgba(0,0,0,0.5);animation:slideUp 0.25s ease;}
    .modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;}
    .modal-title{font-family:'Fraunces',serif;font-size:1.3rem;font-weight:700;color:#fff;margin:0;}
    .modal-close{width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--text-muted);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;transition:all 0.2s;&:hover{background:rgba(239,68,68,0.15);color:#FCA5A5;}}
    .alert-error{display:flex;align-items:center;gap:8px;padding:0.75rem 1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1.25rem;}
    .form-group{margin-bottom:1rem;}
    .form-label{display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em;}
    .form-control{width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:border-color 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:var(--accent);}}
    textarea.form-control{min-height:80px;resize:vertical;}
    .modal-footer{display:flex;gap:0.75rem;justify-content:flex-end;margin-top:1.5rem;}
    .btn{display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.25rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.2s;&:disabled{opacity:0.55;cursor:not-allowed;}}
    .btn-primary{background:linear-gradient(135deg,var(--accent),#1A5FD4);color:#fff;box-shadow:0 6px 18px rgba(46,123,246,0.3);&:hover:not(:disabled){transform:translateY(-2px);}}
    .btn-ghost{background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#fff;&:hover{background:rgba(255,255,255,0.1);}}
    .empty-state{padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;i{font-size:2.5rem;color:var(--text-muted);display:block;margin-bottom:1rem;}h3{font-family:'Fraunces',serif;font-size:1.2rem;color:#fff;margin-bottom:0.5rem;}p{font-size:0.875rem;color:var(--text-muted);}}
    .spinner{display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;}
    .ec-spin{display:inline-block;width:40px;height:40px;border:3px solid rgba(255,255,255,0.1);border-top-color:var(--accent);border-radius:50%;animation:spin 0.6s linear infinite;}
    .load-center{display:flex;justify-content:center;padding:3rem;}
    @media(max-width:768px){.sum-grid{grid-template-columns:repeat(2,1fr);}.audit-list{grid-template-columns:1fr;}}
    @keyframes spin{to{transform:rotate(360deg);}}.@keyframes fadeIn{from{opacity:0;}to{opacity:1;}}@keyframes slideUp{from{opacity:0;transform:translateY(24px);}to{opacity:1;transform:none;}}
  `],
})
export class AdminAuditsComponent implements OnInit {
  private auth     = inject(AuthService);
  private auditSvc = inject(AuditService);
  private toast    = inject(ToastService);
  private fb       = inject(FormBuilder);

  loading   = signal(true);
  saving    = signal(false);
  showModal = signal(false);
  audits    = signal<Audit[]>([]);
  formError = signal('');

  form = this.fb.nonNullable.group({
    title:        ['', Validators.required],
    description:  [''],
    auditorUserId: [null as unknown as number],
  });

  statusSummary = () => [
    { label: 'Scheduled',   tone: 'blue', icon: 'bi-calendar-check', count: this.audits().filter(a => a.status === 'SCHEDULED').length },
    { label: 'In Progress', tone: 'gold', icon: 'bi-hourglass-split', count: this.audits().filter(a => a.status === 'IN_PROGRESS').length },
    { label: 'Completed',   tone: 'mint', icon: 'bi-patch-check-fill', count: this.audits().filter(a => a.status === 'COMPLETED').length },
    { label: 'Cancelled',   tone: 'rose', icon: 'bi-x-circle-fill',   count: this.audits().filter(a => a.status === 'CANCELLED').length },
  ];

  statusIcon(s: AuditStatus): string {
    const m: Partial<Record<AuditStatus,string>> = {
      SCHEDULED:'bi-calendar-check', IN_PROGRESS:'bi-hourglass-split',
      COMPLETED:'bi-patch-check-fill', CANCELLED:'bi-x-circle-fill',
    };
    return m[s] ?? 'bi-search';
  }

  ngOnInit(): void {
    this.auditSvc.getAll().subscribe({
      next: r => { if (r.success) this.audits.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  openCreate(): void { this.form.reset(); this.formError.set(''); this.showModal.set(true); }
  closeModal(): void { this.showModal.set(false); }

  doCreate(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving.set(true);
    const v = this.form.getRawValue();
    this.auditSvc.create({ ...v, auditorUserId: v.auditorUserId || undefined }).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.audits.update(arr => [r.data, ...arr]);
          this.closeModal();
          this.toast.success('Audit initiated', `"${r.data.title}" has been created.`);
        } else { this.formError.set(r.message ?? 'Failed'); }
      },
      error: err => { this.saving.set(false); this.formError.set(err?.error?.message ?? 'Failed'); },
    });
  }

  updateStatus(a: Audit, status: string): void {
    this.auditSvc.updateStatus(a.auditId, status).subscribe({
      next: r => {
        if (r.success) {
          this.audits.update(arr => arr.map(x => x.auditId === a.auditId ? { ...x, status: status as AuditStatus } : x));
          this.toast.success('Updated', `Audit marked as ${status}.`);
        }
      },
    });
  }
}
