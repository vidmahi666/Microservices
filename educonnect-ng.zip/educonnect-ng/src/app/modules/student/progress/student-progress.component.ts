import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { ProgressService } from '../../../core/services/index';
import { Progress } from '../../../core/models';

@Component({
  selector: 'app-student-progress',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Learning Analytics</span>
          <h1 class="page-title">My Progress</h1>
          <p class="page-desc">Track your learning journey across all courses</p>
        </div>
      </header>

      <!-- Summary cards -->
      <div class="summary-grid">
        <div class="sum-card sum-blue">
          <div class="sum-icon"><i class="bi bi-book-fill"></i></div>
          <div class="sum-body">
            <div class="sum-label">Total Courses</div>
            <div class="sum-value">{{ progressList().length }}</div>
          </div>
        </div>
        <div class="sum-card sum-mint">
          <div class="sum-icon"><i class="bi bi-patch-check-fill"></i></div>
          <div class="sum-body">
            <div class="sum-label">Completed</div>
            <div class="sum-value">{{ completedCount() }}</div>
          </div>
        </div>
        <div class="sum-card sum-gold">
          <div class="sum-icon"><i class="bi bi-activity"></i></div>
          <div class="sum-body">
            <div class="sum-label">In Progress</div>
            <div class="sum-value">{{ inProgressCount() }}</div>
          </div>
        </div>
        <div class="sum-card sum-purple">
          <div class="sum-icon"><i class="bi bi-bar-chart-line-fill"></i></div>
          <div class="sum-body">
            <div class="sum-label">Overall %</div>
            <div class="sum-value">{{ overallPct() }}%</div>
          </div>
        </div>
      </div>

      <!-- Loading -->
      @if (loading()) {
        <div class="loading-box"><span class="spinner spinner-lg"></span></div>
      }

      <!-- Overall ring + per course list -->
      @if (!loading() && progressList().length > 0) {
        <div class="prog-layout">
          <!-- Overall ring -->
          <div class="ring-card">
            <h3 class="ring-heading">Overall Progress</h3>
            <div class="ring-wrap">
              <svg viewBox="0 0 160 160" class="ring-svg">
                <circle cx="80" cy="80" r="68" class="ring-bg"></circle>
                <circle cx="80" cy="80" r="68" class="ring-fg"
                  [style.stroke-dashoffset]="427 * (1 - overallPct()/100)"></circle>
              </svg>
              <div class="ring-center">
                <span class="ring-pct">{{ overallPct() }}%</span>
                <span class="ring-label">Complete</span>
              </div>
            </div>
            <div class="ring-legend">
              <div class="leg-item"><div class="dot dot-mint"></div> Completed ({{ completedCount() }})</div>
              <div class="leg-item"><div class="dot dot-blue"></div> In Progress ({{ inProgressCount() }})</div>
            </div>
          </div>

          <!-- Course list -->
          <div class="courses-section">
            <h3 class="section-heading">Course Breakdown</h3>
            @for (p of progressList(); track p.progressId; let i = $index) {
              <div class="prog-row">
                <div class="pr-left">
                  <div class="pr-icon" [attr.data-color]="colors[i % colors.length]">
                    <i class="bi" [ngClass]="icons[i % icons.length]"></i>
                  </div>
                  <div class="pr-info">
                    <div class="pr-title">{{ p.courseTitle ?? 'Course #' + p.courseId }}</div>
                    <div class="pr-meta">Updated {{ p.updatedAt | date:'mediumDate' }}</div>
                  </div>
                </div>
                <div class="pr-right">
                  <div class="pr-bar-wrap">
                    <div class="pr-bar-track">
                      <div class="pr-bar-fill" [style.width.%]="p.completionPercentage"
                        [attr.data-color]="colors[i % colors.length]"></div>
                    </div>
                    <span class="pr-pct">{{ p.completionPercentage }}%</span>
                  </div>
                  <span class="pr-status" [class]="'ps-' + p.status.toLowerCase()">{{ p.status }}</span>
                </div>
              </div>
            }
          </div>
        </div>
      }

      @if (!loading() && progressList().length === 0) {
        <div class="empty-box">
          <i class="bi bi-bar-chart"></i>
          <h3>No progress tracked yet</h3>
          <p>Enroll in courses to start tracking your learning progress.</p>
        </div>
      }
    </div>
  `,
  styles: [`
    :host { display:block;font-family:'Plus Jakarta Sans',sans-serif; --accent:#2E7BF6;--mint:#00C9A7;--gold:#F0A500;--purple:#A78BFA;--text-muted:#8898B3;--border:rgba(255,255,255,0.08); }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .eyebrow { display:inline-block;font-size:0.72rem;font-weight:700;color:#4F95FF;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }

    .summary-grid { display:grid;grid-template-columns:repeat(4,1fr);gap:1rem; }
    .sum-card { display:flex;align-items:center;gap:1rem;padding:1.25rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:16px;transition:all 0.3s;&:hover{transform:translateY(-3px);} }
    .sum-icon { width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0; }
    .sum-label { font-size:0.72rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em; }
    .sum-value { font-family:'Fraunces',serif;font-size:1.8rem;font-weight:800;color:#fff;line-height:1.1;letter-spacing:-0.02em; }
    .sum-blue   .sum-icon { background:rgba(46,123,246,0.15);color:#4F95FF; }
    .sum-mint   .sum-icon { background:rgba(0,201,167,0.15);color:var(--mint); }
    .sum-gold   .sum-icon { background:rgba(240,165,0,0.15);color:var(--gold); }
    .sum-purple .sum-icon { background:rgba(167,139,250,0.15);color:var(--purple); }

    .prog-layout { display:grid;grid-template-columns:300px 1fr;gap:1.5rem;align-items:start; }
    .ring-card { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.5rem;display:flex;flex-direction:column;gap:1.25rem; }
    .ring-heading { font-family:'Fraunces',serif;font-size:1.1rem;font-weight:700;color:#fff;margin:0; }
    .ring-wrap { position:relative;display:flex;justify-content:center; }
    .ring-svg { width:180px;height:180px;transform:rotate(-90deg); }
    .ring-bg  { fill:none;stroke:rgba(255,255,255,0.06);stroke-width:14; }
    .ring-fg  { fill:none;stroke:url(#ringGrad);stroke-width:14;stroke-linecap:round;stroke-dasharray:427;filter:drop-shadow(0 0 12px rgba(0,201,167,0.4));transition:stroke-dashoffset 0.8s ease; }
    .ring-center { position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;.ring-pct{font-family:'Fraunces',serif;font-size:2.4rem;font-weight:800;color:#fff;letter-spacing:-0.02em;line-height:1;}.ring-label{font-size:0.75rem;color:var(--text-muted);margin-top:4px;} }
    .ring-legend { display:flex;flex-direction:column;gap:0.5rem; }
    .leg-item { display:flex;align-items:center;gap:8px;font-size:0.82rem;color:var(--text-muted); }
    .dot { width:10px;height:10px;border-radius:50%;flex-shrink:0; }
    .dot-mint { background:var(--mint); }
    .dot-blue { background:#4F95FF; }

    .courses-section { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.5rem;display:flex;flex-direction:column;gap:1rem; }
    .section-heading { font-family:'Fraunces',serif;font-size:1.1rem;font-weight:700;color:#fff;margin:0 0 0.25rem; }
    .prog-row { display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:0.875rem;border-radius:12px;border:1px solid var(--border);transition:all 0.2s;&:hover{background:rgba(255,255,255,0.03);} }
    .pr-left { display:flex;align-items:center;gap:0.875rem;flex:1;min-width:0; }
    .pr-icon { width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.05rem;flex-shrink:0; }
    .pr-icon[data-color="blue"]   { background:rgba(46,123,246,0.15);color:#4F95FF; }
    .pr-icon[data-color="mint"]   { background:rgba(0,201,167,0.15);color:var(--mint); }
    .pr-icon[data-color="gold"]   { background:rgba(240,165,0,0.15);color:var(--gold); }
    .pr-icon[data-color="purple"] { background:rgba(167,139,250,0.15);color:var(--purple); }
    .pr-title { font-size:0.92rem;font-weight:700;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }
    .pr-meta  { font-size:0.75rem;color:var(--text-muted);margin-top:2px; }
    .pr-right { display:flex;flex-direction:column;align-items:flex-end;gap:0.4rem;flex-shrink:0;min-width:160px; }
    .pr-bar-wrap { display:flex;align-items:center;gap:0.6rem;width:100%; }
    .pr-bar-track { flex:1;height:6px;background:rgba(255,255,255,0.06);border-radius:100px;overflow:hidden; }
    .pr-bar-fill { height:100%;border-radius:100px;transition:width 0.8s ease; }
    .pr-bar-fill[data-color="blue"]   { background:linear-gradient(90deg,#2E7BF6,#4F95FF); }
    .pr-bar-fill[data-color="mint"]   { background:linear-gradient(90deg,var(--mint),#00E5C8); }
    .pr-bar-fill[data-color="gold"]   { background:linear-gradient(90deg,var(--gold),#FFD44D); }
    .pr-bar-fill[data-color="purple"] { background:linear-gradient(90deg,var(--purple),#C4B2FF); }
    .pr-pct { font-size:0.82rem;font-weight:700;color:#fff;flex-shrink:0; }
    .pr-status { font-size:0.7rem;font-weight:700;text-transform:uppercase;padding:3px 9px;border-radius:100px;letter-spacing:0.04em; }
    .ps-completed   { background:rgba(16,185,129,0.15);color:#34D399; }
    .ps-in_progress { background:rgba(46,123,246,0.15);color:#4F95FF; }
    .ps-dropped     { background:rgba(239,68,68,0.15);color:#FCA5A5; }

    .empty-box { padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.02);border:1px dashed var(--border);border-radius:18px;i{font-size:2.5rem;color:var(--text-muted);}h3{font-family:'Fraunces',serif;font-size:1.25rem;color:#fff;margin:1rem 0 0.4rem;}p{font-size:0.875rem;color:var(--text-muted);} }
    .loading-box { display:flex;justify-content:center;padding:4rem; }
    .spinner { display:inline-block;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;width:18px;height:18px; }
    .spinner-lg { width:40px;height:40px;border-width:3px; }
    @media(max-width:900px){.summary-grid{grid-template-columns:repeat(2,1fr)}.prog-layout{grid-template-columns:1fr}}
    @media(max-width:560px){.summary-grid{grid-template-columns:1fr}}
    @keyframes spin { to{transform:rotate(360deg);} }
  `],
})
export class StudentProgressComponent implements OnInit {
  private auth        = inject(AuthService);
  private progressSvc = inject(ProgressService);

  loading      = signal(true);
  progressList = signal<Progress[]>([]);

  completedCount  = computed(() => this.progressList().filter(p => p.status === 'COMPLETED').length);
  inProgressCount = computed(() => this.progressList().filter(p => p.status === 'IN_PROGRESS').length);
  overallPct = computed(() => {
    const list = this.progressList();
    if (!list.length) return 0;
    return Math.round(list.reduce((s, p) => s + p.completionPercentage, 0) / list.length);
  });

  colors = ['blue','mint','gold','purple','blue','mint','gold'];
  icons  = ['bi-book','bi-code-slash','bi-bar-chart','bi-flask','bi-camera','bi-globe','bi-music-note-beamed'];

  ngOnInit(): void {
    const sId = this.auth.userId() ?? 1;
    this.progressSvc.getByStudent(sId).subscribe({
      next: r => { if (r.success) this.progressList.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
