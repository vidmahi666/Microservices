import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { StudentService, ToastService } from '../../../core/services/index';
import { Student } from '../../../core/models';

@Component({
  selector: 'app-student-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page">
      <header class="page-head">
        <div>
          <span class="eyebrow">Account</span>
          <h1 class="page-title">My Profile</h1>
          <p class="page-desc">Manage your personal information</p>
        </div>
      </header>

      <div class="profile-layout">
        <!-- Avatar card -->
        <div class="avatar-card">
          <div class="big-avatar">{{ initials() }}</div>
          <h3 class="av-name">{{ auth.user()?.name }}</h3>
          <p class="av-email">{{ auth.user()?.email }}</p>
          <span class="role-badge">🎓 Student</span>
          <div class="divider"></div>
          <div class="quick-stats">
            <div class="qs-item">
              <span class="qs-label">Status</span>
              <span class="qs-val status-active">Active</span>
            </div>
            <div class="qs-item">
              <span class="qs-label">Role</span>
              <span class="qs-val">Student</span>
            </div>
          </div>
        </div>

        <!-- Edit form -->
        <div class="form-card">
          <h3 class="form-section-title">Personal Information</h3>
          <p class="form-section-desc">Update your profile details below.</p>

          @if (loading()) {
            <div style="display:flex;justify-content:center;padding:3rem"><span class="spinner spinner-lg"></span></div>
          } @else {
            <form [formGroup]="form" (ngSubmit)="save()">
              <div class="two-col">
                <div class="form-group">
                  <label class="form-label">Full Name</label>
                  <div class="input-wrapper">
                    <i class="bi bi-person input-icon"></i>
                    <input formControlName="name" type="text" class="form-control has-icon" placeholder="Full name" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="form-label">Date of Birth</label>
                  <input formControlName="dob" type="date" class="form-control" />
                </div>
                <div class="form-group">
                  <label class="form-label">Gender</label>
                  <select formControlName="gender" class="form-select">
                    <option value="">Select gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                    <option value="Prefer not to say">Prefer not to say</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Contact Info</label>
                  <div class="input-wrapper">
                    <i class="bi bi-telephone input-icon"></i>
                    <input formControlName="contactInfo" type="text" class="form-control has-icon" placeholder="+91 9999999999" />
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Address</label>
                <textarea formControlName="address" class="form-control" rows="3" placeholder="Your address..."></textarea>
              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-primary" [disabled]="saving()">
                  @if (saving()) { <span class="spinner"></span> }
                  <i class="bi bi-check2-circle"></i> Save Changes
                </button>
              </div>
            </form>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host { display:block;font-family:'Plus Jakarta Sans',sans-serif; --accent:#2E7BF6;--mint:#00C9A7;--text-muted:#8898B3;--border:rgba(255,255,255,0.08); }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .eyebrow { display:inline-block;font-size:0.72rem;font-weight:700;color:#4F95FF;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }
    .profile-layout { display:grid;grid-template-columns:280px 1fr;gap:1.5rem;align-items:start; }
    .avatar-card { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:1.75rem;display:flex;flex-direction:column;align-items:center;text-align:center;gap:0.75rem; }
    .big-avatar { width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,#2E7BF6,#00C9A7);display:flex;align-items:center;justify-content:center;font-family:'Fraunces',serif;font-size:2rem;font-weight:800;color:#fff;box-shadow:0 10px 28px rgba(46,123,246,0.35); }
    .av-name  { font-family:'Fraunces',serif;font-size:1.2rem;font-weight:700;color:#fff;margin:0; }
    .av-email { font-size:0.82rem;color:var(--text-muted); }
    .role-badge { padding:5px 14px;background:rgba(0,201,167,0.12);border:1px solid rgba(0,201,167,0.25);border-radius:100px;color:var(--mint);font-size:0.8rem;font-weight:700; }
    .divider { width:100%;height:1px;background:var(--border); }
    .quick-stats { width:100%;display:flex;flex-direction:column;gap:0.625rem; }
    .qs-item { display:flex;justify-content:space-between;font-size:0.85rem; }
    .qs-label { color:var(--text-muted); }
    .qs-val { color:#fff;font-weight:600; }
    .status-active { color:#34D399; }
    .form-card { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;padding:2rem; }
    .form-section-title { font-family:'Fraunces',serif;font-size:1.2rem;font-weight:700;color:#fff;margin:0 0 0.3rem; }
    .form-section-desc { font-size:0.875rem;color:var(--text-muted);margin-bottom:1.75rem; }
    .two-col { display:grid;grid-template-columns:1fr 1fr;gap:0.75rem 1.25rem; }
    .form-group { margin-bottom:0.75rem; }
    .form-label { display:block;font-size:0.78rem;font-weight:600;color:var(--text-muted);margin-bottom:0.4rem;text-transform:uppercase;letter-spacing:0.06em; }
    .input-wrapper { position:relative; }
    .input-icon { position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:0.9rem;pointer-events:none; }
    .form-control, .form-select { width:100%;padding:0.7rem 0.9rem;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.9rem;font-family:inherit;outline:none;transition:all 0.2s;&::placeholder{color:rgba(136,152,179,0.6);}&:focus{border-color:#2E7BF6;background:rgba(46,123,246,0.06);}&.has-icon{padding-left:2.4rem;}resize:vertical;min-height:80px; }
    .form-select { cursor:pointer;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M6 8L0 0h12z' fill='%238898B3'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;padding-right:2rem;option{background:#1A2F5E;} }
    .form-actions { display:flex;justify-content:flex-end;margin-top:1.25rem; }
    .btn { display:inline-flex;align-items:center;gap:8px;padding:0.65rem 1.2rem;font-family:inherit;font-size:0.875rem;font-weight:700;border:none;border-radius:10px;cursor:pointer;transition:all 0.25s;&:disabled{opacity:0.55;cursor:not-allowed;} }
    .btn-primary { background:linear-gradient(135deg,var(--accent),#1A5FD4);color:#fff;box-shadow:0 8px 22px rgba(46,123,246,0.3);&:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 14px 32px rgba(46,123,246,0.5);} }
    .spinner { display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite; }
    .spinner-lg { width:40px;height:40px;border-width:3px; }
    @media(max-width:768px){.profile-layout{grid-template-columns:1fr}.two-col{grid-template-columns:1fr}}
    @keyframes spin { to{transform:rotate(360deg);} }
  `],
})
export class StudentProfileComponent implements OnInit {
  auth       = inject(AuthService);
  studentSvc = inject(StudentService);
  toast      = inject(ToastService);
  fb         = inject(FormBuilder);

  loading = signal(true);
  saving  = signal(false);
  student = signal<Student | null>(null);

  initials = () => {
    const n = this.auth.user()?.name ?? '';
    return n.split(' ').slice(0,2).map(w => w[0]).join('').toUpperCase();
  };

  form = this.fb.nonNullable.group({
    name:        [''],
    dob:         [''],
    gender:      [''],
    address:     [''],
    contactInfo: [''],
  });

  ngOnInit(): void {
    const uid = this.auth.userId() ?? 1;
    this.studentSvc.getByUserId(uid).subscribe({
      next: r => {
        if (r.success && r.data) {
          this.student.set(r.data);
          this.form.patchValue(r.data);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  save(): void {
    const s = this.student();
    if (!s) return;
    this.saving.set(true);
    this.studentSvc.updateProfile(s.userId, this.form.getRawValue()).subscribe({
      next: r => {
        this.saving.set(false);
        if (r.success) {
          this.toast.success('Profile updated!', 'Your changes have been saved.');
        } else {
          this.toast.error('Update failed', r.message);
        }
      },
      error: err => { this.saving.set(false); this.toast.error('Error', err?.error?.message); },
    });
  }
}
