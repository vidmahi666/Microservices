import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CourseService, EnrollmentService } from '../../../core/services/index';
import { ToastService } from '../../../core/services/index';
import { Course, Enrollment } from '../../../core/models';

@Component({
  selector: 'app-student-courses',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page">

      <header class="page-head">
        <div>
          <span class="eyebrow">My Learning</span>
          <h1 class="page-title">My Courses</h1>
          <p class="page-desc">{{ enrolledIds().size }} enrolled · {{ allCourses().length }} available</p>
        </div>
        <div class="local-search">
          <i class="bi bi-funnel"></i>
          <input type="text" [(ngModel)]="search" placeholder="Filter courses..." class="ls-input" />
        </div>
      </header>

      <!-- Tabs -->
      <div class="tabs">
        @for (t of tabs; track t.key) {
          <button class="tab" [class.active]="activeTab === t.key" (click)="activeTab = t.key">
            {{ t.label }} <span class="tab-count">{{ tabCount(t.key) }}</span>
          </button>
        }
      </div>

      @if (loading()) {
        <div class="loading-overlay"><span class="spinner spinner-lg"></span></div>
      } @else if (filtered().length === 0) {
        <div class="empty-box">
          <i class="bi bi-search"></i>
          <h3>No courses found</h3>
          <p>Try adjusting your filters or search query.</p>
        </div>
      } @else {
        <div class="courses-grid">
          @for (c of filtered(); track c.courseId) {
            <article class="course-card" [attr.data-color]="colorOf(c)">
              <div class="thumb">
                <div class="thumb-icon"><i class="bi" [ngClass]="iconOf(c)"></i></div>
                <div class="thumb-pattern"></div>
                @if (isNew(c)) { <span class="tag">New</span> }
                <span class="level" data-level="beginner">{{ c.status }}</span>
              </div>
              <div class="card-body">
                <div class="category">{{ c.status }}</div>
                <h3 class="course-title">{{ c.title }}</h3>
                <div class="instructor"><i class="bi bi-person-circle"></i> Teacher #{{ c.teacherUserId }}</div>
                <div class="meta-row">
                  <span><i class="bi bi-calendar"></i> {{ c.startDate | date:'medShortDate' }}</span>
                  <span><i class="bi bi-flag"></i> {{ c.endDate | date:'medShortDate' }}</span>
                </div>
                <p class="course-desc">{{ c.description | slice:0:80 }}{{ c.description.length > 80 ? '...' : '' }}</p>

                @if (enrolledIds().has(c.courseId)) {
                  <div class="completed-badge"><i class="bi bi-patch-check-fill"></i> Enrolled</div>
                  <button class="card-action outline" routerLink="/student/progress">
                    <i class="bi bi-bar-chart"></i> View Progress
                  </button>
                } @else {
                  <button class="card-action mint"
                    [disabled]="enrolling() === c.courseId || c.status !== 'ACTIVE'"
                    (click)="enroll(c)">
                    @if (enrolling() === c.courseId) { <span class="spinner"></span> }
                    Enroll Now <i class="bi bi-arrow-right"></i>
                  </button>
                }
              </div>
            </article>
          }
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      --accent:#2E7BF6;--accent-light:#4F95FF;--gold:#F0A500;--mint:#00C9A7;
      --purple:#A78BFA;--rose:#FB7185;--text-muted:#8898B3;--border:rgba(255,255,255,0.08);
      display:block; font-family:'Plus Jakarta Sans',sans-serif;
    }
    .page { display:flex;flex-direction:column;gap:1.5rem; }
    .page-head { display:flex;justify-content:space-between;align-items:flex-end;gap:1.5rem;flex-wrap:wrap; }
    .eyebrow { display:inline-block;font-size:0.72rem;font-weight:700;color:var(--accent-light);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem; }
    .page-title { font-family:'Fraunces',serif;font-size:2.1rem;font-weight:800;color:#fff;letter-spacing:-0.02em;margin:0; }
    .page-desc { font-size:0.92rem;color:var(--text-muted);margin-top:6px; }
    .local-search { position:relative;min-width:280px; i{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:0.9rem;} }
    .ls-input { width:100%;padding:0.65rem 0.9rem 0.65rem 2.3rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;color:#fff;font-size:0.88rem;font-family:inherit;outline:none;transition:all 0.2s;&::placeholder{color:rgba(136,152,179,0.7);}&:focus{border-color:var(--accent);background:rgba(46,123,246,0.08);} }
    .tabs { display:flex;gap:6px;padding:6px;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:12px;width:fit-content;overflow-x:auto;max-width:100%; }
    .tab { display:inline-flex;align-items:center;gap:8px;padding:0.55rem 1rem;background:transparent;border:none;color:var(--text-muted);font-size:0.85rem;font-weight:600;font-family:inherit;border-radius:8px;cursor:pointer;transition:all 0.2s;white-space:nowrap; .tab-count{font-size:0.72rem;padding:2px 8px;border-radius:100px;background:rgba(255,255,255,0.06);color:var(--text-muted);} &:hover{color:#fff;} &.active{background:linear-gradient(135deg,rgba(46,123,246,0.25),rgba(0,201,167,0.15));color:#fff;box-shadow:0 4px 12px rgba(46,123,246,0.22);.tab-count{background:rgba(255,255,255,0.12);color:#fff;}} }
    .courses-grid { display:grid;grid-template-columns:repeat(3,1fr);gap:1.25rem; }
    .course-card { background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:18px;overflow:hidden;transition:all 0.3s ease;display:flex;flex-direction:column;&:hover{transform:translateY(-5px);border-color:rgba(46,123,246,0.35);box-shadow:0 20px 45px rgba(0,0,0,0.35);} }
    .thumb { position:relative;height:120px;display:flex;align-items:center;justify-content:center;overflow:hidden; .thumb-icon{position:relative;z-index:2;width:58px;height:58px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;background:rgba(255,255,255,0.12);color:#fff;backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,0.18);} .thumb-pattern{position:absolute;inset:0;background-image:radial-gradient(circle at 20% 30%,rgba(255,255,255,0.15) 0%,transparent 50%),radial-gradient(circle at 80% 70%,rgba(255,255,255,0.08) 0%,transparent 40%);} .tag{position:absolute;top:12px;left:12px;z-index:3;padding:3px 10px;font-size:0.66rem;font-weight:700;letter-spacing:0.05em;text-transform:uppercase;background:var(--gold);color:#1a1300;border-radius:100px;} .level{position:absolute;top:12px;right:12px;z-index:3;padding:3px 10px;font-size:0.66rem;font-weight:700;letter-spacing:0.05em;text-transform:uppercase;background:rgba(0,0,0,0.45);color:#fff;border-radius:100px;backdrop-filter:blur(4px);} }
    .course-card[data-color="blue"]   .thumb { background:linear-gradient(135deg,#2E7BF6,#1A5FD4); }
    .course-card[data-color="mint"]   .thumb { background:linear-gradient(135deg,#00C9A7,#0E6D5B); }
    .course-card[data-color="gold"]   .thumb { background:linear-gradient(135deg,#F0A500,#B87A00); }
    .course-card[data-color="purple"] .thumb { background:linear-gradient(135deg,#A78BFA,#6D4FD4); }
    .course-card[data-color="rose"]   .thumb { background:linear-gradient(135deg,#FB7185,#C4415A); }
    .card-body { padding:1.25rem;display:flex;flex-direction:column;gap:0.55rem;flex:1; }
    .category { font-size:0.7rem;font-weight:700;letter-spacing:0.08em;color:var(--accent-light);text-transform:uppercase; }
    .course-title { font-size:1.02rem;font-weight:700;color:#fff;margin:0;line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden; }
    .instructor { font-size:0.82rem;color:var(--text-muted);display:inline-flex;align-items:center;gap:6px; }
    .meta-row { display:flex;gap:0.9rem;font-size:0.78rem;color:var(--text-muted); span{display:inline-flex;align-items:center;gap:5px;} i{color:var(--accent-light);} }
    .course-desc { font-size:0.82rem;color:var(--text-muted);line-height:1.5; }
    .completed-badge { display:inline-flex;align-items:center;gap:6px;padding:5px 10px;background:rgba(0,201,167,0.15);border:1px solid rgba(0,201,167,0.3);border-radius:100px;color:var(--mint);font-size:0.75rem;font-weight:700;width:fit-content;margin-top:0.2rem; }
    .card-action { margin-top:auto;padding:0.7rem 1rem;background:linear-gradient(135deg,var(--accent),#1A5FD4);border:none;border-radius:10px;color:#fff;font-size:0.88rem;font-weight:700;font-family:inherit;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:6px;transition:all 0.25s;box-shadow:0 6px 18px rgba(46,123,246,0.28);&:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 12px 28px rgba(46,123,246,0.45);}&:disabled{opacity:0.5;cursor:not-allowed;transform:none;} &.outline{background:transparent;border:1px solid rgba(0,201,167,0.4);color:var(--mint);box-shadow:none;&:hover{background:rgba(0,201,167,0.08);transform:translateY(-2px);}} &.mint{background:linear-gradient(135deg,var(--mint),#00856D);box-shadow:0 6px 18px rgba(0,201,167,0.28);&:hover:not(:disabled){box-shadow:0 12px 28px rgba(0,201,167,0.45);}} }
    .empty-box { padding:4rem 2rem;text-align:center;background:rgba(255,255,255,0.03);border:1px dashed var(--border);border-radius:18px; i{font-size:2.5rem;color:var(--text-muted);} h3{font-family:'Fraunces',serif;font-size:1.3rem;color:#fff;margin:1rem 0 0.4rem;} p{font-size:0.9rem;color:var(--text-muted);} }
    .loading-overlay { display:flex;justify-content:center;padding:4rem; }
    .spinner { display:inline-block;border:2px solid rgba(255,255,255,0.15);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite; }
    .spinner { width:18px;height:18px; } .spinner-lg { width:40px;height:40px;border-width:3px; }
    @media(max-width:1100px){.courses-grid{grid-template-columns:repeat(2,1fr);}}
    @media(max-width:640px){.courses-grid{grid-template-columns:1fr;}.page-title{font-size:1.7rem;}}
    @keyframes spin { to{transform:rotate(360deg);} }
  `],
})
export class StudentCoursesComponent implements OnInit {
  private auth      = inject(AuthService);
  private courseSvc = inject(CourseService);
  private enrollSvc = inject(EnrollmentService);
  private toast     = inject(ToastService);

  loading    = signal(true);
  enrolling  = signal<number | null>(null);
  allCourses = signal<Course[]>([]);
  enrolledIds = signal<Set<number>>(new Set());
  search     = '';
  activeTab  = 'all';

  tabs = [
    { key: 'all',      label: 'All Courses' },
    { key: 'enrolled', label: 'Enrolled' },
    { key: 'active',   label: 'Active' },
  ];

  private COLORS = ['blue','mint','gold','purple','rose'];
  private ICONS  = ['bi-book','bi-code-slash','bi-bar-chart-line','bi-flask','bi-music-note-beamed','bi-camera','bi-globe'];

  colorOf(c: Course): string { return this.COLORS[c.courseId % this.COLORS.length]; }
  iconOf(c: Course):  string { return this.ICONS[c.courseId  % this.ICONS.length]; }
  isNew(c: Course): boolean {
    const d = new Date(c.createdAt ?? '');
    return !isNaN(d.getTime()) && (Date.now() - d.getTime()) < 7 * 86400000;
  }

  tabCount(key: string): number {
    if (key === 'all')      return this.allCourses().length;
    if (key === 'enrolled') return this.enrolledIds().size;
    if (key === 'active')   return this.allCourses().filter(c => c.status === 'ACTIVE').length;
    return 0;
  }

  filtered = computed(() => {
    let list = this.allCourses();
    if (this.activeTab === 'enrolled') list = list.filter(c => this.enrolledIds().has(c.courseId));
    if (this.activeTab === 'active')   list = list.filter(c => c.status === 'ACTIVE');
    if (this.search.trim()) {
      const q = this.search.toLowerCase();
      list = list.filter(c => c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q));
    }
    return list;
  });

  ngOnInit(): void {
    this.courseSvc.getAll().subscribe({
      next: r => { if (r.success) this.allCourses.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
    const sId = this.auth.userId() ?? 1;
    this.enrollSvc.getByStudent(sId).subscribe({
      next: r => { if (r.success) this.enrolledIds.set(new Set((r.data ?? []).map(e => e.courseId))); },
    });
  }

  enroll(c: Course): void {
    const sId = this.auth.userId() ?? 1;
    this.enrolling.set(c.courseId);
    this.enrollSvc.enroll({ studentId: sId, courseId: c.courseId }).subscribe({
      next: r => {
        this.enrolling.set(null);
        if (r.success) {
          this.enrolledIds.update(s => { s.add(c.courseId); return new Set(s); });
          this.toast.success('Enrolled!', `You are now enrolled in "${c.title}"`);
        } else {
          this.toast.error('Enroll failed', r.message);
        }
      },
      error: err => { this.enrolling.set(null); this.toast.error('Enroll failed', err?.error?.message); },
    });
  }
}
