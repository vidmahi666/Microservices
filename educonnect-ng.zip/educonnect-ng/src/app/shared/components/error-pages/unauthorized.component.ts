import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-unauthorized',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="error-page">
      <div class="blob blob-1"></div>
      <div class="blob blob-2"></div>
      <div class="error-card">
        <div class="err-icon"><i class="bi bi-shield-exclamation"></i></div>
        <h1>Access Denied</h1>
        <p>You don't have permission to view this page.<br>Contact your administrator if you believe this is an error.</p>
        <div class="err-actions">
          <button class="btn btn-ghost" (click)="back()">← Go Back</button>
          <button class="btn btn-primary" (click)="home()">Go to Dashboard</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .error-page {
      min-height: 100vh; background: #0D1B3E;
      display: flex; align-items: center; justify-content: center;
      padding: 2rem; position: relative; overflow: hidden;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .blob { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.12; }
    .blob-1 { width: 500px; height: 500px; background: radial-gradient(circle, #2E7BF6, transparent); top: -100px; left: -100px; }
    .blob-2 { width: 350px; height: 350px; background: radial-gradient(circle, #00C9A7, transparent); bottom: -50px; right: -50px; }
    .error-card { text-align: center; max-width: 480px; position: relative; z-index: 1; animation: slideUp 0.4s ease; }
    .err-icon { width: 72px; height: 72px; background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.25); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem; font-size: 2rem; color: #FCA5A5; }
    h1 { font-family: 'Fraunces', serif; font-size: 2.2rem; font-weight: 800; color: #fff; margin-bottom: 0.75rem; }
    p { color: #8898B3; font-size: 0.95rem; line-height: 1.7; }
    .err-actions { display: flex; gap: 0.75rem; justify-content: center; margin-top: 2rem; flex-wrap: wrap; }
    @keyframes slideUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: none; } }
  `],
})
export class UnauthorizedComponent {
  private auth = inject(AuthService);
  back(): void { history.back(); }
  home(): void { if (this.auth.isLoggedIn()) window.location.href = this.auth.dashboardRoute(); else window.location.href = '/login'; }
}
