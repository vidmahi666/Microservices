import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../../core/services/index';

@Component({
  selector: 'app-toast-container',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-container">
      @for (t of toastSvc.toasts(); track t.id) {
        <div class="toast" [class]="'toast-' + t.type">
          <i class="bi toast-icon"
             [ngClass]="{
               'bi-check-circle-fill': t.type === 'success',
               'bi-x-circle-fill': t.type === 'error',
               'bi-info-circle-fill': t.type === 'info',
               'bi-exclamation-triangle-fill': t.type === 'warning'
             }"></i>
          <div class="toast-body">
            <div class="toast-title">{{ t.title }}</div>
            @if (t.message) { <div class="toast-msg">{{ t.message }}</div> }
          </div>
          <button class="toast-close" (click)="toastSvc.remove(t.id)"><i class="bi bi-x"></i></button>
        </div>
      }
    </div>
  `,
})
export class ToastContainerComponent {
  toastSvc = inject(ToastService);
}
