import { Component, signal, computed, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { TopbarComponent } from '../topbar/topbar.component';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, CommonModule, SidebarComponent, TopbarComponent],
  template: `
    <div class="dash-shell" [class.collapsed]="collapsed()">
      <app-sidebar [collapsed]="collapsed()" (toggleSidebar)="collapsed.update(v => !v)" />
      <div class="main-area">
        <app-topbar [collapsed]="collapsed()" (toggleSidebar)="collapsed.update(v => !v)" />
        <main class="content">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
  styles: [`
    :host {
      --navy-deep: #0A1530;
      --navy:      #0D1B3E;
      --border:    rgba(255,255,255,0.08);
    }
    .dash-shell {
      min-height: 100vh;
      background: var(--navy-deep);
      color: #fff;
      display: grid;
      grid-template-columns: 260px 1fr;
      transition: grid-template-columns 0.25s ease;
      &.collapsed { grid-template-columns: 82px 1fr; }
    }
    .main-area { display: flex; flex-direction: column; min-width: 0; }
    .content {
      flex: 1;
      padding: 2rem 2rem 3rem;
      max-width: 1400px;
      width: 100%;
      margin: 0 auto;
    }
    @media (max-width: 900px) {
      .dash-shell { grid-template-columns: 82px 1fr; }
      .content { padding: 1.25rem; }
    }
    @media (max-width: 560px) {
      .dash-shell { grid-template-columns: 1fr; }
      .content { padding: 1rem; }
    }
  `],
})
export class ShellComponent {
  collapsed = signal(false);
}
