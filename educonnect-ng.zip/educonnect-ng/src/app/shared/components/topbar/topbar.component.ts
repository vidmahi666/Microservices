import { Component, Input, Output, EventEmitter, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/index';
import { Notification, NotificationStatus } from '../../../core/models';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <header class="topbar">
      <button class="hamburger" (click)="toggleSidebar.emit()">
        <i class="bi bi-list"></i>
      </button>
      <div class="search-wrap">
        <i class="bi bi-search"></i>
        <input type="text" [(ngModel)]="searchTerm" placeholder="Search courses, assessments..." class="search-input" />
        <kbd class="kbd-hint">⌘K</kbd>
      </div>
      <div class="top-actions">
        <div class="notif-wrap">
          <button class="icon-btn" (click)="showNotif = !showNotif">
            <i class="bi bi-bell-fill"></i>
            @if (unreadCount() > 0) { <span class="dot"></span> }
          </button>
          @if (showNotif) {
            <div class="notif-dropdown">
              <div class="notif-header">
                <span>Notifications</span>
                @if (unreadCount() > 0) { <button class="mark-all" (click)="markAllRead()">Mark all read</button> }
              </div>
              @if (notifications().length === 0) {
                <div class="notif-empty"><i class="bi bi-bell-slash"></i><p>No notifications</p></div>
              }
              @for (n of notifications().slice(0, 6); track n.notificationId) {
                <div class="notif-item" [class.unread]="n.status === 'UNREAD'" (click)="markRead(n)">
                  <div class="ni-dot" [class]="n.category.toLowerCase()"></div>
                  <div class="ni-body">
                    <p class="ni-msg">{{ n.message }}</p>
                    <span class="ni-time">{{ n.createdDate | date:'short' }}</span>
                  </div>
                </div>
              }
            </div>
          }
        </div>
        <div class="avatar">{{ auth.initials() }}</div>
      </div>
    </header>
  `,
  styles: [`
    .topbar { position: sticky; top: 0; z-index: 20; display: flex; align-items: center; gap: 1rem; padding: 0.9rem 1.75rem; background: rgba(13,27,62,0.7); border-bottom: 1px solid rgba(255,255,255,0.08); backdrop-filter: blur(16px); }
    .hamburger { width: 40px; height: 40px; border: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.03); color: #fff; border-radius: 10px; cursor: pointer; font-size: 1.2rem; transition: all 0.2s; &:hover { background: rgba(255,255,255,0.07); } }
    .search-wrap { flex: 1; max-width: 620px; position: relative; display: flex; align-items: center; > i { position: absolute; left: 14px; color: #8898B3; font-size: 1rem; } .search-input { width: 100%; padding: 0.7rem 3.5rem 0.7rem 2.6rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; color: #fff; font-size: 0.92rem; font-family: inherit; outline: none; &::placeholder { color: rgba(136,152,179,0.7); } &:focus { border-color: #2E7BF6; background: rgba(46,123,246,0.08); } } .kbd-hint { position: absolute; right: 10px; padding: 3px 8px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); border-radius: 6px; font-size: 0.7rem; color: #8898B3; } }
    .top-actions { display: flex; align-items: center; gap: 0.6rem; margin-left: auto; }
    .icon-btn { position: relative; width: 40px; height: 40px; border: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.03); color: #fff; border-radius: 10px; cursor: pointer; font-size: 1rem; display: flex; align-items: center; justify-content: center; .dot { position: absolute; top: 8px; right: 10px; width: 8px; height: 8px; background: #F0A500; border-radius: 50%; } }
    .avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #2E7BF6, #00C9A7); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.85rem; color: #fff; cursor: pointer; }
    .notif-wrap { position: relative; }
    .notif-dropdown { position: absolute; top: calc(100% + 10px); right: 0; width: 340px; background: #1A2F5E; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; box-shadow: 0 24px 60px rgba(0,0,0,0.5); overflow: hidden; z-index: 100; }
    .notif-header { display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,0.08); font-size: 0.875rem; font-weight: 600; color: #fff; .mark-all { background: none; border: none; color: #4F95FF; font-size: 0.78rem; cursor: pointer; } }
    .notif-item { display: flex; align-items: flex-start; gap: 10px; padding: 0.85rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,0.04); cursor: pointer; &.unread { background: rgba(46,123,246,0.06); } }
    .ni-dot { width: 8px; height: 8px; border-radius: 50%; margin-top: 6px; flex-shrink: 0; &.course { background: #4F95FF; } &.assessment { background: #F0A500; } &.program { background: #00C9A7; } &.compliance, &.system { background: #8898B3; } }
    .ni-msg  { font-size: 0.82rem; color: #fff; margin: 0; }
    .ni-time { font-size: 0.72rem; color: #8898B3; }
    .notif-empty { padding: 2rem; text-align: center; color: #8898B3; i { font-size: 1.5rem; display: block; margin-bottom: 0.5rem; } p { font-size: 0.82rem; } }
  `],
})
export class TopbarComponent implements OnInit {
  @Input()  collapsed = false;
  @Output() toggleSidebar = new EventEmitter<void>();
  auth = inject(AuthService);
  private notifSvc = inject(NotificationService);
  searchTerm    = '';
  showNotif     = false;
  notifications = signal<Notification[]>([]);
  unreadCount   = signal(0);

  ngOnInit(): void {
    const uid = this.auth.userId();
    if (uid) {
      this.notifSvc.getUnread(uid).subscribe({ next: r => { if (r.success) { this.notifications.set(r.data ?? []); this.unreadCount.set((r.data ?? []).length); } }, error: () => {} });
    }
  }
  markRead(n: Notification): void {
    if (n.status === NotificationStatus.UNREAD) {
      this.notifSvc.markRead(n.notificationId).subscribe();
      this.notifications.update(l => l.map(x => x.notificationId === n.notificationId ? { ...x, status: NotificationStatus.READ } : x));
      this.unreadCount.update(c => Math.max(0, c - 1));
    }
  }
  markAllRead(): void {
    this.notifications().filter(n => n.status === NotificationStatus.UNREAD).forEach(n => this.notifSvc.markRead(n.notificationId).subscribe());
    this.notifications.update(l => l.map(n => ({ ...n, status: NotificationStatus.READ })));
    this.unreadCount.set(0);
  }
}
