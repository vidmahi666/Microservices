import { Component, Input, Output, EventEmitter, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { UserRole } from '../../../core/models';

interface NavItem {
  label:  string;
  icon:   string;
  route:  string;
  roles:  UserRole[];
  exact?: boolean;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <aside class="sidebar">
      <!-- Brand -->
      <div class="brand" routerLink="/">
        <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
        <span class="brand-name">Edu<span>Connect</span></span>
      </div>

      <!-- Nav items -->
      <nav class="side-nav">
        @for (item of visibleNav(); track item.route) {
          <a [routerLink]="item.route"
             [routerLinkActiveOptions]="{ exact: item.exact ?? false }"
             routerLinkActive="active"
             class="side-link">
            <i class="bi" [ngClass]="item.icon"></i>
            <span>{{ item.label }}</span>
          </a>
        }
      </nav>

      <!-- Footer -->
      <div class="side-foot">
        <div class="upgrade-card">
          <i class="bi bi-stars"></i>
          <div>
            <div class="uc-title">{{ roleLabel() }}</div>
            <div class="uc-desc">{{ auth.user()?.email }}</div>
          </div>
        </div>
        <button class="logout-btn" (click)="auth.logout()">
          <i class="bi bi-box-arrow-left"></i>
          <span>Log out</span>
        </button>
      </div>
    </aside>
  `,
  styles: [`
    :host {
      --navy:         #0D1B3E;
      --navy-deep:    #0A1530;
      --accent:       #2E7BF6;
      --accent-light: #4F95FF;
      --gold:         #F0A500;
      --mint:         #00C9A7;
      --text-muted:   #8898B3;
      --border:       rgba(255,255,255,0.08);
    }
    .sidebar {
      background: linear-gradient(180deg, var(--navy) 0%, var(--navy-deep) 100%);
      border-right: 1px solid var(--border);
      padding: 1.25rem 1rem;
      display: flex; flex-direction: column; gap: 1.25rem;
      position: sticky; top: 0; height: 100vh; overflow: hidden;
    }
    .brand {
      display: flex; align-items: center; gap: 10px;
      cursor: pointer; padding: 0.25rem 0.5rem; text-decoration: none;
      .brand-icon {
        width: 38px; height: 38px;
        background: linear-gradient(135deg, #2E7BF6, #00C9A7);
        border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-size: 1.1rem; flex-shrink: 0;
      }
      .brand-name {
        font-family: 'Fraunces', serif; font-size: 1.3rem; font-weight: 700;
        color: #fff; letter-spacing: -0.02em; white-space: nowrap;
        span { color: var(--accent-light); }
      }
    }
    .side-nav { display: flex; flex-direction: column; gap: 4px; margin-top: 0.5rem; }
    .side-link {
      display: flex; align-items: center; gap: 12px;
      padding: 0.7rem 0.85rem; border-radius: 10px;
      color: var(--text-muted); text-decoration: none;
      font-size: 0.92rem; font-weight: 500;
      transition: all 0.2s ease; white-space: nowrap;
      border: 1px solid transparent;
      i { font-size: 1.05rem; width: 20px; text-align: center; flex-shrink: 0; }
      &:hover { background: rgba(255,255,255,0.04); color: #fff; }
      &.active {
        background: linear-gradient(135deg, rgba(46,123,246,0.2), rgba(0,201,167,0.12));
        border-color: rgba(46,123,246,0.35); color: #fff;
        box-shadow: 0 6px 18px rgba(46,123,246,0.18);
        i { color: var(--accent-light); }
      }
    }
    .side-foot { margin-top: auto; display: flex; flex-direction: column; gap: 0.75rem; }
    .upgrade-card {
      display: flex; align-items: center; gap: 10px; padding: 0.85rem;
      background: linear-gradient(135deg, rgba(240,165,0,0.12), rgba(46,123,246,0.08));
      border: 1px solid rgba(240,165,0,0.25); border-radius: 12px; font-size: 0.8rem;
      i { color: var(--gold); font-size: 1.25rem; }
      .uc-title { font-weight: 700; color: #fff; font-size: 0.82rem; }
      .uc-desc  { color: var(--text-muted); font-size: 0.68rem; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 140px; }
    }
    .logout-btn {
      display: flex; align-items: center; gap: 10px;
      padding: 0.7rem 0.85rem; background: transparent;
      border: 1px solid rgba(255,255,255,0.1); border-radius: 10px;
      color: var(--text-muted); font-size: 0.9rem; font-weight: 500;
      font-family: 'Plus Jakarta Sans', sans-serif; cursor: pointer; transition: all 0.2s;
      &:hover { color: #fff; border-color: rgba(239,68,68,0.4); background: rgba(239,68,68,0.08); }
      i { font-size: 1rem; }
    }

    /* collapsed */
    :host-context(.dash-shell.collapsed) .sidebar {
      padding: 1.25rem 0.5rem;
      .brand-name, .side-link span, .upgrade-card > div, .logout-btn span { display: none; }
      .upgrade-card { justify-content: center; }
      .side-link    { justify-content: center; padding: 0.7rem; }
      .logout-btn   { justify-content: center; }
    }

    @media (max-width: 900px) {
      .brand-name, .side-link span, .upgrade-card > div, .logout-btn span { display: none; }
      .side-link  { justify-content: center; padding: 0.7rem; }
      .logout-btn { justify-content: center; }
      .upgrade-card { justify-content: center; }
      .sidebar { padding: 1.25rem 0.5rem; }
    }
    @media (max-width: 560px) { .sidebar { display: none; } }
  `],
})
export class SidebarComponent {
  @Input() collapsed = false;
  @Output() toggleSidebar = new EventEmitter<void>();

  auth = inject(AuthService);

  roleLabel = computed(() => {
    const labels: Partial<Record<UserRole, string>> = {
      [UserRole.STUDENT]:            'Student',
      [UserRole.TEACHER]:            'Teacher',
      [UserRole.ADMIN]:              'Administrator',
      [UserRole.PROGRAM_MANAGER]:    'Program Manager',
      [UserRole.COMPLIANCE_OFFICER]: 'Compliance Officer',
      [UserRole.GOVERNMENT_AUDITOR]: 'Govt. Auditor',
    };
    return labels[this.auth.role()!] ?? this.auth.role();
  });

  private navItems: NavItem[] = [
    // Student
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',    route: '/student/dashboard',   roles: [UserRole.STUDENT], exact: true },
    { label: 'My Courses',    icon: 'bi-book-fill',         route: '/student/courses',     roles: [UserRole.STUDENT] },
    { label: 'Assessments',   icon: 'bi-pencil-square',     route: '/student/assessments', roles: [UserRole.STUDENT] },
    { label: 'My Progress',   icon: 'bi-bar-chart-fill',    route: '/student/progress',    roles: [UserRole.STUDENT] },
    { label: 'My Profile',    icon: 'bi-person-circle',     route: '/student/profile',     roles: [UserRole.STUDENT] },
    // Teacher
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',    route: '/teacher/dashboard',   roles: [UserRole.TEACHER], exact: true },
    { label: 'My Courses',    icon: 'bi-book-fill',         route: '/teacher/courses',     roles: [UserRole.TEACHER] },
    { label: 'Content',       icon: 'bi-collection-play',   route: '/teacher/content',     roles: [UserRole.TEACHER] },
    { label: 'Assessments',   icon: 'bi-pencil-square',     route: '/teacher/assessments', roles: [UserRole.TEACHER] },
    { label: 'Students',      icon: 'bi-people-fill',       route: '/teacher/students',    roles: [UserRole.TEACHER] },
    // Admin / Staff
    { label: 'Dashboard',     icon: 'bi-grid-1x2-fill',    route: '/admin/dashboard',     roles: [UserRole.ADMIN, UserRole.PROGRAM_MANAGER, UserRole.COMPLIANCE_OFFICER, UserRole.GOVERNMENT_AUDITOR], exact: true },
    { label: 'User Mgmt',     icon: 'bi-people-fill',       route: '/admin/users',         roles: [UserRole.ADMIN] },
    { label: 'Courses',       icon: 'bi-book-fill',         route: '/admin/courses',       roles: [UserRole.ADMIN, UserRole.PROGRAM_MANAGER] },
    { label: 'Reports',       icon: 'bi-file-earmark-bar-graph', route: '/admin/reports',  roles: [UserRole.ADMIN, UserRole.PROGRAM_MANAGER] },
    { label: 'Compliance',    icon: 'bi-shield-check',      route: '/admin/compliance',    roles: [UserRole.ADMIN, UserRole.COMPLIANCE_OFFICER] },
    { label: 'Audits',        icon: 'bi-search',            route: '/admin/audits',        roles: [UserRole.ADMIN, UserRole.COMPLIANCE_OFFICER, UserRole.GOVERNMENT_AUDITOR] },
  ];

  visibleNav = computed(() => {
    const r = this.auth.role();
    return r ? this.navItems.filter(n => n.roles.includes(r)) : [];
  });
}
