// =============================================================
//  EduConnect – TypeScript Models
//  Exact 1-to-1 mapping of Java backend entities, DTOs & enums
// =============================================================

// ── Generic API wrapper (mirrors ApiResponse<T>) ─────────────
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp?: string;
}

// ── Enums ─────────────────────────────────────────────────────
export enum UserRole {
  STUDENT            = 'STUDENT',
  TEACHER            = 'TEACHER',
  PROGRAM_MANAGER    = 'PROGRAM_MANAGER',
  ADMIN              = 'ADMIN',
  COMPLIANCE_OFFICER = 'COMPLIANCE_OFFICER',
  GOVERNMENT_AUDITOR = 'GOVERNMENT_AUDITOR',
}

export enum UserStatus {
  ACTIVE   = 'ACTIVE',
  INACTIVE = 'INACTIVE',
}

export enum CourseStatus {
  DRAFT     = 'DRAFT',
  ACTIVE    = 'ACTIVE',
  COMPLETED = 'COMPLETED',
  ARCHIVED  = 'ARCHIVED',
}

export enum AssessmentType {
  ASSIGNMENT = 'ASSIGNMENT',
  EXAM       = 'EXAM',
  QUIZ       = 'QUIZ',
  PROJECT    = 'PROJECT',
}

export enum AssessmentStatus {
  DRAFT    = 'DRAFT',
  ACTIVE   = 'ACTIVE',
  CLOSED   = 'CLOSED',
  ARCHIVED = 'ARCHIVED',
}

export enum SubmissionStatus {
  SUBMITTED               = 'SUBMITTED',
  GRADED                  = 'GRADED',
  RESUBMISSION_REQUIRED   = 'RESUBMISSION_REQUIRED',
}

export enum ContentType {
  VIDEO        = 'VIDEO',
  PDF          = 'PDF',
  QUIZ         = 'QUIZ',
  DOCUMENT     = 'DOCUMENT',
  PRESENTATION = 'PRESENTATION',
}

export enum ContentStatus {
  ACTIVE   = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  ARCHIVED = 'ARCHIVED',
}

export enum EnrollmentStatus {
  ACTIVE    = 'ACTIVE',
  COMPLETED = 'COMPLETED',
  DROPPED   = 'DROPPED',
  SUSPENDED = 'SUSPENDED',
}

export enum ProgressStatus {
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED   = 'COMPLETED',
  DROPPED     = 'DROPPED',
}

export enum NotificationCategory {
  COURSE     = 'COURSE',
  ASSESSMENT = 'ASSESSMENT',
  PROGRAM    = 'PROGRAM',
  COMPLIANCE = 'COMPLIANCE',
  SYSTEM     = 'SYSTEM',
}

export enum NotificationStatus {
  UNREAD   = 'UNREAD',
  READ     = 'READ',
  ARCHIVED = 'ARCHIVED',
}

export enum VerificationStatus {
  PENDING  = 'PENDING',
  VERIFIED = 'VERIFIED',
  REJECTED = 'REJECTED',
}

export enum ComplianceType {
  COURSE     = 'COURSE',
  ASSESSMENT = 'ASSESSMENT',
  PROGRAM    = 'PROGRAM',
  CONTENT    = 'CONTENT',
}

export enum ComplianceResult {
  COMPLIANT    = 'COMPLIANT',
  NON_COMPLIANT = 'NON_COMPLIANT',
  UNDER_REVIEW = 'UNDER_REVIEW',
  REMEDIATED   = 'REMEDIATED',
}

export enum AuditStatus {
  SCHEDULED   = 'SCHEDULED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED   = 'COMPLETED',
  CANCELLED   = 'CANCELLED',
}

export enum ReportScope {
  COURSE     = 'COURSE',
  ASSESSMENT = 'ASSESSMENT',
  PROGRAM    = 'PROGRAM',
  COMPLIANCE = 'COMPLIANCE',
  STUDENT    = 'STUDENT',
  DASHBOARD  = 'DASHBOARD',
}

// ── Auth DTOs ──────────────────────────────────────────────────
export interface LoginRequest {
  email:    string;
  password: string;
}

export interface RegisterRequest {
  name:     string;
  email:    string;
  password: string;
  phone?:   string;
}

export interface AuthResponse {
  userId: number;
  name:   string;
  email:  string;
  role:   UserRole;
  token:  string;
}

export interface CreateUserRequest {
  name:     string;
  email:    string;
  password: string;
  phone?:   string;
}

// ── User ──────────────────────────────────────────────────────
export interface User {
  userId:    number;
  name:      string;
  email:     string;
  phone?:    string;
  role:      UserRole;
  status:    UserStatus;
  createdAt: string;
  updatedAt: string;
}

export interface UpdateUserRequest {
  name?:  string;
  phone?: string;
}

// ── Student ────────────────────────────────────────────────────
export interface Student {
  studentId:   number;
  name:        string;
  dob?:        string;
  gender?:     string;
  address?:    string;
  contactInfo?: string;
  userId:      number;
  status:      UserStatus;
  createdAt:   string;
  updatedAt:   string;
}

export interface StudentProfileRequest {
  name:        string;
  dob?:        string;
  gender?:     string;
  address?:    string;
  contactInfo?: string;
}

export interface StudentDocument {
  documentId:         number;
  studentId:          number;
  uploadedDate?:      string;
  verificationStatus: VerificationStatus;
  createdAt:          string;
}

// ── Course ─────────────────────────────────────────────────────
export interface Course {
  courseId:      number;
  title:         string;
  description:   string;
  teacherUserId: number;
  startDate:     string;
  endDate:       string;
  status:        CourseStatus;
  createdAt:     string;
  updatedAt:     string;
}

export interface CourseRequest {
  title:         string;
  description:   string;
  teacherUserId: number;
  startDate:     string;
  endDate:       string;
}

// ── Enrollment ─────────────────────────────────────────────────
export interface Enrollment {
  enrollmentId:   number;
  studentId:      number;
  courseId:       number;
  studentName?:   string;
  courseTitle?:   string;
  enrollmentDate: string;
  status:         EnrollmentStatus;
}

export interface EnrollmentRequest {
  studentId: number;
  courseId:  number;
}

// ── Progress ────────────────────────────────────────────────────
export interface Progress {
  progressId:           number;
  studentId:            number;
  courseId:             number;
  studentName?:         string;
  courseTitle?:         string;
  metricsJson?:         string;
  completionPercentage: number;
  status:               ProgressStatus;
  createdAt:            string;
  updatedAt:            string;
}

export interface ProgressUpdateRequest {
  completionPercentage: number;
  metricsJson?:         string;
}

// ── Assessment ─────────────────────────────────────────────────
export interface Assessment {
  assessmentId:  number;
  courseId:      number;
  title:         string;
  type:          AssessmentType;
  fileUri?:      string;
  instructions?: string;
  dueDate?:      string;
  maxScore?:     number;
  passingScore?: number;
  status:        AssessmentStatus;
  createdAt:     string;
  updatedAt:     string;
}

export interface AssessmentRequest {
  courseId:      number;
  title:         string;
  type:          AssessmentType;
  fileUri?:      string;
  instructions?: string;
  dueDate?:      string;
  maxScore?:     number;
  passingScore?: number;
}

export interface Submission {
  submissionId: number;
  assessmentId: number;
  studentId:    number;
  fileUri?:     string;
  comments?:    string;
  score?:       number;
  status:       SubmissionStatus;
  submittedAt:  string;
  updatedAt:    string;
}

export interface SubmissionRequest {
  assessmentId: number;
  studentId:    number;
  fileUri?:     string;
  comments?:    string;
}

export interface GradeRequest {
  score:     number;
  comments?: string;
}

// ── Content ────────────────────────────────────────────────────
export interface Content {
  contentId:    number;
  courseId:     number;
  title:        string;
  type:         ContentType;
  fileUri:      string;
  description?: string;
  sortOrder?:   number;
  status:       ContentStatus;
  uploadedDate: string;
  updatedAt:    string;
}

export interface ContentRequest {
  courseId:     number;
  title:        string;
  type:         ContentType;
  fileUri:      string;
  description?: string;
  sortOrder?:   number;
}

export interface ContentAccess {
  accessId:    number;
  contentId:   number;
  studentId:   number;
  accessedAt:  string;
}

// ── Notification ────────────────────────────────────────────────
export interface Notification {
  notificationId: number;
  userId:         number;
  entityId?:      number;
  message:        string;
  category:       NotificationCategory;
  status:         NotificationStatus;
  createdDate:    string;
}

export interface NotificationRequest {
  userId:    number;
  entityId?: number;
  message:   string;
  category:  NotificationCategory;
}

// ── Compliance ──────────────────────────────────────────────────
export interface ComplianceRecord {
  complianceId: number;
  entityId:     number;
  type:         ComplianceType;
  result?:      ComplianceResult;
  recordDate:   string;
  notes?:       string;
}

export interface ComplianceRecordRequest {
  entityId: number;
  type:     ComplianceType;
  notes?:   string;
}

// ── Audit ──────────────────────────────────────────────────────
export interface Audit {
  auditId:       number;
  title:         string;
  description?:  string;
  auditorUserId?: number;
  status:        AuditStatus;
  createdAt:     string;
}

export interface AuditRequest {
  title:        string;
  description?: string;
  auditorUserId?: number;
}

export interface AuditLog {
  logId:      number;
  entityType: string;
  entityId:   number;
  userId:     number;
  action:     string;
  details?:   string;
  timestamp:  string;
}

export interface AuditLogRequest {
  entityType: string;
  entityId:   number;
  userId:     number;
  action:     string;
  details?:   string;
}

// ── Report ─────────────────────────────────────────────────────
export interface Report {
  reportId:      number;
  scope:         ReportScope;
  metrics?:      string;
  generatedDate: string;
  generatedBy:   string;
}

export interface DashboardMetrics {
  totalStudents:    number;
  totalTeachers:    number;
  totalCourses:     number;
  totalEnrollments: number;
  totalAssessments: number;
  activeUsers:      number;
  completionRate:   number;
  [key: string]: unknown;
}
