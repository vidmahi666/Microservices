package com.educonnect.reportservice.service;

import com.educonnect.reportservice.entity.Report;
import com.educonnect.reportservice.exception.ResourceNotFoundException;
import com.educonnect.reportservice.feign.CourseServiceClient;
import com.educonnect.reportservice.feign.StudentServiceClient;
import com.educonnect.reportservice.repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j @Service @RequiredArgsConstructor
public class ReportService {
    private final ReportRepository reportRepository;
    private final StudentServiceClient studentServiceClient;
    private final CourseServiceClient courseServiceClient;

    @Transactional
    public Map<String, Object> generateReport(String scope, String generatedBy) {
        Report.ReportScope reportScope = Report.ReportScope.valueOf(scope.toUpperCase());
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("scope", scope);
        metrics.put("generatedAt", LocalDateTime.now().toString());
        metrics.put("generatedBy", generatedBy != null ? generatedBy : "system");

        switch (reportScope) {
            case STUDENT -> {
                List<?> students = studentServiceClient.getAllStudents();
                metrics.put("totalStudents", students.size());
            }
            case COURSE -> {
                List<?> courses = courseServiceClient.getAllCourses();
                metrics.put("totalCourses", courses.size());
            }
            case DASHBOARD -> {
                metrics.put("totalStudents", studentServiceClient.getAllStudents().size());
                metrics.put("totalCourses",  courseServiceClient.getAllCourses().size());
            }
            default -> metrics.put("message", "Report for scope " + scope + " generated");
        }

        reportRepository.save(Report.builder().scope(reportScope).metrics(metrics.toString())
                .generatedBy(generatedBy != null ? generatedBy : "system").build());
        return metrics;
    }

    @Transactional
    public Map<String, Object> getDashboardMetrics() {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("totalStudents", studentServiceClient.getAllStudents().size());
        metrics.put("totalCourses",  courseServiceClient.getAllCourses().size());
        metrics.put("generatedAt", LocalDateTime.now().toString());

        reportRepository.save(Report.builder().scope(Report.ReportScope.DASHBOARD)
                .metrics(metrics.toString()).generatedBy("system").build());
        return metrics;
    }

    @Transactional(readOnly = true)
    public List<Report> getAllReports() { return reportRepository.findAll(); }

    @Transactional(readOnly = true)
    public Report getById(Long id) {
        return reportRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Report", id));
    }

    @Transactional(readOnly = true)
    public List<Report> getByScope(String scope) {
        return reportRepository.findByScope(Report.ReportScope.valueOf(scope.toUpperCase()));
    }
}
