package com.educonnect.enrollmentservice.service;

import com.educonnect.enrollmentservice.dto.EnrollmentRequest;
import com.educonnect.enrollmentservice.dto.EnrollmentResponse;
import com.educonnect.enrollmentservice.entity.Enrollment;
import com.educonnect.enrollmentservice.exception.BadRequestException;
import com.educonnect.enrollmentservice.exception.ResourceNotFoundException;
import com.educonnect.enrollmentservice.feign.CourseClient;
import com.educonnect.enrollmentservice.feign.StudentClient;
import com.educonnect.enrollmentservice.feign.dto.CourseResponse;
import com.educonnect.enrollmentservice.feign.dto.StudentResponse;
import com.educonnect.enrollmentservice.repository.EnrollmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Slf4j @Service @RequiredArgsConstructor
public class EnrollmentService {
    private final EnrollmentRepository enrollmentRepository;
    private final StudentClient studentClient;
    private final CourseClient courseClient;

    @Transactional
    public EnrollmentResponse enroll(EnrollmentRequest request) {
        log.info("Enrolling studentId={} into courseId={}", request.getStudentId(), request.getCourseId());
        if (enrollmentRepository.existsByStudentIdAndCourseId(request.getStudentId(), request.getCourseId()))
            throw new BadRequestException("Student is already enrolled in this course");

        // Fetch names via OpenFeign (with fallback)
        String studentName = request.getStudentName();
        String courseTitle  = request.getCourseTitle();
        if (studentName == null) {
            StudentResponse sr = studentClient.getStudentByUserId(request.getStudentId());
            if (sr != null) studentName = sr.getName();
        }
        if (courseTitle == null) {
            CourseResponse cr = courseClient.getCourseById(request.getCourseId());
            if (cr != null) courseTitle = cr.getTitle();
        }

        Enrollment saved = enrollmentRepository.save(Enrollment.builder()
                .studentId(request.getStudentId()).courseId(request.getCourseId())
                .studentName(studentName).courseTitle(courseTitle).build());
        log.info("Enrollment created id={}", saved.getEnrollmentId());
        return mapToResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByStudent(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId).stream().map(this::mapToResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByCourse(Long courseId) {
        return enrollmentRepository.findByCourseId(courseId).stream().map(this::mapToResponse).toList();
    }

    @Transactional(readOnly = true)
    public EnrollmentResponse getById(Long id) {
        return mapToResponse(enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment", id)));
    }

    @Transactional
    public EnrollmentResponse updateStatus(Long id, String status) {
        log.info("Updating enrollment id={} to status={}", id, status);
        Enrollment e = enrollmentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Enrollment", id));
        e.setStatus(Enrollment.EnrollmentStatus.valueOf(status.toUpperCase()));
        return mapToResponse(enrollmentRepository.save(e));
    }

    @Transactional
    public EnrollmentResponse unenroll(Long id) {
        Enrollment e = enrollmentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Enrollment", id));
        e.setStatus(Enrollment.EnrollmentStatus.DROPPED);
        return mapToResponse(enrollmentRepository.save(e));
    }

    private EnrollmentResponse mapToResponse(Enrollment e) {
        return EnrollmentResponse.builder()
                .enrollmentId(e.getEnrollmentId()).studentId(e.getStudentId()).studentName(e.getStudentName())
                .courseId(e.getCourseId()).courseTitle(e.getCourseTitle())
                .enrollmentDate(e.getEnrollmentDate()).status(e.getStatus()).build();
    }
}
