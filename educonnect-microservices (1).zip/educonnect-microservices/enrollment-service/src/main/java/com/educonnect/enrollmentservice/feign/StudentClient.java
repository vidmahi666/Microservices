package com.educonnect.enrollmentservice.feign;
import com.educonnect.enrollmentservice.feign.dto.StudentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
@FeignClient(name = "student-service", fallback = StudentClientFallback.class)
public interface StudentClient {
    @GetMapping("/api/students/internal/{userId}")
    StudentResponse getStudentByUserId(@PathVariable Long userId);
}
